using System;
using System.Threading;
using MSNPSharp;

// Author: Einar Egilsson
// http://tech.einaregilsson.com/2007/08/09/who-has-deleted-you-from-msn/
class MsnContactChecker
{
    readonly Messenger msn = new Messenger();
    const string Url =
        "http://tech.einaregilsson.com/2007/08/09/who-has-deleted-you-from-msn/";

    static void Main()
    {
        new MsnContactChecker().Check();
    }

    public void Check()
    {
        Console.WriteLine("\nMsnContactChecker v1.0\n{0}", Url);
        try
        {
            Console.Write("\nUsername: ");
            msn.Credentials.Account = Console.ReadLine().Trim();
            Console.Write("Password: ");
            msn.Credentials.Password = Console.ReadLine().Trim();

            msn.NameserverProcessor.ConnectingException += Error;
            msn.Nameserver.ExceptionOccurred += Error;
            msn.Nameserver.AuthenticationError += Error;
            msn.Nameserver.ServerErrorReceived += MsnError;
            msn.ContactService.SynchronizationCompleted += Synchronized;


            Console.WriteLine("\nConnecting to MSN...(this might take a little while)");
            msn.Connect();
            Thread.Sleep(Timeout.Infinite);
        }
        catch (Exception ex)
        {
            Error(this, new ExceptionEventArgs(ex));
        }
    }

    void Synchronized(object sender, EventArgs e)
    {
        Console.WriteLine("\nContacts that have deleted you:");
        int count = 0;
        foreach (Contact c in msn.ContactList.Forward)
        {
            if (!c.OnReverseList)
            {
                count++;
                if (c.Mail == c.Name)
                {
                    Console.WriteLine(" {0}", c.Name);
                }
                else
                {
                    Console.WriteLine(" {0} ({1})", c.Name, c.Mail);
                }
            }
        }
        if (count == 0)
        {
            Console.WriteLine(" None of your contacts have deleted you");
        }
        Exit(0);
    }

    private void MsnError(object sender, MSNErrorEventArgs e)
    {
        Console.WriteLine("\nError: {0}", e.MSNError);
        Exit(1);
    }

    void Error(object sender, ExceptionEventArgs e)
    {
        Console.WriteLine("\nError: {0}", e.Exception.Message);
        Exit(1);
    }

    private void Exit(int code)
    {
        Console.WriteLine("\nPress any key to quit program");
        Console.Read();
        Environment.Exit(code);
    }
}

