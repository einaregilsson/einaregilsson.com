/*
 * Copyright 2007 Einar Egilsson  ( http://tech.einaregilsson.com )
 * For details about this project see http://tech.einaregilsson.com/2007/09/20/binary-tree-image
 */
using System;
using System.Collections.Generic;
using System.Text;

namespace EinarEgilsson
{
    public class Node : INode
    {
        private Node _left;
        private Node _right;
        private int _value;

        #region INode Members

        public INode Left { get { return _left; } set { _left = (Node)value; } }
        public INode Right { get { return _right; } set { _right = (Node)value; } }
        public string Text { get { return "Node"; } }
        public object Value { get { return _value; } }
        public int IntValue { get { return _value; } }

        public Node(Node left, Node right, int value)
        {
            _left = left; _right = right; _value = value;
        }

        #endregion
    }

    //Proof-of-concept class just to demonstrate how to use the BinaryTreeImage class.
    public class BinaryTree
    {
        private Node _root;
        public Node Root { get { return _root; } }

        public void Add(int value)
        {
            _root = AddNode(new Node(null, null, value), _root);
        }

        private Node AddNode(Node newNode, Node currentNode)
        {
            if (currentNode == null)
                return newNode;
            else if (currentNode.IntValue == newNode.IntValue)
                throw new Exception("Value " + newNode.IntValue + " is already in the tree!");
            else if (currentNode.IntValue > newNode.IntValue)
                currentNode.Left = AddNode(newNode, (Node)currentNode.Left);
            else
                currentNode.Right = AddNode(newNode, (Node)currentNode.Right);
            return currentNode;
        }
    }
}
