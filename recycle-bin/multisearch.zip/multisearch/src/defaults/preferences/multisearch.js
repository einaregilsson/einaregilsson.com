pref("extensions.multisearch@einaregilsson.com.description", "chrome://multisearch/locale/multisearch.properties");
pref("extensions.multisearch.delimiter", ",");
