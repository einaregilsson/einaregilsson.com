[this is the original page http://tech.einaregilsson.com/projects/multisearch/]

This was done as a request for someone on the Mozillazine forums. It�s in the 
sandbox at AMO so you�ll need to be a registered user to view it there.

The extension splits up search terms with a delimiter and open results in 
multiple tabs. For instance, you could do a search from the search bar for 
�foo,bar,baz� and then it would open three new tabs, one searching for �foo�, 
one for �bar� and one for �baz�. The default delimiter is a , but can be 
changed through about:config, the key is extensions.multisearch.delimiter.

Works with: Firefox: 2.0b1 � 3.0.*
Latest version: 1.2.2


VERSION HISTORY

Version 1.2.2 � June 26, 2008

  Small compatibility fix for the TabMixPlus extension

Version 1.2.1 � May 24, 2008

  Added Firefox 3 compatibility.

Version 1.1 � August 7, 2007

  This is a compatibility fix for Tab Mix Plus (TMP). When TMP was installed 
  MultiSearch stopped working. Now they work together, but MultiSearch will 
  override the TMP feature of loading urls directly from the search bar, that 
  won�t work. All other TMP features will work with MultiSearch
  
Version 1.0 - July 20, 2007

  Initial version, contains all features likely to ever be in this product.



COMMENTS

###############################################################################

  Ahmed Wahdan | 07 Aug 2007 2:25 am 

  Multisearch is one of the things that makes the Firefox not just a browser 
  but an experience to enjoy.

  As the coder of the Extension said, and as it�s name implies, it is a multi 
  search extension.

  You Select the search engine you want to search, type or paste the things you
  want to search about separated with the delimiter (, by default) in the 
  search box, and VOLA, each term opens in a separate tab.

  Imagine the list you had with all those things you wanted to buy from amazon, 
  or the list of Movies on your hard disk that needs subtitles, or the list of 
  Words you want to search for meaning to on a Dictionary, just copy the list 
  and paste it in search box and browse the tabs to find what you want for.

  This extension is one of a kind, I�ve searched a lot everywhere and didn�t 
  find any extension doing this trick.

  Thank you einare.

###############################################################################

  dark_hawk | 19 Jun 2008 10:29 pm

  Hello there man,

  Thanks a lot for updating the extension for FF3.

  A little problem though, when using multisearch along side with Tab Mix Plus,
  it totally disables the search box in firefox. You made that change earlier 
  that multisearch will load 5 seconds after the browser to prevent this 
  problem.

  The version I�m using of TMP:
  http://tmp.garyr.net/tab_mix_plus-dev-build.xpi

  It�s the new version because it looks like there is a problem with the 
  author�s ISP or something.

  Thanks a lot for your continuous updates man.

###############################################################################

  einar | 26 Jun 2008 2:15 pm

  Version 1.2.2 fixes this problem.

###############################################################################

  dark_hawk | 26 Jun 2008 11:08 pm

  Indeed Version 1.2.2 Fixes the problem.

  Thank you einar.
  
###############################################################################
  
  tux. | 10 Aug 2008 12:17 pm

  Does this addon also apply to searches started from the address bar (via 
  shortcuts)?

###############################################################################

  Anonymous | 13 Aug 2008 4:26 pm

  tux,

  No, it splits the searches into tabs from the search bar.

###############################################################################

  sim | 11 Jun 2009 5:02 pm

  �it doesn�t seem to be working :(

###############################################################################
