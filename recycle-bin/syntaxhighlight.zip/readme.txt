[This is the text that was on the original page http://tech.einaregilsson.com/projects/syntaxhighlight]

This is a small class library written in C# to highlight code. I made this 
mainly because I wanted to try writing a parser. The library is designed 
to be extendable. The parser is not coupled to the formatting itself, you 
can use different formatters, all they have to do is implement a 
ISyntaxFormatter interface. Included are a HtmlInlineFormatter which 
surrounds each highlighted token with a <span style=���> and a 
HtmlCssClassFormatter which surrounds the tokens with a <span class=���> 
and defines the styles in css classes. At some point I�ll try to create 
a rtf formatter. Definitions for different languages are kept in xml files 
and are easy to make.

To test the highlighter I made a little proof-of-concept web application 
called SvnBrowser. It basically acts as a proxy for Subversion repositories, 
fetching the code files, highlighting them, and then writing them out. 