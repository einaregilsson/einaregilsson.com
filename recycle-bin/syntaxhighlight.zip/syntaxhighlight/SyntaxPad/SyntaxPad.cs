using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;
using SyntaxHighlight;

namespace SyntaxPad {
    public partial class SyntaxPad : Form {
        public SyntaxPad() {
            InitializeComponent();
            txtCode.AddSyntax(Syntax.Load(@"d:\programming\syntaxhighlight\syntaxhighlight\syntaxfiles\csharp.syntax"));
            txtCode.SelectSyntaxByFileType("cs");
        }

        private void txtCode_DoubleClick(object sender, EventArgs e) {
            MessageBox.Show(txtCode.Rtf);
            txtCode.Text = txtCode.Rtf;
        }

        private void SyntaxPad_Load(object sender, EventArgs e) {
        }
    }
}