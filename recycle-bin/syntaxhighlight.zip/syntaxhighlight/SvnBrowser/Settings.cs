using System;
using System.Data;
using System.Configuration;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Web.UI.HtmlControls;

namespace SvnBrowser 
{
    public class Settings : ApplicationSettingsBase
    {
        private Settings() {}

        public static string SvnUsername
        {
            get { return ConfigurationManager.AppSettings["SvnUsername"]; }
        }

        public static string SvnPassword
        {
            get { return ConfigurationManager.AppSettings["SvnPassword"]; }
        }

        public static string SvnDomain
        {
            get { return ConfigurationManager.AppSettings["SvnDomain"]; }
        }

        public static string SvnUrl
        {
            get { return ConfigurationManager.AppSettings["SvnUrl"]; }
        }

        public static string WindowTitlePrefix
        {
            get { return ConfigurationManager.AppSettings["WindowTitlePrefix"]; }
        }

        public static string SyntaxFilesPath
        {
            get { return ConfigurationManager.AppSettings["SyntaxFilesPath"]; }
        }

        public static bool UseSvnAuthentication
        {
            get { return ConfigurationManager.AppSettings["UseSvnAuthentication"].ToLower().Trim() == "true"; }
        }

    }
}
