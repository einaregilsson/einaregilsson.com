﻿using System;
using System.Collections;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.Security;
using System.Web.UI;
using System.Web.UI.HtmlControls;
using System.Web.UI.WebControls;
using System.Web.UI.WebControls.WebParts;
using System.Xml.Linq;
using SyntaxHighlight;
using SyntaxHighlight.Formatters;

namespace SvnBrowser {
    public partial class TestCreator : System.Web.UI.Page {
        protected void Page_Load(object sender, EventArgs e) {

        }

        protected void Button1_Click(object sender, EventArgs e) {
            SyntaxDocument doc = new SyntaxDocument(@"d:\programming\syntaxhighlight\syntaxhighlighttest\inputfiles\syntax\csharp.syntax");
            SyntaxParser parser = new SyntaxParser(doc.Syntax, new HtmlInlineFormatter());
            Response.Clear();
            Response.Write(parser.Parse(TextBox1.Text));
            Response.End();
        }
    }
}
