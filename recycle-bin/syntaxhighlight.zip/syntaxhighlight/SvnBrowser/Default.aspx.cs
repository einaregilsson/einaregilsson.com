using System;
using System.IO;
using System.Net;
using SyntaxHighlight;
using SyntaxHighlight.Formatters;

namespace SvnBrowser
{
    public partial class _Default : System.Web.UI.Page
    {
        private static SyntaxCollection _syntaxCollection = new SyntaxCollection();

        static _Default()
        {
            _syntaxCollection.LoadFolder(Settings.SyntaxFilesPath);
        }

        protected void Page_Load(object sender, EventArgs e)
        {
            string path = Request.ServerVariables["QUERY_STRING"];
            HttpWebResponse svnResponse = HttpGet(path);

            if (IsFolder(path))
            {
                ProcessSvnPage(svnResponse, path);
            }
            else
            {
                if (svnResponse.ContentType == "text/plain")
                    ProcessTextFile(svnResponse, path);
                else if (svnResponse.ContentType == "application/octet-stream")
                    ProcessBinaryFile(svnResponse, path);
                else
                    throw new NotImplementedException("SvnBrowser can't handle content type '" + svnResponse.ContentType + "'");
            }
        }

        private void SetTitle(string title)
        {
            this.Title = Settings.WindowTitlePrefix + " - " + Server.UrlDecode(title);
        }

        private void ProcessTextFile(HttpWebResponse svnResponse, string path)
        {

            string ext = Path.GetExtension(path);
            Syntax syntax;

            if ((syntax = _syntaxCollection.GetByFileType(ext)) != null)
            {
                SyntaxParser parser = new SyntaxParser(syntax, new HtmlInlineFormatter());
                litBody.Text = parser.Parse(GetText(svnResponse));
                SetTitle(path);
            }
            else
            {
                litBody.Text = "<pre>" + GetText(svnResponse).Replace("<", "&lt;").Replace(">", "&gt;") + "</pre>";
                SetTitle(path);
            }
        }

        private void ProcessBinaryFile(HttpWebResponse svnResponse, string path)
        {
            Stream stream = svnResponse.GetResponseStream();
            byte[] buf = new byte[1024];
            int count;
            string file = Server.UrlDecode(Path.GetFileName(path));

            Response.ContentType = svnResponse.ContentType;
            Response.AddHeader("Content-Disposition", "attachment;filename=\"" + file + "\"");
            while ((count = stream.Read(buf, 0, buf.Length)) > 0)
            {
                Response.OutputStream.Write(buf, 0, count);
            }

            Response.Flush();
        }

        private string GetText(HttpWebResponse response)
        {
            string text;
            using (StreamReader reader = new StreamReader(response.GetResponseStream()))
            {
                text = reader.ReadToEnd();
            }
            return text;
        }

        private void ProcessSvnPage(HttpWebResponse svnResponse, string path)
        {
            string html;
            string parentPathLink = "href=\"../\"";
            string parentPathLinkPlaceHolder = "href2=\"../\"";

            html = GetText(svnResponse);

            html = html.Replace(parentPathLink, parentPathLinkPlaceHolder);
            html = html.Replace("href=\"", "href=\"?" + path);
            html = html.Replace(parentPathLinkPlaceHolder, "href=\"?" + ParentPath(path) + "\"");

            html = html.Substring(html.IndexOf("<body>") + 6);
            html = html.Substring(0, html.IndexOf("</body>"));

            litBody.Text = html;
            SetTitle(path);
        }

        private bool IsFile(string path)
        {
            return !IsFolder(path);
        }
        private bool IsFolder(string path)
        {
            return path.EndsWith("/") || path == "";
        }

        private string ParentPath(string path)
        {
            if (path == "" || IsFirstLevelFolder(path))
                return "";
            else
                return path.Substring(0, path.Substring(0, path.Length - 1).LastIndexOf("/") + 1);
        }
        private bool IsFirstLevelFolder(string path)
        {
            return path.IndexOf("/") != -1 && path.IndexOf("/") == path.LastIndexOf("/");
        }

        private HttpWebResponse HttpGet(string path)
        {
            HttpWebRequest req = (HttpWebRequest) WebRequest.Create(Settings.SvnUrl + path);
            if (Settings.UseSvnAuthentication)
            {
                NetworkCredential credential = new NetworkCredential(Settings.SvnUsername, Settings.SvnPassword, Settings.SvnDomain);
                req.Credentials = credential;
            }

            return (HttpWebResponse) req.GetResponse();
        }
    }
}
