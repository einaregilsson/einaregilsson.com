using System.Collections;
using System.Drawing;

namespace SyntaxHighlight {

    public class Style {

        #region  Members

        private string _name;
        private Color _color;
        private bool _bold;
        private bool _italic;

        #endregion

        #region Properties

        public string Name { get { return _name; } }
        public Color Color { get { return _color; } }
        public string HtmlColor { get { return ColorTranslator.ToHtml(_color); } }
        public string RtfColor { get { return string.Format(@"\red{0}\green{1}\blue{2};", _color.R, _color.G, _color.B); } }
        public bool Bold { get { return _bold; } }
        public bool Italic { get { return _italic; } }

        #endregion

        #region Constructors

        public Style(string name, string color, bool bold, bool italic) {
            _name = name;
            _color = ColorTranslator.FromHtml(color);
            _bold = bold;
            _italic = italic;
        }

        #endregion
    }
}
