using System;
using System.Collections.Generic;
using System.Text;

namespace SyntaxHighlight.Formatters {
    
    public class XmlFormatter : ISyntaxFormatter {

        #region ISyntaxFormatter Members

        public void FormatToken(Token token) {
            token.SurroundWith("<" + token.Group.Name + ">", "</" + token.Group.Name + ">");
        }

        public string PreProcessText(string text) {
            return text;
        }

        public string PostProcessText(string text) {
            return text;
        }

        #endregion
    }
}
