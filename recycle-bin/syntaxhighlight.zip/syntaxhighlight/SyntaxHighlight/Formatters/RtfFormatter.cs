﻿using System;
using System.Collections.Generic;
using System.Text;

namespace SyntaxHighlight.Formatters {
    public class RtfFormatter : ISyntaxFormatter {
        #region ISyntaxFormatter Members
        private List<string> _colorTable = new List<string>();
        private string _header = @"
{\rtf1\ansi\deff0{\fonttbl{\f0\fnil\fprq1\fcharset0 Courier New;}}
{\colortbl ;\red0\green0\blue0;$COLORTABLE$}
\viewkind4\uc1\pard\cf0\lang1024\f0\fs20 ";

        public RtfFormatter() {
            _colorTable.Add(@"\red0\green0\blue0;");
        }
        public void FormatToken(Token token) {
            string tmp = token.ToString();
            token.Remove(0, token.Length);

            foreach (char c in tmp) {
                if (c == '\n') {
                    token.Append(@"\line");
                }else
                if (c == '{' || c == '}' || c == '\'') {
                    token.Append('\\');
                }
                token.Append(c);
            }
            token.Prepend(@"\cf" + GetColor(token.Group.Style.RtfColor) + " ");
            token.Append(@"\cf0 ");
        }

        private int GetColor(string color) {
            for (int i = 0; i < _colorTable.Count; i++) {
                if (_colorTable[i] == color) {
                    return i;
                }
            }
            _colorTable.Add(color);
            return _colorTable.Count - 1;
        }

        public string PreProcessText(string text) {
            return text;
        }

        public string PostProcessText(string text) {
            string tbl = String.Join("", _colorTable.ToArray());
            string all = (_header.Replace("$COLORTABLE$", tbl) + text + @"\par}");
            return all;
        }

        #endregion
    }
}
