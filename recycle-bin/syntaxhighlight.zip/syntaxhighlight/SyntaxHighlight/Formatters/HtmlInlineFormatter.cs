using SyntaxHighlight;

namespace SyntaxHighlight.Formatters {

    public class HtmlInlineFormatter : HtmlFormatter, ISyntaxFormatter {

        protected override string StyleToSpanStartTag(Style style) {
            return string.Format("<span style=\"color:{0};{1}{2}\">",
                    style.Color.Name,
                    style.Bold ? " font-weight:bold;" : "",
                    style.Italic ? " font-style: italic;" : "");
        }

    }
}
