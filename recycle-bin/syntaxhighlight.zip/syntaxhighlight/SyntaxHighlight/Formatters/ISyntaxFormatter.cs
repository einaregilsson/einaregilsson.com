using SyntaxHighlight;
using System.Collections.Generic;

namespace SyntaxHighlight.Formatters {

    public interface ISyntaxFormatter {

        void FormatToken(Token token);
        string PreProcessText(string text);
        string PostProcessText(string text);
    }
}
