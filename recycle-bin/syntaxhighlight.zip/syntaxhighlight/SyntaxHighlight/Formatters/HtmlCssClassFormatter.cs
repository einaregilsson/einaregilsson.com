using SyntaxHighlight;

namespace SyntaxHighlight.Formatters {
  
    public class HtmlCssClassFormatter : HtmlFormatter, ISyntaxFormatter {

        protected override string StyleToSpanStartTag(Style style) {
            return string.Format("<span class=\"{0}\">", style.Name);
        }
    }
}
