using System.Text.RegularExpressions;
using System.Collections.Generic;
using SyntaxHighlight;

namespace SyntaxHighlight.Formatters {

    public abstract class HtmlFormatter : ISyntaxFormatter {
    
        protected abstract string StyleToSpanStartTag(Style style);

        #region ISyntaxFormatter Members

        public virtual void FormatToken(Token token) {
            token.SurroundWith(StyleToSpanStartTag(token.Group.Style).Replace("<", "[[").Replace(">", "]]"), "[[/span]]");
        }

        public virtual string PreProcessText(string text) {
            return text;
        }

        public virtual string PostProcessText(string text) {
            text = text.Replace("<", "&lt;").Replace(">", "&gt;");
            Regex r = new Regex(@"\[\[(/?span.*?)\]\]");
            text = r.Replace(text, "<$1>");
            return "<pre>" + text + "</pre>";
        }

        #endregion
    }
}
