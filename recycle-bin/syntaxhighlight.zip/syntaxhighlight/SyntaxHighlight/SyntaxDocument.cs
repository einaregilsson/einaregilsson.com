using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;

namespace SyntaxHighlight {

    public class SyntaxDocument {

        #region Private classes
        private class Directive : Dictionary<string, string> {
            public bool IsStyle() { return this.ContainsKey(Props.STYLE) && !this.ContainsKey(Props.GROUP); }
            public bool IsLanguage() { return this.ContainsKey(Props.LANGUAGE); }
            public bool IsGroup() { return this.ContainsKey(Props.GROUP); }
        }

        private class Props {
            public const string LANGUAGE = "$LANGUAGE";
            public const string GROUP = "$GROUP";
            public const string STYLE = "$STYLE";
            public const string TYPE = "$TYPE";
            public const string START = "$START";
            public const string END = "$END";
            public const string ESCAPE = "$ESCAPE";
            public const string CASESENSITIVE = "$CASESENSITIVE";
            public const string FILETYPES = "$FILETYPES";
            public const string BOLD = "$BOLD";
            public const string ITALIC = "$ITALIC";
            public const string COLOR = "$COLOR";
        }
        #endregion

        #region Members
        private Regex _directivePattern = new Regex(@"^\s*\[\s*\$[A-Za-z]+=[^ ]+(\s+\$[A-Za-z]+=[^ ]+)*\s*\]\s*$", RegexOptions.Compiled);
        private Syntax _syntax;
        private int _lineNr;
        #endregion

        #region Properties
        public Syntax Syntax {
            get { return _syntax; }
        }
        #endregion

        #region Constructor
        
        public SyntaxDocument(string path) {

            if (!File.Exists(path)) {
                throw new SyntaxHighlightException("Syntax file '{0}' does not exist!", path);
            }

            LoadSyntax(new FileStream(path, FileMode.Open, FileAccess.Read));
        }

        public SyntaxDocument(Stream inputStream) {
            LoadSyntax(inputStream);
        }

        #endregion

        #region Load Syntax
        private void LoadSyntax(Stream inputStream) {

            StreamReader reader = new StreamReader(inputStream);
            string[] lines = reader.ReadToEnd().Trim().Split('\n');
            reader.Close();

            TokenGroup currentGroup = null;

            if (string.Join(String.Empty,lines).Trim() == String.Empty) {
                throw new SyntaxHighlightException("Syntax file is empty!");
            }

            Directive language = ParseDirective(lines[0]);
            ValidateLanguage(language);

            _syntax = new SyntaxHighlight.Syntax(language[Props.LANGUAGE], bool.Parse(language[Props.CASESENSITIVE]), language[Props.FILETYPES].Split(','));

            for (_lineNr = 2; _lineNr  <=lines.Length; _lineNr ++) {
                string line = lines[_lineNr-1];
                Directive dir = ParseDirective(line);
                if (dir != null) {
                    if (dir.IsStyle()) {
                        _syntax.AddStyle(CreateStyle(dir));
                    } else if (dir.IsGroup()) {
                        currentGroup = CreateGroup(dir);
                        _syntax.AddTokenGroup(currentGroup);
                    } else if (dir.IsLanguage()) {
                        throw new SyntaxHighlightException("Duplicate {0} directive at line {1}", Props.LANGUAGE,_lineNr);
                    }
                } else if (line.Trim() == "" || line.Trim().StartsWith(":::")) {
                    //Do nothing...
                } else { //Keyword
                    if (currentGroup == null) {
                        throw new SyntaxHighlightException("Keyword comes before {0} directive, line {1}", Props.GROUP, _lineNr );
                    }
                    currentGroup.AddToken(line.Trim());
                }
            }
        }
        #endregion

        #region Validation
        private void ValidateLanguage(Directive language) {
            if (language == null || !language.IsLanguage()) {
                throw new SyntaxHighlightException("First line of syntax file must be {0} directive!", Props.LANGUAGE);
            }
            CheckForProperties(language, Props.LANGUAGE, Props.FILETYPES, Props.CASESENSITIVE);
        }

        private void ValidateGroup(Directive group) {
            CheckForProperties(group, Props.GROUP, Props.TYPE, Props.STYLE);

            if (group[Props.TYPE].ToUpper() == TokenGroup.Range) {
                CheckForProperties(group, Props.GROUP, Props.START, Props.END);
            }
            if (!_syntax.ContainsStyle(group[Props.STYLE])) {
                throw new SyntaxHighlightException("Unknown style '{0}' at line {1}", group["$STYLE"], _lineNr);
            }
        }

        private void CheckForProperties(Directive dir, string dirType, params string[] properties) {
            foreach (string p in properties) {
                if (!dir.ContainsKey(p)) {
                    throw new SyntaxHighlightException("{0} directive missing required property {1}", dirType, p);
                }
            }
        }

        #endregion
        
        #region Create objects
        private Directive ParseDirective(string line) {

            if (!_directivePattern.IsMatch(line)) {
                return null;
            }

            Directive dir = new Directive();
            line = Regex.Replace(line, @"^\s*\[\s*|\s*\]\s*$", "");
            line = Regex.Replace(line, @"\s+", " ");

            string[] options = line.Split(' ');
            foreach (string option in options) {
                string[] parts = option.Split('=');
                string val = parts[1];
                val = val.Replace(@"\n", "\n").Replace(@"\r", "\r").Replace(@"\t", "\t");
                dir.Add(parts[0].ToUpper(), val);
            }

            if (!dir.IsLanguage() && !dir.IsStyle() && !dir.IsGroup()) {
                throw new SyntaxHighlightException("Unknown directive at line {0}", _lineNr);
            }
            return dir;
        }

        private Style CreateStyle(Directive styleDirective) {
            bool bold = false, italic = false;
            string color = "black";

            if (styleDirective.ContainsKey(Props.BOLD) && styleDirective[Props.BOLD].ToUpper() == "TRUE") {
                bold = true;
            }
            if (styleDirective.ContainsKey(Props.ITALIC) && styleDirective[Props.ITALIC].ToUpper() == "TRUE") {
                italic = true;
            }
            if (styleDirective.ContainsKey(Props.COLOR)) {
                color = styleDirective[Props.COLOR];
            }

            return new Style(styleDirective[Props.STYLE], color, bold, italic);
        }

        private TokenGroup CreateGroup(Directive groupDirective) {

            ValidateGroup(groupDirective);
            string type = groupDirective[Props.TYPE];
            string groupName = groupDirective[Props.GROUP];
            Style style = _syntax.GetStyle(groupDirective[Props.STYLE]);
            switch(type.ToUpper()) {
                case TokenGroup.Keywords:
                    return new KeywordTokenGroup(groupName, style); 
                case TokenGroup.Symbols:
                    return new SymbolTokenGroup(groupName, style); 
                case TokenGroup.Range:

                    char? escapeChar = null;
                    if (groupDirective.ContainsKey(Props.ESCAPE)) {
                        if (groupDirective[Props.ESCAPE].Length != 1) {
                            throw new SyntaxHighlightException("Escape character must only be a single character, line {0}", _lineNr);
                        }
                        escapeChar = groupDirective[Props.ESCAPE][0];
                    }
                    return new RangeTokenGroup(groupName, style, groupDirective[Props.START], groupDirective[Props.END], escapeChar);
                default:
                    throw new SyntaxHighlightException("{0} is not a valid {1} value, line {2}", type, Props.TYPE, _lineNr); 
            }
        }
        #endregion
    }
}
