using System;
using System.Collections.Generic;
using System.Text;

namespace SyntaxHighlight {
    public static class StopWatch {

        private static Dictionary<string, object> _measurements = new Dictionary<string, object>(); 
        public static void Start(string measurementName) {
            if (_measurements.ContainsKey(measurementName)) {
                _measurements[measurementName] = DateTime.Now;
            } else {
                _measurements.Add(measurementName, DateTime.Now);
            }
        }

        public static void Stop(string measurementName) {
            DateTime before = (DateTime)_measurements[measurementName];
            _measurements[measurementName] = DateTime.Now.Subtract(before);
        }

        public static string GetResults() {
            StringBuilder builder = new StringBuilder();

            foreach (string name in _measurements.Keys) {
                object value = _measurements[name];

                if (value is DateTime) {
                    DateTime dt = (DateTime)value;
                    builder.Append(name).Append(": ").Append(DateTime.Now.Subtract(dt).TotalMilliseconds).Append("ms (still running)\n");
                } else {
                    TimeSpan t = (TimeSpan) value;
                    builder.Append(name).Append(": ").Append(t.TotalMilliseconds).Append("ms\n");
                }
            }
            return builder.ToString();
        }
    }
}
