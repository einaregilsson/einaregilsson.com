using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Text;
using System.Windows.Forms;
using SyntaxHighlight;
using SyntaxHighlight.Formatters;
using System.IO;

namespace SyntaxHighlight.Controls{
    
    public partial class SyntaxTextBox : RichTextBox, ISyntaxFormatter {

        public SyntaxTextBox() {
            InitializeComponent();
        }

        #region Members
        private Syntax _syntax;
        private SyntaxParser _parser;
        private bool _paintingEnabled = true;
        private string _lastText = "";
        private int _diffStart, _diffEnd;
        private List<Token> _tokens = new List<Token>();
        private List<Token> _lastTokens = new List<Token>();
        private SyntaxCollection _syntaxes = new SyntaxCollection();
        private bool _enableHighlighting = true;        
        #endregion

        #region Properties
        public virtual bool HighlightingEnabled {
            get { return _enableHighlighting; }
            set {

                if (_enableHighlighting && !value) {
                    _enableHighlighting = value;
                    int selStart = SelectionStart;
                    int selLength = SelectionLength;
                    _paintingEnabled = false;
                    Select(0, Text.Length);
                    SelectionColor = ForeColor;
                    Select(selStart, selLength);
                    _paintingEnabled = true;
                } else if (value) {
                    _enableHighlighting = value;
                    _lastText = "";
                    OnTextChanged(new EventArgs());
                }
            }
        }

        #endregion

        #region Syntax selection and file loading
        public virtual void AddSyntax(Syntax syntax) {
            _syntaxes.Add(syntax);
        }

        public virtual new void LoadFile(string path) {
            if (!File.Exists(path)) {
                throw new FileNotFoundException("File not found", path);
            }

            SelectSyntaxByFileType(Path.GetExtension(path));
            this.Text = File.ReadAllText(path);
        }

        public virtual void LoadSyntaxFiles(string folder) {
            _syntaxes.LoadFolder(folder);
        }

        public virtual void SelectSyntax(string language) {
            Syntax syntax = _syntaxes.GetByLanguage(language);
            _parser = new SyntaxParser(syntax, new RtfFormatter());
            OnTextChanged(new EventArgs());
        }

        public virtual void SelectSyntaxByFileType(string fileExtension) {
            Syntax syntax = _syntaxes.GetByFileType(fileExtension);
            _parser = new SyntaxParser(syntax, new RtfFormatter());
            OnTextChanged(new EventArgs());
        }
        #endregion

        #region Overrides
        bool t = false;
        protected override void OnTextChanged(EventArgs e) {
            if (t) return;
            base.OnTextChanged(e);
            if (!_enableHighlighting || _parser == null) {
                return;
            }
            //CalculateDiff();
            t = true;
            int i = this.SelectionStart;
            this.Rtf = _parser.Parse(Text).Trim();
            t = false;
            this.SelectionStart = i;
        }

        protected override void WndProc(ref System.Windows.Forms.Message m) {
            // Code courtesy of Mark Mihevc
            // sometimes we want to eat the paint message so we don't have to see all the
            // flicker from when we select the text to change the color.
            short WM_PAINT = 0x00f;
            if (m.Msg == WM_PAINT && !_paintingEnabled) {
                m.Result = IntPtr.Zero;
            } else {
                base.WndProc(ref m);
            }
        }
        #endregion

        #region Calculate affected area
        protected virtual void CalculateDiff() {
            //StopWatch.Start("Diff");

            char[] newString = Text.ToCharArray();
            char[] oldString = _lastText.ToCharArray();
            Token t;

            if (_lastTokens.Count < 3) {
                _diffStart = 0;
                _diffEnd = newString.Length - 1;
                return;
            }
            //Figure out where the new string and old start to be different
            _diffStart = 0;
            int firstIndex = 0;
            int lastIndex = _tokens.Count - 1;
            while (_diffStart < oldString.Length && _diffStart < newString.Length
                   && newString[_diffStart] == oldString[_diffStart]) {
                _diffStart++;
            }

            //Figure out where the new string and old start to be different by going backwards.
            int diff = newString.Length - oldString.Length;
            _diffEnd = newString.Length - 1;
            while (_diffEnd > _diffStart && _diffEnd >= 0 && _diffEnd - diff >= 0 && newString[_diffEnd] == oldString[_diffEnd - diff]) {
                _diffEnd--;
            }

            if (_diffEnd <= _diffStart) {
                _diffEnd = _diffStart;
            }

            _lastText = Text;

            //To make sure that we cover everything that might be affected we'll have to figure
            //out what tokens from the last pass overlap our diff area and expand our diffarea
            //to cover those token positions.
            //First find the first token that overlaps with the changed text
            while (firstIndex < _lastTokens.Count-1) {
                t = _lastTokens[firstIndex];
                if (t.StartPosition + t.Length >= _diffStart) {
                    break;
                }
                firstIndex++;
            }

            //Then find the last token that overlaps with the changed text.
            while (lastIndex > 0) {
                t = _lastTokens[lastIndex];
                if (t.StartPosition <= _diffEnd) {
                    break;
                }
                lastIndex--;
            }

            _diffStart = _lastTokens[firstIndex].StartPosition;
            _diffEnd = _lastTokens[lastIndex].EndPosition;
            //StopWatch.Stop("Diff");
        }
        #endregion

        #region ISyntaxFormatter Members

        public virtual void FormatToken(Token token) {
            //Don't wanna paint here, just gather them up
            _tokens.Add(token);
        }

        public virtual string PreProcessText(string text) {
            //StopWatch.Start("Parse");
            _tokens.Clear();
            return text;
        }

        public virtual string PostProcessText(string text) {
            //StopWatch.Stop("Parse");            
            
            //Remember the original selection
            int selStart = SelectionStart;
            int selLength = SelectionLength;
            Token t;
            int firstIndex = 0;
            int lastIndex = _tokens.Count - 1;

            //First find the first token that overlaps with the changed text
            while (firstIndex < _tokens.Count) {
                t = _tokens[firstIndex];
                if (t.StartPosition + t.Length >= _diffStart) {
                    break;
                }
                firstIndex++;
            }
            if (firstIndex > 0) {
                firstIndex--; //Some precaution, go one more back then we probably need.
            }

            //Then find the last token that overlaps with the changed text.
            while (lastIndex >= 0) {
                t = _tokens[lastIndex];
                if (t.StartPosition <= _diffEnd) {
                    break;
                }
                lastIndex--;
            }
            if (lastIndex < _tokens.Count - 1) {
                lastIndex++; //Go one further than we probably need
            }

            //StopWatch.Start("Paint");
            _paintingEnabled = false; //To get rid of flicker
            if (_tokens.Count > 0) {

                Token firstToken = _tokens[firstIndex];
                Token lastToken = _tokens[lastIndex];

                //First color the changed area in the foreground color...
                if (firstIndex == 0) {
                    Select(0, lastToken.EndPosition);
                } else if (lastIndex == _tokens.Count-1) {
                    Select(firstToken.StartPosition, Text.Length - firstToken.StartPosition);
                } else {
                    Select(firstToken.StartPosition, lastToken.EndPosition - firstToken.StartPosition);
                }
                SelectionColor = ForeColor;

                ///...and then color the tokens
                for (int i = firstIndex; i <= lastIndex; i++) {
                    t = _tokens[i];
                    Select(t.StartPosition, t.Length);
                    SelectionColor = t.Group.Style.Color;
                }
                //StopWatch.Stop("Paint");
            } else {
                //No tokens, everything in forecolor:
                Select(0, Text.Length);
                SelectionColor = ForeColor;
            }
            //Restore original selection and allow painting
            Select(selStart, selLength);
            _paintingEnabled = true;
            //MessageBox.Show(StopWatch.GetResults());
            _lastTokens = _tokens;
            return text;
        }

        #endregion
    }
}
