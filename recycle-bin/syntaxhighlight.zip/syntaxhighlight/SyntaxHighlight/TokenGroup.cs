using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;

namespace SyntaxHighlight {

    public abstract class TokenGroup {

        public const string Keywords = "KEYWORDS";
        public const string Symbols = "SYMBOLS";
        public const string Range = "RANGE";

        #region Members
        private string _name;
        private List<string> _tokens = new List<string>();
        Style _style;
        #endregion

        #region Constructor
        public TokenGroup(string name, Style style) {
            _name = name;
            _style = style;
        }
        #endregion

        #region Properties
        public string Name { get { return _name; } }
        public List<string> Tokens { get { return _tokens; } }
        public Style Style { get { return _style; } }
        #endregion
    
        public virtual void AddToken(string token) {
            _tokens.Add(token);
        }
    }


    public class KeywordTokenGroup : TokenGroup {
        public KeywordTokenGroup(string name, Style style) : base(name, style) {}
    }

    public class SymbolTokenGroup : TokenGroup {
        public SymbolTokenGroup(string name, Style style) : base(name, style) { }
    }
    
    public class RangeTokenGroup : TokenGroup {
        private string _startToken;
        private string _endToken;
        private char? _escapeChar;
    
        public RangeTokenGroup(string name, Style style, string startToken, string endToken, char? escapeChar) : base(name, style) {
            _startToken = startToken;
            _endToken = endToken;
            _escapeChar = escapeChar;
        }

        public bool EndTokenIsEscapeChar {
            get { return _escapeChar.HasValue && _endToken.Length == 1 && _escapeChar.Value == _endToken[0]; }
        }
        public override void AddToken(string token) {
            throw new SyntaxHighlightException("Token '{0}' cannot be added to token group with $TYPE=Range!", token);
        }

        public string StartToken { get { return _startToken;}}
        public string EndToken { get { return _endToken;}}
        public char? EscapeChar { get { return _escapeChar;}}
    }
}
