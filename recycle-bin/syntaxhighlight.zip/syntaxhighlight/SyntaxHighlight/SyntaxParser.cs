using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using SyntaxHighlight.Formatters;

namespace SyntaxHighlight {

    public class SyntaxParser {

        #region Members
        protected Node _root = new Node();
        protected ISyntaxFormatter _formatter;
        protected Syntax _syntax;
        #endregion

        public SyntaxParser(Syntax syntax, ISyntaxFormatter formatter) {
            _syntax = syntax;
            _formatter = formatter;
            BuildSyntaxTree();
        }

        #region Build Syntax Tree

        private void BuildSyntaxTree() {
            foreach (TokenGroup group in _syntax.TokenGroups) {
                
                foreach (string token in group.Tokens) {
                    InsertToken(token, group, 0, _root);
                }

                if (group is RangeTokenGroup) {
                    RangeTokenGroup rg = (RangeTokenGroup)group;
                    InsertToken(rg.StartToken, group, 0, _root);
                }
            }
        }

        private Node InsertToken(string token, TokenGroup group, int pos, Node node) {
            Node child = null;

            if (!node.Children.TryGetValue(token[pos], out child)) {
                child = new Node();
                node.Children.Add(token[pos], child);
            }

            if (pos == token.Length - 1) {
                child.Group = group;
                return child;
            } else {
                return InsertToken(token, group, ++pos, child);
            }
        }

        #endregion

        #region Parsing

        public virtual string Parse(string src) {
            StringBuilder output = new StringBuilder(src.Length * 3);
            int pos = 0;
            int prevpos = 0;
            TokenGroup group;

            src = _formatter.PreProcessText(src);
            while (pos < src.Length) {
                prevpos = pos;

                if (pos > 0 && IsWordChar(src[pos]) && IsWordChar(src[pos - 1])) {
                    output.Append(src[pos]);
                    pos++;
                    continue;
                }
                group = LexToken(src, ref pos);
                if (group != null) {
                    Token token = new Token(src.Substring(prevpos, pos - prevpos + 1), prevpos, group);
                    _formatter.FormatToken(token);
                    output.Append(token);
                } else {
                    pos = prevpos;
                    output.Append(src[pos]);
                }
                pos++;
            }

            return _formatter.PostProcessText(output.ToString());
        }

        private bool IsWordChar(char c) {
            return Char.IsLetterOrDigit(c) || c == '_';
        }

        private TokenGroup LexToken(string src, ref int pos) {

            TokenGroup candidateGroup = null;
            int candidatePos = pos + 1;
            int currPos = pos;

            Node currNode = _root;
            Node child = null;

            while (pos < src.Length && currNode.Children.TryGetValue(src[pos], out child)) {
                if (child.Group != null) {

                    if (pos == src.Length - 1) {
                        //End of string is a valid terminator for all tokens
                        candidatePos = pos;
                        candidateGroup = child.Group;
                    } else {

                        if (child.Group != null) {
                            if (child.Group is SymbolTokenGroup) {
                                candidatePos = pos;
                                candidateGroup = child.Group;
                            }else if (child.Group is KeywordTokenGroup) {
                                if (!IsWordChar(src[pos + 1]) && (currPos == 0 || !IsWordChar(src[currPos-1]))) {
                                    candidatePos = pos;
                                    candidateGroup = child.Group;
                                }
                            } else if (child.Group is RangeTokenGroup) {
                                RangeTokenGroup rangeGroup = (RangeTokenGroup) child.Group;
                                candidateGroup = child.Group;
                                int rpos = pos + 1;
                                int matchPos = 0;
                                while (rpos < src.Length) {

                                    if (rangeGroup.EscapeChar.HasValue && src[rpos] == rangeGroup.EscapeChar.Value) {
                                        
                                        if (!(rangeGroup.EndTokenIsEscapeChar && rpos != src.Length-1 && src[rpos+1] != rangeGroup.EscapeChar.Value)) {
                                            matchPos = 0;
                                            rpos += 2;
                                            continue;
                                        }
                                    }
                                    if (src[rpos] == rangeGroup.EndToken[matchPos]) {
                                        
                                        matchPos++;
                                        if (matchPos == rangeGroup.EndToken.Length) {
                                            break;
                                        }
                                    } else {
                                        matchPos = 0;
                                    }
                                    rpos++;
                                }
                                rpos = Math.Min(rpos, src.Length - 1);
                                candidatePos = rpos;
                            }
                        }
                    }
                }
                currNode = child;
                pos++;
            }
            pos = candidatePos;
            return candidateGroup;
        }
        #endregion

        protected class Node {
            public Dictionary<char, Node> Children = new Dictionary<char, Node>();
            public TokenGroup Group;
        }
    }
}
