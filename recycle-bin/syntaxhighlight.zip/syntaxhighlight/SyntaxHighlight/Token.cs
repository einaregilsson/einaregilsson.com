using System;
using System.Text;

namespace SyntaxHighlight {

    public class Token {

        public Token(string src, int startPos, TokenGroup group) {
            _builder = new StringBuilder(src.Length * 2);
            Append(src);
            _startPos = startPos;
            _group = group;
        }

        #region Members

        private StringBuilder _builder;
        private int _startPos;
        private TokenGroup _group;

        #endregion

        #region Properties

        public virtual int Length { get { return _builder.Length; } }
        public virtual int StartPosition { get { return _startPos; } }
        public virtual int EndPosition { get { return _startPos + _builder.Length; } }
        public virtual TokenGroup Group { get { return _group; } }

        public virtual int Capacity {
            get { return _builder.Capacity; }
            set { _builder.Capacity = value; }
        }

        public virtual int MaxCapacity {
            get { return _builder.MaxCapacity; }
        }

        #endregion

        #region StringBuilder delegations

        public virtual Token Append(char ch) {
            _builder.Append(ch);
            return this;
        }

        public virtual Token Append(string s) {
            _builder.Append(s);
            return this;
        }

        public virtual Token Insert(int index, string value) {
            _builder.Insert(index, value);
            return this;
        }

        public virtual Token Insert(int index, char value) {
            _builder.Insert(index, value);
            return this;
        }

        public virtual Token Remove(int startIndex, int length) {
            _builder.Remove(startIndex, length);
            return this;
        }

        public virtual Token Replace(string oldValue, string newValue) {
            _builder.Replace(oldValue, newValue);
            return this;
        }

        public override bool Equals(object obj) {
            return this.StartPosition == ((Token)obj).StartPosition;
        }

        public override string ToString() {
            return _builder.ToString();
        }

        public override int GetHashCode() {
            return this.StartPosition;
        }

        #endregion

        #region Added functions

        public virtual Token Prepend(string value) {
            _builder.Insert(0, value);
            return this;
        }

        public virtual Token SurroundWith(string before, string after) {
            _builder.Insert(0, before);
            _builder.Append(after);
            return this;
        }

        #endregion

    }
}
