using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Collections.ObjectModel;

namespace SyntaxHighlight {

    public class Syntax {
 
        #region Members
        protected string _language;
        protected bool _caseSensitive;
        protected bool _fixCase;
        protected List<TokenGroup> _tokenGroups = new List<TokenGroup>();
        protected List<Style> _styles = new List<Style>();
        protected List<string> _fileTypes = new List<string>();
        #endregion

        #region Properties

        public virtual string Language { get { return _language; } }
        public virtual bool CaseSensitive { get { return _caseSensitive; } }
        public virtual ReadOnlyCollection<TokenGroup> TokenGroups { get { return _tokenGroups.AsReadOnly(); } }
        public virtual ReadOnlyCollection<Style> Styles { get { return _styles.AsReadOnly(); } }
        public virtual ReadOnlyCollection<string> FileTypes { get { return _fileTypes.AsReadOnly(); } }

        #endregion

        #region Constructors
        public Syntax(string language, bool caseSensitive)
            : this(language, caseSensitive, new string[] { }) { }

        public Syntax(string language, bool caseSensitive, IEnumerable<string> filetypes) {
            _language = language;
            _caseSensitive = caseSensitive;

            foreach (string filetype in filetypes) {
                _fileTypes.Add(FixFileType(filetype));
            }
        }
        #endregion

        public Style GetStyle(string styleName) {
            foreach (Style s in _styles) {
                if (s.Name.ToUpper() == styleName.ToUpper()) {
                    return s;
                }
            }
            return null;
        }
        public bool ContainsStyle(string styleName) {
            return GetStyle(styleName) != null;
        }

        #region Load

        public static Syntax Load(string path) {
            return new SyntaxDocument(path).Syntax;
        }

        #endregion

        #region Add

        public virtual void AddTokenGroup(TokenGroup group) {
            _tokenGroups.Add(group);
        }

        public virtual void AddStyle(Style style) {
            _styles.Add(style);
        }

        #endregion

        #region FileTypes
        public void AddFileType(string fileType) {
            this._fileTypes.Add(FixFileType(fileType));
        }
        public virtual bool SupportsFileType(string filetype) {
            return this._fileTypes.Contains(FixFileType(filetype));
        }

        protected virtual string FixFileType(string filetype) {
            return Regex.Replace(filetype.Trim().ToLower(), @"^\*?\.?", "");
        }
        
        #endregion
    }
}
