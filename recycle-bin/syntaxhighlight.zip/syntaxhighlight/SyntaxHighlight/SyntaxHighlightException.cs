using System;

namespace SyntaxHighlight
{
    public class SyntaxHighlightException : Exception
    {
        public SyntaxHighlightException(string msg) : base(msg) { }
        public SyntaxHighlightException(string msg, Exception innerException) : base(msg, innerException) { }
        public SyntaxHighlightException(string msg, params object[] args) : base(String.Format(msg, args)){  }
    }
}
