using System;
using System.IO;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Reflection;

namespace SyntaxHighlight {
    
    public class SyntaxCollection : List<Syntax> {
    
        public void LoadFolder(string folderPath) {

            if (!Path.IsPathRooted(folderPath)) {
                Uri uri = new Uri(Path.GetDirectoryName(Assembly.GetExecutingAssembly().EscapedCodeBase));
                string baseFolder = uri.LocalPath;
                folderPath = Path.Combine(baseFolder, folderPath);
            }

            if (!Directory.Exists(folderPath)) {
                throw new FileNotFoundException("Folder " + folderPath + " doesn't exist!");
            }

            string[] syntaxFiles = Directory.GetFiles(folderPath, "*.syntax");

            foreach (string syntaxFile in syntaxFiles) {
                this.Add(Syntax.Load(syntaxFile));
            }
        }

        public Syntax GetByLanguage(string language) {
            return this.Find(delegate(Syntax s) { return s.Language.ToLower() == language.ToLower(); });
        }

        public Syntax GetByFileType(string fileExtension) {
            return this.Find(delegate(Syntax s) { return s.SupportsFileType(fileExtension); });
        }
    }
}
