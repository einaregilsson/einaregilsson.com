﻿using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using SyntaxHighlight.Formatters;

namespace SyntaxHighlight.Test {
    
    
    [TestFixture]
    public class SyntaxParserTest {

        private SyntaxParser _parser;
        
        [TestFixtureSetUp]
        public void Init() {
            SyntaxDocument doc = new SyntaxDocument(TestFile.GetStream("InputFiles.Syntax.csharp.syntax"));
            _parser = new SyntaxParser(doc.Syntax, new HtmlInlineFormatter());
        }

        [Test]
        public void TestKeywords() {
            CompareFiles("keywords");
        }

        [Test]
        public void TestStrings() {
            CompareFiles("strings");
        }

        [Test]
        public void TestComments() {
            CompareFiles("comments");
        }
        
        [Test]
        public void TestSymbols() {
            CompareFiles("symbols");
        }

        [Test]
        public void TestPreProcessor() {
            CompareFiles("preprocessor");
        }

        private void CompareFiles(string filename) {
            string input = TestFile.GetContents("InputFiles." + filename + ".input").Trim();
            string output = TestFile.GetContents("OutputFiles." + filename + ".output").Trim();
            Assert.AreEqual(output, _parser.Parse(input));
        }

    }
}
