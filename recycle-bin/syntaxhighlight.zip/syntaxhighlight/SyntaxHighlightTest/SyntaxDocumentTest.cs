using System;
using System.Collections.Generic;
using System.Text;
using NUnit.Framework;
using SyntaxHighlight;

namespace SyntaxHighlight.Test {

    [TestFixture]
    public class SyntaxDocumentTest {

        #region Invalid Syntax Errors

        [Test]
        public void TestFirstLineNotLanguageDirective() {
            TestError("FirstLineError.syntax", "First line of syntax file must be $LANGUAGE directive!");
        }

        [Test]
        public void TestDuplicateLanguageDirective() {
            TestError("DuplicateLanguage.syntax", "Duplicate $LANGUAGE directive at line 17");
        }

        [Test]
        public void TestKeywordBeforeGroup() {
            TestError("KeywordBeforeGroup.syntax", "Keyword comes before $GROUP directive, line 10");
        }

        [Test]
        public void TestInvalidTypeValue() {
            TestError("InvalidTypeValue.syntax", "foo is not a valid $TYPE value, line 12");
        }

        [Test]
        public void TestUnknownStyle() {
            TestError("UnknownStyle.syntax", "Unknown style 'Keywords' at line 4");
        }

        [Test]
        public void TestTokenInRangeGroup() {
            TestError("TokenInRangeGroup.syntax", "Token 'bool' cannot be added to token group with $TYPE=Range!");
        }

        [Test]
        public void TestUnknownDirective() {
            TestError("UnknownDirective.syntax", "Unknown directive at line 4");
        }

        [Test]
        public void TestEscapeCharTooLong() {
            TestError("EscapeCharTooLong.syntax", "Escape character must only be a single character, line 12");
        }

        [Test]
        public void TestMissingRequiredProperties() {
            TestError("LangMissingCaseSensitive.syntax", "$LANGUAGE directive missing required property $CASESENSITIVE");
            TestError("LangMissingFiletypes.syntax", "$LANGUAGE directive missing required property $FILETYPES");
            TestError("GroupMissingStyle.syntax", "$GROUP directive missing required property $STYLE");
            TestError("GroupMissingType.syntax", "$GROUP directive missing required property $TYPE");
            TestError("RangeGroupMissingStart.syntax", "$GROUP directive missing required property $START");
            TestError("RangeGroupMissingEnd.syntax", "$GROUP directive missing required property $END");
        }

        [Test]
        public void TestFileDoesNotExist() {
            try {
                SyntaxDocument doc = new SyntaxDocument("file.notexist");
                Assert.Fail("Should have failed on non-existant file!");
            } catch (SyntaxHighlightException ex) {
                Assert.AreEqual("Syntax file 'file.notexist' does not exist!", ex.Message, "Unexpected message : " + ex.Message);
            }
        }

        [Test]
        public void TestEmptySyntax() {
            TestError("Empty.syntax", "Syntax file is empty!");
        }

        private void TestError(string inputFile, string expectedMessage) {
            try {
                SyntaxDocument doc = new SyntaxDocument(TestFile.GetStream("InputFiles.Syntax." + inputFile));
                Assert.Fail("Input file " + inputFile + " should have caused an exception!");

            } catch (SyntaxHighlightException ex) {
                Assert.AreEqual(expectedMessage, ex.Message, "Got different error than expected!");
            }
        }
        
        #endregion

        #region Syntax validation

        [Test]
        public void TestValidCSharpSyntax() {
            ValidateCSharpSyntax("InputFiles.Syntax.csharp.syntax");
        }

        [Test]
        public void TestValidButUglyCSharpSyntax() {
            ValidateCSharpSyntax("InputFiles.Syntax.uglycsharp.syntax");
        }

        private void ValidateCSharpSyntax(string resource) {
            SyntaxDocument doc = new SyntaxDocument(TestFile.GetStream(resource));
            Syntax syntax = doc.Syntax;

            Assert.AreEqual(true, syntax.CaseSensitive, "C# is case sensitive");
            Assert.AreEqual(1, syntax.FileTypes.Count, "C# only has one filetype");
            Assert.AreEqual("cs", syntax.FileTypes[0], "C# has file types 'cs'");
            Assert.AreEqual(8, syntax.Styles.Count, "Syntax file should have 8 styles!");

            ValidateStyle(syntax, "Keywords", "Blue", true, false);
            ValidateStyle(syntax, "Comments", "Green", false, true);
            ValidateStyle(syntax, "Strings", "Brown", false, false);
            ValidateStyle(syntax, "Brackets", "Red", false, false);
            ValidateStyle(syntax, "Symbols", "Purple", false, false);
            ValidateStyle(syntax, "Symbols2", "Red", true, false);
            ValidateStyle(syntax, "PreProcessor", "Pink", true, false);
            ValidateStyle(syntax, "XmlComments", "Gray", false, true);

            Assert.AreEqual(10, syntax.TokenGroups.Count, "Syntax file should have 10 tokenGroups");
            ValidateKeywordOrSymbolGroup(syntax, "Keywords", "KEYWORDS", "Keywords", "abstract", "as", "base", "bool", "break", "byte", "case", "catch", "char", "checked", "class", "const", "continue", "decimal", "default", "delegate", "do", "double", "event", "explicit", "extern", "else", "enum", "false", "finally", "fixed", "float", "for", "foreach", "get", "goto", "if", "implicit", "in", "int", "interface", "internal", "is", "lock", "long", "namespace", "new", "null", "object", "operator", "out", "override", "params", "partial", "private", "protected", "public", "readonly", "ref", "return", "set", "struct", "switch", "sbyte", "sealed", "short", "sizeof", "stackalloc", "static", "string", "this", "throw", "true", "try", "typeof", "uint", "ulong", "unchecked", "unsafe", "ushort", "using", "value", "virtual", "volatile", "void", "while", "where", "yield return");
            ValidateKeywordOrSymbolGroup(syntax, "Symbols", "SYMBOLS", "Symbols", "+", "-", "*", "/", "%", "<", ">", "&", "|", "^", "=");
            ValidateKeywordOrSymbolGroup(syntax, "Symbols2", "SYMBOLS", "Symbols2", "++", "--", "-=", "+=", "*=", "/=", "%=", "<=", ">=", "==", "!=", "&&", "||", "|=", "&=", "^=");
            ValidateKeywordOrSymbolGroup(syntax, "Brackets", "SYMBOLS", "Brackets", "(", ")", "{", "}", "[", "]");
            ValidateKeywordOrSymbolGroup(syntax, "PreProcessor", "KEYWORDS", "PreProcessor", "#if", "#else", "#elif", "#endif", "#define", "#undef", "#warning", "#error", "#line", "#region", "#endregion");
            ValidateRangeGroup(syntax, "Comments", "Comments", "//", "\n", null);
            ValidateRangeGroup(syntax, "XmlComments", "XmlComments", "///", "\n", null);
            ValidateRangeGroup(syntax, "MultiLineComments", "Comments", "/*", "*/", null);
            ValidateRangeGroup(syntax, "Strings", "Strings", "\"", "\"", '\\');
            ValidateRangeGroup(syntax, "RawStrings", "Strings", "@\"", "\"", '"');
        }

        private void ValidateStyle(Syntax syntax, string name, string color, bool bold, bool italic) {
            Style style = syntax.GetStyle(name);
            Assert.IsNotNull(style, "Syntax should include style " + name);
            Assert.AreEqual(style.Name.ToUpper(), name.ToUpper(), "Names of style do not match, {0} and {1}", style.Name, name);
            Assert.AreEqual(color, style.HtmlColor);
            Assert.AreEqual(bold, style.Bold, "Expected bold to be {0} for style {1}", bold, style.Name);
            Assert.AreEqual(italic, style.Italic, "Expected italic to be {0} for style {1}", italic, style.Name);
        }

        private void ValidateKeywordOrSymbolGroup(Syntax syntax, string name, string type, string stylename, params string[] tokens) {
            foreach (TokenGroup tg in syntax.TokenGroups) {
                if (tg.Name.ToUpper() == name.ToUpper()) {

                    if (tg is KeywordTokenGroup) {
                        Assert.AreEqual(TokenGroup.Keywords, type, "Expected group '{0}' to be of type '{1}'", name, type);
                    } else if (tg is SymbolTokenGroup) {
                        Assert.AreEqual(TokenGroup.Symbols, type, "Expected group '{0}' to be of type '{1}'", name, type);
                    }
                    Assert.AreEqual(stylename.ToUpper(), tg.Style.Name.ToUpper(), "Expected group '{0}' to have style '{1}'", name, stylename);

                    Assert.AreEqual(tokens.Length, tg.Tokens.Count);

                    foreach (string token in tokens) {
                        Assert.IsTrue(tg.Tokens.Contains(token), "Group does not contain token " + token);
                    }
                    return;
                }
            }
            Assert.Fail("Found no TokenGroup named " + name);
        }

        private void ValidateRangeGroup(Syntax syntax, string name, string stylename, string start, string end, char? escapeChar) {
            foreach (TokenGroup tg in syntax.TokenGroups) {
                if (tg.Name.ToUpper() == name.ToUpper()) {

                    if (!(tg is RangeTokenGroup)) {
                        Assert.Fail("Expected group '{0}' to be RangeTokenGroup", name);
                    }

                    Assert.AreEqual(stylename.ToUpper(), tg.Style.Name.ToUpper(), "Expected group '{0}' to have style '{1}'", name, stylename);
                    Assert.AreEqual(0, tg.Tokens.Count);
                    RangeTokenGroup rg = (RangeTokenGroup) tg;
                    Assert.AreEqual(start, rg.StartToken);
                    Assert.AreEqual(end, rg.EndToken);
                    Assert.AreEqual(escapeChar, rg.EscapeChar);
                    return;
                }
            }
            Assert.Fail("Found no TokenGroup named " + name);
        }

        #endregion
    }
}
