using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;

namespace SyntaxHighlight.Test {
    
    internal static class TestFile {

        public static Stream GetStream(string resourceName) {
            return Assembly.GetExecutingAssembly().GetManifestResourceStream("SyntaxHighlight.Test." + resourceName);
        }

        public static string GetContents(string resourceName) {
            TextReader reader = new StreamReader(GetStream(resourceName));
            string contents = reader.ReadToEnd();
            reader.Close();
            return contents;
        }
    }
}
