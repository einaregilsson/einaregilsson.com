var SearchForSender = {

    searchBox : null,
    subject : null,
    sender : null,
    subjectMenu : null,
    senderMenu : null,
    seperator : null,
    subjectOrSenderMenu : null,

    onLoad : function(event) {
        var menuItems;
        document.getElementById('threadPaneContext')
            .addEventListener("popupshowing", function(e) { SearchForSender.showContextMenu(e); }, false);

        this.searchBox      = document.getElementById("searchInput");
        this.subjectMenu    = document.getElementById("searchforsender-subject");
        this.senderMenu     = document.getElementById("searchforsender-sender");
        this.seperator      = document.getElementById("searchforsender-sep");

        menuItems = this.searchBox.getElementsByTagName("menuitem");

        for (var x in menuItems) {
            if (menuItems[x].value == kQuickSearchSenderOrSubject) {
                this.subjectOrSenderMenu = menuItems[x];
                break;
            }
        }

    },

    showContextMenu : function(event) {
        var msgURI     //selected message uri
          , msgHdr     //selected message header
          , parser     //to parse author
          , hide
          , senderAddress;


        hide = GetNumSelectedMessages() != 1;

        this.subjectMenu.hidden = hide;
        this.senderMenu.hidden = hide;
        this.seperator.hidden = hide;

        if (hide)
            return;

        msgURI = GetLoadedMessage();
        if (!msgURI)
            return;

        msgHdr = messenger.messageServiceFromURI(msgURI).messageURIToMsgHdr(msgURI);

        parser = Components.classes["@mozilla.org/messenger/headerparser;1"]
                    .getService(Components.interfaces.nsIMsgHeaderParser);

        senderAddress = {};
        parser.parseHeadersWithArray(msgHdr.author, senderAddress, {}, {});
        this.sender = senderAddress.value

        if (!msgHdr.mime2DecodedSubject) {
            this.subjectMenu.disabled = true;
            return;
        }

        this.subject = msgHdr.mime2DecodedSubject.toString();
        this.subject = this.subject.replace(/^(Re:|fwd:|fw:|spam-low:|out of office autoreply:|\s|\[)*/i, "");
        this.subject = this.subject.replace(/(\s|\])*$/i, "");

        if (!this.subject) {
            this.subjectMenu.disabled = true;
            return;
        }
    },

    searchForSubject: function(event) {
        this.search(this.subject);
    },

    searchForSender: function(event) {
        this.search(this.sender);
    },

    search : function(searchTerm) {

        if (this.searchBox.searchMode != kQuickSearchSenderOrSubject) {
            this.subjectOrSenderMenu.click();
        }

        this.searchBox.focus();
        this.searchBox.value = searchTerm;
        gSearchInput.clearButtonHidden = false;
        onSearchInput(true);
    }


};

window.addEventListener("load", function(event) { SearchForSender.onLoad(event); }, false);