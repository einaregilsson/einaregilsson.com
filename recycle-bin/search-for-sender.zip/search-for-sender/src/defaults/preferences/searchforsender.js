pref("extensions.searchforsender.debug", false);

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.searchforsender@einaregilsson.com.description", "chrome://searchforsender/locale/searchforsender.properties");