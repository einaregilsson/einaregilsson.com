[this is the original page http://tech.einaregilsson.com/projects/search-for-sender/]

This was done as a request for someone on the Mozillazine forums. The extension 
adds two items to the threadpane context menu, �Search for this sender� and 
�Search for this subject�. This basically takes the sender or subject of the 
selected message, copies it to the QuickSearch window and starts the search. 
Useful for filtering out all messages in a thread, or all messages from a 
sender.

Works with: Thunderbird: 1.5 � 2.0.0.*
Latest version: 1.0


VERSION HISTORY

Version 1.0 � December 1st, 2007

  Small bugfix so that the blue clear button appears in the search box when 
  searching.

  Also bumped version number to 1.0 since this is feature complete, there won�t 
  be any more work on this plugin.

Version 0.2 � April 11, 2007

  This is just an update to make it work with Thunderbird 2.0, it has no new 
  features.

Version 0.1.1 � November 12, 2006

  Three things I haven�t been able to fix in this version:

  1. When the quick search is set to something other than �Subject or Sender� I 
     set it to that before searching. However, the checkmark on the menu is not 
     updated.

  2. I tried to make the �Search for this subject� disabled when the subject 
     was empty, or only consisted of Re: Fwd: marks. However, setting the 
     menuitem.disabled property to true didn�t seem to work, I don�t know why.

  3. I wanted to put the menuitems after the �Open message in new window� item, 
     but the insertafter attribute didn�t work for some reason.

  These things will probably be fixed in the next version.



COMMENTS

###############################################################################

  Thomas Cook | 21 Sep 2007 12:19 am

  Fantastic idea for an add-on, but I get an invalid file hash when I try to 
  install it - both here and on the mozilla.org site. Is the xpi file corrupt?

###############################################################################

  Thomas Cook | 21 Sep 2007 12:21 am

  I should mention that I�m using Thunderbird 1.5.0.9.

###############################################################################

  einar | 21 Sep 2007 9:30 am

  Hi

  I haven�t tested version 0.2 with 1.5 but I didn�t think it would matter 
  because all I changed was the supported version. But try one thing, goto
  https://addons.mozilla.org/en-US/firefox/addons/versions/3851 and try 
  installing the older version, 0.1. I know that worked for me when I had TB 
  1.5 so it should work for you. There are no functional differences between 
  0.1 and 0.2. Let me know how it goes, I might have to change the supported 
  version for 0.2

###############################################################################

  adrian | 25 Apr 2008 8:38 am

  Any chance on a update for this on thunderbird2 ?

###############################################################################

  adrian | 25 Apr 2008 8:39 am

  As in, I�m currently using 2.0.0.12

###############################################################################

  einar | 25 Apr 2008 7:05 pm

  The extension used to work for 2.0.*. Did it stop working when you upgraded 
  to .12 or has it never worked for you? I don�t use Thunderbird myself anymore 
  so I haven�t tested in a while.

###############################################################################

  Stefano | 16 Jan 2009 9:55 am

  Hi,
  I�m using it and I found that it works very well but I would like to propose 
  to change the replacement for subject identifier for replies ecc. including 
  also: �R:� and �I:� (without quotes). The line I�m referring to is this:

  this.subject = this.subject.replace(/^(Re:|fwd:|fw:|spam-low:|out of office autoreply:|\s|\[)*/i, ��);

###############################################################################

  Werner | 04 Mar 2009 2:10 pm 

  Hello,

  nice tool but a little bit to accurate

  FRITZ!Box Telefaxempfang: Neues Telefax von 0123456789

  FRITZ!Box Telefaxempfang: Neues Telefax von unbekannt

  FRITZ!Box Push Service vom 02.03.2009
  FRITZ!Box Push Service vom 03.03.2009
  FRITZ!Box Push Service vom 04.03.2009

  do you see what I mean, would be nice to reduce accuracy for subject as an 
  definable option. The same for sender searching for the same domain would be 
  great too. All beside an accurate search.

  Best regards
  Werner

###############################################################################

  Jimmy | 11 Jun 2009 3:16 am

  Einar,

  Thank you for this one. Exactly what i am looking for.

  How can we get this work on TB3?

  I bumped the MaxVersion and it installed but I dont get any ContextMenu 
  items.

  Of all the bazillion of useless Search crap, I would have to see this one 
  die. Please attend.

###############################################################################
