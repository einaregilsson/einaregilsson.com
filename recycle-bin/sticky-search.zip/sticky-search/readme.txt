[this is the original page http://tech.einaregilsson.com/projects/sticky-search/]

This was done as a request for someone on the Mozillazine forums.

Makes the quick search �sticky�, i.e. repeats the last quicksearch when you 
switch to another folder. This turns the quick search box into more of a filter
than a search, it will keep searching every folder you switch to until you 
close the search. When switching folders the text in the searchbox is selected 
so it�s easy to erase it to quit filtering on the search phrase.

Works with: Thunderbird: 2.0 � 2.0.0.*
Latest version: 0.9


VERSION HISTORY

Version 0.9 � May 6, 2007

  Initial version. Future plans include adding a tac icon to the search box to 
  choose if the search is sticky or not.



COMMENTS

###############################################################################

  jon green | 27 Oct 2007 8:21 pm

  thanks for this extension - it makes the search box behave as I expected it 
  to!

  jon
  
###############################################################################

  Stefan | 13 Feb 2008 11:20 pm

  Just what I�ve been looking for! Thanks!
   
###############################################################################
   
  Superb work! | 19 Jun 2008 6:28 pm

  I�m using this combined with �search for sender� addon to look for 
  �conversations� (ie subject �AAABBB� in inbox, then in my sent items, it 
  picks up �RE:AAABBB,� and so on).

  It�s my way of implementing the �Find related messages� feature in Outlook. 
  There�s a few more clicks than Outlook, but it�s still a LOT better than 
  nothing.

  Thanks!

###############################################################################

  Manfred | 05 Jul 2008 7:38 pm

  Hello Einar,

  I have been looking around the mozilla web site for add-ons to help me find 
  and organize mail. I like and understand the concept of your Sticky Search 
  and it works in conjunction with the little search window (top right side of 
  icon bar) that came installed automatically with the latest US version 
  2.0.0.14.
  
  ((As a side point: I am confused about the searchbar-0.1-tb add-on 
  (https://addons.mozilla.org/en-US/thunderbird/addon/5270) where the author 
  says that in version 2 the bar was omitted. Do you know what he means? Is his
  bar/window different?))

  However, I don�t understand what �quicksearch� is and does. Do I need to 
  install a separate quicksearch add-on? Does such an add-on give me more 
  functionality? Which one?

  Your Sticky Search concept is great! For example, looking for �herbalife� in 
  the body of messages, I can find the messages by clicking on the various 
  folders.

  The only thing I can�t find in the message is the location where �herbalife� 
  appears. Is there something to do this?

  Thank you for a good idea and for your reply, Manfred (in Chile)
  
###############################################################################
  
  einar | 06 Jul 2008 10:04 pm

  Hi Manfred

  What I call the quick search is just the normal search box that you are 
  talking about. I don�t remember why I called it that, probably saw it called 
  that somewhere else. There is currently no way to see where in a message the 
  search phrase appears, although that might be a nice feature.

###############################################################################
