[this is the original page http://tech.einaregilsson.com/projects/sneak-peek/]

Sneak Peek is an extension for Mozilla Firefox that allows you to preview 
information from link targets by hovering over hyperlinks on a webpage. Unlike 
other preview extensions (Cooliris etc.) the Sneak Peek extension does not show
preview on all links, and it does not show a preview of the entire link target 
page. Instead the extension uses little snippets of code, so-called Sneak Peek 
Scripts, that define for which pages you want to see a preview, and precisely 
which part of the link target you want to preview. The extension was built to 
generalize an old Greasemonkey script I had written, that allowed you to hover 
over links in the Joel on Software message boards, and see the first post in 
the thread in a preview box. After getting used to having the functionality on 
that message board I started missing it on other message boards I use so I 
created this extension so I could easily create previews for any message board.
Although the extension was mainly made to preview posts in message boards it 
can be used for any case where you want to preview only a specific part of a 
link target, I use it for example to preview comments on my blog page by 
hovering over the comments link.

Detailed information about how this works, and how to create scripts can be 
found in the help file included with the extension and also available here.

Works with Firefox: 3.0 � 3.5.*
Latest version: 0.9.2

[Following scripts are available in the scripts folder]

  Sneak Peek Scripts
  CrazyOnTap discussion forums
  Joel on Software discussion forums
  Mozillazine discussion forums
  AddonsMirror discussion forums
  mbl.is blog entry preview
  140conf.com twitter links preview (by Sara Streeter)
  RedFlagDeals Forums (by RenegadeX)


VERSION HISTORY

Version 0.9.2 � July 10th, 2008

 Fixed problem with installing scripts from local files.

Version 0.9.1 � July 9th, 2008

  Fixed two errors:
    * Edit newly created add-on now works normally
    * When items are deleted the edit button goes blank.

Version 0.9 � July 4th, 2008

  First beta version. Will upgrade to 1.0 when the extension becomes public.



COMMENTS

###############################################################################

  RenegadeX | 10 Jul 2008 7:34 pm

  I have a bit of regexp experience but don�t find it easy, and after a dozen
  or so failed attempts at creating my first SP, and not knowing which of my 3
  regex lines were wrong (or if it was all 3!), I eventually got it working. I
  had thought perhaps I needed to add a regexp to match whatever came after 
  the �.php?� in the URL(such as �searchid=1234? or �t=54321?), and but
  eventually came to realize that no, it�s not needed! And for that, I�m glad!!

  Then I realized that I often use the �show new posts� button on forums rather
  than visit each subforum individually, so I had to include an either|or exp
  for the 2 different php files that the forum software uses. Got that working
  too, but in total it probably took me 20 minutes to make 1 SP script.

  A little bit of automation or visual validation during the generating process
  would definitely help. I resorted to using 
  http://www.regular-expressions.info/javascriptexample.html to test the 
  validity of my expressions, and had to refer to the SP scripts you�ve already
  posted to find out what I should be looking for for the �Peek pattern�.

  I also can�t seem to install my SP script via dragging the plain-text text
  file saved as whatever.sp into my browser. It recognizes that it�s a SP file,
  but then always gives me a �Failed to download script!� message. I suspected
  it might be something to do with character encoding, but I�ve tried saving
  the file in a number of formats (inc UTF-8, w/wo BOM) and no luck. Any idea
  what could be wrong with it?

  �
  @@SneakPeek
  name : RedFlagDeals Forums
  author : RenegadeX
  sitePattern : http://www\.redflagdeals\.com/forums/(search\.php|forumdisplay\.php)
  linkPattern : http://www\.redflagdeals\.com/forums/showthread\.php\?t=[0-9]+
  peekPattern : [^]*?
  �

###############################################################################

  RenegadeX | 10 Jul 2008 7:38 pm

  ^ oh, my peekPattern apparently got mangled when I hit �Send� just now �
  apparently WordPad doesn�t like less-than and greater-than signs and
  disregards whatever is between them.

  I�ll just email it to you.

###############################################################################

  einar | 10 Jul 2008 9:18 pm

  Hi RenegadeX

  Nice to know someone is using it :)

  I�ve added a new version, 0.9.2, that works correctly on local files. I
  thought the old one did already, but testing it after getting your comment I
  realized that it didn�t work at all.

  I couldn�t install the script you sent me, after a while I figured out it was
  because it was missing the url: line. It�s required to be there, even though
  you don�t specify any url. The parsing is a bit sensitive ;) Anyway, I put
  your script upon my site, giving you credit for it of course, so others can
  download it.

  As for having trouble creating scripts, yes, it can be pretty annoying. Some
  tips, tricks and future ideas:

    * Go to about:config and set extensions.sneakpeek.debug to true. Then
      you�ll see some debug output in the error console that might help you a 
      little bit, saying how many links were set up with event handlers and so
      on. I don�t remember exactly how much is printed, it was meant as a
      debugging aid, not for public use. (In about config you can also mess 
      with the css for the preview if you want).

    * Read the help file, available from the help button in the options dialog.
      It has some tricks (not a lot), such as using [^]*? for content.

    * An idea I had was to build some kind of tester. You could enter an
      example site url and it would tell you something like �Site pattern xxx
      matched the example url, link pattern found n links on that page that
      were set up with previews, the first of those gives the following
      preview: xxxxxx�. So you could build it up gradually, first making sure
      that the site pattern matched, then checking how many links were matched
      and finally seeing the content found from the first links� preview. But
      that might be a while away, I probably won�t work much on this extension
      for at least 2-3 weeks.

  And if you�re a member at addons.mozilla.org I�d really appreciate if you�d
  leave a review for the extension :)
 
###############################################################################

  RenegadeX | 18 Jul 2008 5:17 am

  Hi again. I just sent you an email with some ideas, but I thought the
  following might be useful to share with other users:

  In �about:config�, I edited my �extensions.sneakpeek.previewStyle� and gave
  my popup box a different colour(pale yellow), changed the font size, made the
  box wider, and centred the box on my screen as I noticed that sometimes if my
  mouse was too far to the right side of the screen, the popup would get cut
  off.

  (My screen�s resolution is 1152�864 so as I made my popup box 650px, I
  calculated: (screenwidth � boxwidth) / 2 and put the resulting number (251)
  as a �left: � positioning value)

  So here�s what I�m currently using:
  �
  position:absolute! important; 
  left: 251px! important; 
  background-color:#FFFFE1 ! important; 
  border:solid 1px black! important; 
  padding:3px ! important; 
  color:black ! important; 
  width:650px ! important; 
  font-family:Arial, sans-serif ! important; 
  font-size:11px ! important; 
  display:none
  �

  It�s pretty simple to play around with the various style settings, but I
  wonder if there is enough interest for a style-picker built in to the Sneak 
  Peek Options (colour palette, font chooser, width changer, re-positioner, � 
  and preview button).

  I mentioned it to Einar already, but in my first post I had said using the
  pipe symbol (shift+backslash) was good because it allowed the Sneak Peek to
  be applied to various different forum pages that a user might access.
  However, even easier is a simple wildcard �*� (ex: ..com/forums/*)

  Also if anyone has a forum they�d like a script for but doesn�t know how,
  post here and I�ll see what I can do!
  
###############################################################################

  RenegadeX | 20 Jul 2008 7:12 pm

  oops.. I just tried installing the code I wrote above on a friend�s computer
  and noticed that it didn�t work due to an extra space between the �left:� and
  �251px�.
 
  I fixed some other unnecessary spaces in it too: Here, try this:

  position:absolute !important; 
  left:251px !important; 
  background-color:#FFFFE1 !important; 
  border:solid 1px black !important; 
  padding:3px !important; 
  color:black !important; 
  width:650px !important; 
  font-family:Arial, sans-serif !important; 
  font-size:11px !important; 
  display:none
  
###############################################################################

  Val001 | 15 Nov 2008 9:19 pm

  Hello,

  SneakPeek is a great tool!

  It works nice, especially on well-structured sites.
  I was able to program it for fast show of all Job Descriptions from Dice,
  works like a charm! You just point on a job line and see description body in
  pop-up window without noise information like headers, adds and so on.

  Thank you EINAR!

###############################################################################

  John | 03 Mar 2009 7:30 pm

  Awesome extension.

  Anyway to keep it up and not just on mouse over?

  John

###############################################################################

  redditUser | 04 May 2009 6:55 am

  how about a script for use on http://redditall.com

  I�m generally familiar with regEx but am no expert and can�t seem to figure
  it out. Thanks!

###############################################################################

  einar | 04 May 2009 8:46 am

  @redditUser: Well, what do you want to display? The stories or the comments?
  I can�t write a script to display the stories since every link points to a
  different site, and there�s no regex that could fit them all. If you want a
  preview of some comments that could be doable.

###############################################################################

  Sara Streeter | 08 Jun 2009 6:43 pm

  I used this add-on to create a twitter preview for the 140 Characters
  conference page which had a huge list of people with their twitter links.

  Name: 140 Characters Conference � Twitter
  Author: Sara Streeter
  Author URL: http://www.sarastreeter.com
  sitePattern : ^http://www\.140conf\.com.*
  linkPattern : ^http://twitter.com/\w+
  peekPattern : <ol class=�statuses�[^]*?</ol>

  I tried to get previews of content divs in websites as well, but couldn�t
  manage to make a generic enough regex that would still load quickly. The
  twitter works very well though � thanks so much!

  Sara

###############################################################################

  einar | 22 Jun 2009 7:01 am

  @Sara Streeter: I have added your script as a link on the page, thanks.

###############################################################################
