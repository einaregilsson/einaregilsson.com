/**
 * $Id: scriptinstall.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $
 * Licensing information: GPL, See license.txt for more information
 *
 * The UI logic for installing scripts is here, the actual saving of 
 * the file to the script folder is done by the SneakPeek component.
 */


/**
 * Checks whether the currently loaded file is an sp script and prompts the
 * user to install it.
 */
function checkInstall() {
    var spstrings = document.getElementById('sneakpeek-strings');

    function s(key, value) {
        if (value) {
            return spstrings.getFormattedString(key, [value]);
        } else {
            return spstrings.getString(key);
        }
    }

    var url = window.content.document.location.href;

    if (url.endsWith('.sp')) {

        var pre = window.content.document.getElementsByTagName('pre')[0];

        if (pre && pre.innerHTML.startsWith('@@SneakPeek')) {

            var install = SPLib.confirmYesNo(s('name'), s('install.question'));
            if (install) {
                
                var uri = SPLib.newURI(url);
                var newFilename = uri.spec.substr(uri.spec.lastIndexOf('/')+1);
                var scriptText;
                if (uri.scheme == 'file') {
                    try {
                        scriptText = SPLib.getFileLines(SPLib.getFileFromURLSpec(uri.spec)).join('\n');
                    } catch(ex) {
                        SPLib.msgBox(s('name'), s('install.failed') + '\n\n' + ex.message);
                        return;
                    }                
                } else {
                    //Use xml http request to get raw source
                    var req = new XMLHttpRequest();
                    req.open('GET', url, false);
                    req.send(null);

                    if (req.status != 200) {
                        SPLib.msgBox(s('name'), s('install.failed'));
                        return;
                    }
                    scriptText = req.responseText;
                }
                

                function promptOverwrite(filename) {
                    return SPLib.confirmYesNo(s('name'), s('install.overwrite', filename));
                }
                 
                try {
                
                    var result = sneakpeek.installScript(scriptText, newFilename, promptOverwrite);
                    if (result == sneakpeek.NO_OVERWRITE) {
                        SPLib.msgBox(s('name'), s('install.cancelled'));
                    } else {
                        SPLib.msgBox(s('name'), s('install.success', result));
                    }
                } catch(e) {
                    SPLib.msgBox(s('name'), s('install.installNoParse'));
                }

            } else {
                SPLib.msgBox(s('name'), s('install.cancelled'));
            }
        }
    }
}
