/**
 * $Id: splib.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $
 * Licensing information: GPL, See license.txt for more information
 *
 * Library of common utility function, no extension specific code here
 * except the initialization line at the bottom of the file.
 */

var SPLib = {

    /* Private variables */
    _ext        : null,
    _cout       : null,
    _prefBranch : null,

    /**
     * Initializes the library with extension specific data.
     */
    initialize : function(extension) {
        this._ext = extension;
        this._cout = Cc["@mozilla.org/consoleservice;1"].getService(Ci.nsIConsoleService);
        this._initPrefs();
    },

    /**
     * Outputs the given string to the error console
     * if debug output is enabled.
     */
    debug : function(str) {
        if (this._ext.prefs.debug) {
            this._cout.logStringMessage("%1: %2"._(this._ext.name, str));
        }
    },

    /**
     * Prints all members of an object to the error console 
     * if debug output is enabled.
     */
    debugObject : function(name, obj) {
        s = name + ': ';
        try {
            for (x in obj) {
                s += "\n\t%1 : %2"._(x, obj[x]);
            }
            this.debug(s);
        } catch(e) {
            this.debug('Failed to debug object ' + obj);            
        }
    },

    /**
     * Adds all prefs to a prefs object on the extension object, and registers
     * a pref observer for the branch.
     */
    _initPrefs : function() {

        this._prefBranch = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService)
                                .getBranch("extensions.%1."._(this._ext.id.split("@")[0]));
        this._ext.prefs = {};

        var list = this._prefBranch.getChildList("", {}).toString().split(",");

        for each(var name in list) {

            var type = this._prefBranch.getPrefType(name);

            if (type == this._prefBranch.PREF_STRING) {
                this._ext.prefs[name] = this._prefBranch.getCharPref(name);
            } else if (type == this._prefBranch.PREF_INT)  {
                this._ext.prefs[name] = this._prefBranch.getIntPref(name);
            } else if (type == this._prefBranch.PREF_BOOL) {
                this._ext.prefs[name] = this._prefBranch.getBoolPref(name);
            }
        }
    },

    /* Gets char pref from extension branch. */
    getCharPref : function(branch) {
        return this._prefBranch.getCharPref(branch);
    },

    /* Gets bool pref from extension branch. */
    getBoolPref : function(branch) {
        return this._prefBranch.getBoolPref(branch);
    },

    /* Gets int pref from extension branch. */
    getIntPref : function(branch) {
        return this._prefBranch.getIntPref(branch);
    },

    /* Gets the folder where the extension is installed. */
    getExtensionFolder : function() {
        return Cc["@mozilla.org/extensions/manager;1"]
                .getService(Ci.nsIExtensionManager)
                    .getInstallLocation(this._ext.id)
                        .getItemLocation(this._ext.id);

    },

    /* Gets the value of an environment variable. */
    getEnvVar : function(name) {
        return Cc["@mozilla.org/process/environment;1"]
                .getService(Ci.nsIEnvironment)
                    .get(name);

    },

    /* Sets the value of an environment variable. */
    setEnvVar : function(name, value) {
        return Cc["@mozilla.org/process/environment;1"]
                .getService(Ci.nsIEnvironment)
                    .set(name, value);

    },

    /** 
     * Finds all nodes in the current document that have an 'id' attribute and
     * declares global variables with the same name so they can be easily accessed.
     */
    declareAllVariables : function() {
        for each(var node in document.getElementsByAttribute('id', '*')) {
            if (node.id) {
                window[node.id] = node;
           }
        }
    },

    /**
     * Reads all lines from the given file and returns an array with 
     * the lines.
     */
    getFileLines : function(file) {
        // open an input stream from file
        var istream = Components.classes["@mozilla.org/network/file-input-stream;1"]
                                .createInstance(Components.interfaces.nsIFileInputStream);
        istream.init(file, 0x01, 0444, 0);
        istream.QueryInterface(Components.interfaces.nsILineInputStream);

        // read lines into array
        var line = {}, lines = [], hasmore;
        do {
            hasmore = istream.readLine(line);
            lines.push(line.value); 
        } while(hasmore);

        istream.close();
        return lines;
    },
   
    /**
     * Creates a nsIUri object from an url string.
     */
    newURI : function(url) {
        return Cc["@mozilla.org/network/io-service;1"].getService(Components.interfaces.nsIIOService).newURI(url, null, null);
    },
    
    /**
     * Returns a nsIFile object from a file url.
     */
    getFileFromURLSpec : function(url) {
        return Cc["@mozilla.org/network/protocol;1?name=file"].getService(Ci.nsIFileProtocolHandler).getFileFromURLSpec(url);
    },
    
    /* Pops up a message box with the given title and text */
    msgBox : function(title, text) {
        Cc["@mozilla.org/embedcomp/prompt-service;1"]
            .getService(Ci.nsIPromptService)
                .alert(window, title, text);
    },

    /* Pops up a confirmation dialog with the given title and text */
    confirm : function(title, text) {
        return Cc["@mozilla.org/embedcomp/prompt-service;1"]
            .getService(Ci.nsIPromptService)
                .confirm(window, title, text);
    },
    
    /* Pops up a confirmation dialog with Yes/No buttons, and the given title and text */
    confirmYesNo : function(title, text) {
        var ps = Cc["@mozilla.org/embedcomp/prompt-service;1"].getService(Ci.nsIPromptService);

        var selected = {};
        return !ps.confirmEx(window, title, text, ps.STD_YES_NO_BUTTONS, null, null, "Yes", null, {});
    },

    /**
     * Returns the pattern from within a regular expression,
     * without the leading and trailing / and /gi.
     */
    regex2string : function(rx) {
        var str = rx.toString();
        str = str.substr(1, str.lastIndexOf('/')-1);
        return str.replace(/\\\//g, '/');
    },

    /**
     * Saves 'content' to file 'filepath'. Note that filepath needs to
     * be a real file path, not a chrome path.
     */
    saveToFile : function(filepath, content) {
        var file = this.getFile(filepath);

        if (!file.exists()) {
            file.create(Ci.nsIFile.NORMAL_FILE_TYPE, 420);
        }
        var outputStream = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);

        outputStream.init( file, 0x04 | 0x08 | 0x20, 420, 0 );
        var result = outputStream.write( content, content.length );
        outputStream.close();
    },

    /**
     * Launches a process with the given filename and command line arguments.
     */
    startProcess: function(filename, args) {

        var file = this.getFile(filename);

        args = args ? args : [];

        if (file.exists()) {
            var nsIProcess = Cc["@mozilla.org/process/util;1"].getService(Ci.nsIProcess);
            nsIProcess.init(file);
            nsIProcess.run(false, args, args.length);
        } else {
            throw Error("File '%1' does not exist!"._(filename));
        }
        
    },
   
    /* Launches a file, same effect as doubleclicking it. */
    launchFile : function(filepath) {
        var f = this.getFile(filepath);
        f.launch();
    },


    /* Gets a local file reference, return the interface nsILocalFile. */
    getFile : function(filepath) {
        var f = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
        f.initWithPath(filepath);
        return f;
    },

    /**
     * Returns all elements that match the query sent in. The root used
     * in the query is the window.content.document, so this will only
     * work for html content.
     */
    xpath : function(doc, query) {
        return doc.evaluate(query, doc, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
    }
};

//************** Some prototype enhancements ************** //

/* Shortcuts to avoid typing long lines */
try {
    Cc = Components.classes;
    Ci = Components.interfaces;
} catch(e) {}

/* Returns true if the string contains the substring str. */
String.prototype.contains = function (str) {
    return this.indexOf(str) != -1;
};

/* Trims whitespace from beginning and end of string. */
String.prototype.trim = function() {
    return this.replace(/^\s*|\s*$/gi, '');
};

/* Returns true if the string starts with the given substring. */
String.prototype.startsWith = function(s) {
    return (this.length >= s.length && this.substr(0, s.length) == s);
};

/* Returns true if the string ends with the given substring. */
String.prototype.endsWith = function(s) {
    return (this.length >= s.length && this.substr(this.length - s.length) == s);
};

/**
 * Inserts the arguments into the string. E.g. if
 * the string is "Hello %1" then "Hello %1"._('johnny')
 * would return "Hello johnny".
 */
String.prototype._ = function() {
    var s = this;
    for (var i = 0; i < arguments.length; i++) {
        var nr = "%" + (i+1);
        var repl;
        if (arguments[i] == null) {
            repl = "null";
        } else if (arguments[i] == undefined) {
            repl = "undefined";
        } else {
            repl = arguments[i];
        }
        s = s.replace(new RegExp(nr, "g"), repl);
    }
    return s;
};

//Initialize the library with extension specific values.
SPLib.initialize({name:'SneakPeek', id:'sneakpeek@einaregilsson.com'});
