/**
 * $Id: sneakpeekscript.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $ 
 * Licensing information: GPL, See license.txt for more information
 *
 * A class for a single script.
 */

function SneakPeekScript(name, author, url, sitePattern, linkPattern, peekPattern) {
    this.name = name || '';
    this.author = author || '';
    this.url = url || '';
    this.sitePattern = sitePattern || '';
    this.linkPattern = linkPattern || '';
    this.peekPattern = peekPattern || '';
}

SneakPeekScript.prototype = {

    /**
     * Returns a string representation of the object. This is
     * the same as the text should be in a script file.
     */
    toString : function() {
        return "@@SneakPeek\n"
        + "name : " + this.name + "\n"
        + "author : " + this.author+ "\n"
        + "url : " + this.url + "\n"
        + "sitePattern : " + SPLib.regex2string(this.sitePattern) + "\n"
        + "linkPattern : " + SPLib.regex2string(this.linkPattern) + "\n"
        + "peekPattern : " + SPLib.regex2string(this.peekPattern) + "\n";
    },
    
    /** 
     * Loads the object from a file. Throws errors
     * if the file is not a well formed script.
     */
    loadFromFile : function(path) {
        var file = SPLib.getFile(path);
        this.loadFromLines(SPLib.getFileLines(file));    
        this.filename = file.leafName;
        SPLib.debug('set name to ' + this.filename);
    },
    
    /** 
     * Loads the object from the given text. Throws errors
     * if the text is not a well formed script.
     */
    loadFromText : function(text) {
        this.loadFromLines(text.split('\n'));
    },
    
    /** 
     * Loads the object from the given array of strings. Throws errors
     * if the lines are not what is expected.
     */
    loadFromLines : function(lines) {

        if (lines.length < 7) {
            throw Error("Sneak Peek file should have at least 7 lines!");
        }

        if (lines[0].replace(/^\s*|\s*$/gi, '') != '@@SneakPeek') {
            throw Error("Sneak Peek file must start with @@SneakPeek!");
        }

        var exp = ['', 'name', 'author', 'url', 'sitePattern', 'linkPattern', 'peekPattern'];
        for (var i = 1; i <= 6; i++) {
            var rx = RegExp('^' + exp[i] + '\\s*:\\s*(.*)');
            if (!rx.exec(lines[i])) {
                throw Error('Invalid data in line ' + i + ', expected ' + exp[i] + ': <data>');
            }

            if (i < 4) {
                this[exp[i]] = RegExp.$1;
            } else  { //Last three are regexes
                this[exp[i]] = new RegExp(RegExp.$1, 'gi');
            }
        }

        if (lines.length > 7) {
            SPLib.debug('Lines are too many, extra lines will be ignored');
        }
    },
    
    /**
     * Saves the object to a file in the given scriptFolder, which is
     * an nsIFile instance.
     */
    saveToFile : function(scriptFolder) {
        var newfile = SPLib.getFile(scriptFolder.path);
        newfile.append(this.filename);
        SPLib.saveToFile(newfile.path, this.toString());
    }
}

