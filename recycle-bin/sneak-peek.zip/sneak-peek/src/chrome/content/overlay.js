/**
 * $Id: overlay.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $
 * Licensing information: GPL, See license.txt for more information
 *
 * Code for listening for load events, inserting html, getting the
 * preview pages is stored here.
 */

/**
 * Wrapper function, all other functions are declared inside it so they're
 * invisible to other extensions.
 */
window.addEventListener("load", function(event) { //Start onload handler

    if (event.target != window.document) {
        return;
    }
    window.sneakpeek = Cc["@einaregilsson.com/sneakpeek;1"].getService(Ci.nsISupports).wrappedJSObject;
/**
 * Initializes the extension on startup, reading in the preview files and 
 * setting up event handlers.
 */
function initialize() {
    document.getElementById('appcontent').addEventListener('pageshow', contentLoaded, false);
    document.getElementById('appcontent').addEventListener('pagehide', cleanUp, false);
}

/**
 * Event handler for content document loaded. Checks if the url
 * matches any sitePattern and if so, creates the preview node and
 * adds event handlers to all links matching the linkPattern.
 */
function contentLoaded(event) {

    if (event.originalTarget != window.content.document) {
        return;
    }
    
    checkInstall();

    var currentUrl = window.content.document.location.href;
    for each (var script in sneakpeek.scripts) {
        if (currentUrl.match(script.sitePattern)) {
            SPLib.debug('Found match for url ' + currentUrl + ', it is "' + script.name + '"');
            window.content.spScript = script;
            setupPreviewNode();
            setupPreviewEventHandlers();
            return;
        }
    }
}

/**
 * Event handler for the 'pagehide' event. Removes the preview
 * node so that it isn't stuck on the page if we later press
 * back to go back to it.
 */
function cleanUp(event) {

    if (event.originalTarget != window.content.document) {
        return;
    }
    
    var pnode = window.content.previewNode;
    if (pnode) {
        pnode.parentNode.removeChild(pnode);
    }
}


/**
 * Adds event handlers to all links matching the linkpattern and
 * removes title attributes so they won't interfere.
 */
function setupPreviewEventHandlers() {
    var links = window.content.document.getElementsByTagName('a');
    var x = 0;
    for (var i in links) {
        var link = links[i];
        if (link.href && link.href.match(window.content.spScript.linkPattern)) {
            x++;
            link.addEventListener("mouseover", getPost, true);
            link.addEventListener("mouseout", clearPost, true);
            link.title = "";
        }
    }
    SPLib.debug('Added ' + x + ' handlers for mouseover');
}


/**
 * Adds the preview node to the content document
 */
function setupPreviewNode() {
    var cwin = window.content;
    cwin.previewCache = {};
    cwin.currentPreviewUrl = "";
    cwin.previewNode = cwin.document.createElement("div");

    cwin.previewNode.setAttribute("style",SPLib.getCharPref('previewStyle'));
    cwin.document.getElementsByTagName("body")[0].appendChild(cwin.previewNode);
}


/* Sets the position of the preview node */
function setPos(x, y) {
    var pnode = window.content.previewNode;
    if (pnode) {
        pnode.style.top = (y+20) + 'px';
        pnode.style.left = x + 'px';
    }
}

/**
 * Waits for half a second, then gets the page of the link thats being
 * hovered over and displays the preview node at the correct location.
 */
function getPost(event) {

    var linkUrl = event.target.toString();
    var link = event.target;
    var cwin = window.content;
    cwin.currentPreviewUrl = linkUrl;
    var text;
    for (var x = 0, y = 0;  link.offsetParent; link = link.offsetParent) {
        x += link.offsetLeft;
        y += link.offsetTop;
    }

    if (text = cwin.previewCache[linkUrl]) {
        SPLib.debug("Cache hit for " + linkUrl);
        setPos(x, y);
        cwin.previewNode.innerHTML = text;
        cwin.previewNode.style.display = "";
        cwin.currentPreviewUrl = linkUrl;
    } else {
        SPLib.debug("Cache miss for " + linkUrl);
        //Only get pages if the mouse is over them for more than 0.5 seconds.
        setTimeout(function() {
            if (cwin.currentPreviewUrl != linkUrl) {
                SPLib.debug("Mouseout has fired for " + linkUrl + ", don't get page");
                //alert('fail ' + 'pre: ' + cwin.currentPreviewUrl + ' link: ' + linkUrl);
                return;
            }
            var req = new XMLHttpRequest();
            
            req.onload = function(event) {

                if (req.status != 200) {
                    alert("Failed to load preview, message is: " + req.status + " " + req.responseText);
                    return;
                }

                cwin.spScript.peekPattern.lastIndex = 0;
                cwin.previewCache[linkUrl] = cwin.spScript.peekPattern.exec(req.responseText);;

                //Only show if the mouseout event hasn't fired
                if (cwin.currentPreviewUrl == linkUrl) {
                    setPos(x, y);
                    cwin.previewNode.innerHTML = cwin.previewCache[linkUrl];
                    cwin.previewNode.style.display = "";
                } else {
                    SPLib.debug("Skipping set text for " + linkUrl + ", mouseout has fired");
                }
            }
            
            req.open('GET', linkUrl);
            SPLib.debug('requesting ' + linkUrl);
            req.setRequestHeader("User-Agent", "Mozilla/4.0 (compatible) (Sneak Peek)");
            req.send(null);

        }, 500); //end setTimeout

    }

}

/* Hides the preview node */
function clearPost(event) {
    var cwin = window.content;
    cwin.previewNode.style.display = "none";
    cwin.currentPreviewUrl = "";
}


//Start the initialization
initialize();

}, false); //End onload handler

/**
 * Opens the SneakPeek options window. This function is declared outside the load
 * event handler since it needs to be visible to the overlay.xul. For the same reason
 * we use the sp_ prefix, so we don't accidentally overwrite some other extensions
 * (or Firefox's) options function.
 */
function sp_options() {
        var windowName = "sneakPeekOptions";
        var windowsMediator = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
        var win = windowsMediator.getMostRecentWindow(windowName);
        if (win) {
            win.focus();
        } else {
            window.openDialog("chrome://sneakpeek/content/options.xul",
                    windowName,
                    "chrome,dialog,resizable=no,centerscreen", this);
        }
    
}