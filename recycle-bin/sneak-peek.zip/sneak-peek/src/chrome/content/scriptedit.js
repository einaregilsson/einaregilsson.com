﻿/**
 * $Id: scriptedit.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $ 
 * Licensing information: GPL, See license.txt for more information
 *
 * All code for the script edit dialog is here.
 */

/**
 * Event handler for the 'load' event. Loads up necessary data,
 * and does other initialization tasks.
 */
function onLoad(event) {
    SPLib.declareAllVariables();
    window.sneakpeek = Cc["@einaregilsson.com/sneakpeek;1"].getService(Ci.nsISupports).wrappedJSObject;
    window.script = window.arguments[0];

    txtName.value = script.name;
    txtAuthor.value = script.author;
    txtAuthorURL.value = script.url;
    txtSitePattern.value = SPLib.regex2string(script.sitePattern);
    txtLinkPattern.value = SPLib.regex2string(script.linkPattern);
    txtPeekPattern.value = SPLib.regex2string(script.peekPattern);
}

/**
 * Displays an error message to the user.
 */
function error(msg) {
    SPLib.msgBox(spstrings.getString('name'), msg);
}

/**
 * Saves the script to the scripts folder and updates
 * it in the component.
 */
function save() {
    script.name        = txtName.value;
    script.author      = txtAuthor.value;
    script.url         = txtAuthorURL.value;

    if (!script.name.replace(/\s/g, '')) {
        error(spstrings.getString('error.noName'));
        txtName.focus();
        return false;
    }
    
    try {
        script.sitePattern = new RegExp(txtSitePattern.value, 'gi');
        if (txtSitePattern.value.replace(/^\s*|\s*$/g, '') == '') {
            throw Error("Cannot be null");
        }
    } catch (e) {
        error(spstrings.getFormattedString('error.sitePatternRegExp', [txtSitePattern.value]));
        txtSitePattern.focus();
        return false;
    }
    try {
        script.linkPattern = new RegExp(txtLinkPattern.value, 'gi');
        if (txtLinkPattern.value.replace(/^\s*|\s*$/g, '') == '') {
            throw Error("Cannot be null");
        }
    } catch (e) {
        error(spstrings.getFormattedString('error.linkPatternRegExp', [txtLinkPattern.value]));
        txtLinkPattern.focus();
        return false;
    }
    try {
        script.peekPattern = new RegExp(txtPeekPattern.value, 'gi');
        if (txtPeekPattern.value.replace(/^\s*|\s*$/g, '') == '') {
            throw Error("Cannot be null");
        }
    } catch (e) {
        error(spstrings.getFormattedString('error.peekPatternRegExp', [txtPeekPattern.value]));
        txtPeekPattern.focus();
        return false;
    }

    
    sneakpeek.installScript(script, script.filename, function() {return true;});
    script.saved = true;
    return true;
}
