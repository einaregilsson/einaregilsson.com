/**
 * $Id: options.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $ 
 * Licensing information: GPL, See license.txt for more information
 *
 * All code for the options dialog is here.
 */

/* Adds all the installed scripts to the listbox. */
function addItemsToListBox() {

    var newItem, script;

    for each (script in sneakpeek.scripts) {
        newItem = template.cloneNode(true);
        setItemValues(newItem, script);
        lstScripts.appendChild(newItem);
        newItem.setAttribute('selected', false);
    }
}

/* Sets values on listbox items. */
function setItemValues(item, script) {
    function set(name, val) {
        item.getElementsByAttribute('name', name)[0].setAttribute('value', val);
    }

    set('dscrName', script.name);
    set('dscrSitePattern', SPLib.regex2string(script.sitePattern));
    set('dscrLinkPattern', SPLib.regex2string(script.linkPattern));
    set('dscrPeekPattern', SPLib.regex2string(script.peekPattern));
    set('dscrAuthor', script.author);
    set('dscrAuthorURL', script.url);
    item.script = script;
}

/**
 * Event handler for the 'load' event. Loads up necessary data,
 * and does other initialization tasks.
 */
function onLoad(event) {
    try {
        SPLib.declareAllVariables();
        lstScripts.removeChild(template);
        window.sneakpeek = Cc["@einaregilsson.com/sneakpeek;1"].getService(Ci.nsISupports).wrappedJSObject;
        addItemsToListBox();
        SPLib.debug('Loaded');
    } catch(e) {
        alert(e);
    }
}

/* Opens a dialog to create a new script. */
function newScript() {
    //Must make the component create the object, otherwise we'll get weird
    //scoping issues.
    var script = sneakpeek.getEmptyScript();
    var result = window.openDialog("chrome://sneakpeek/content/scriptedit.xul",
                                   "scriptedit",
                                   "chrome,dialog,modal,centerscreen", script);
    if (script.saved) {
        var newItem = template.cloneNode(true);
        setItemValues(newItem, script);
        newItem.setAttribute('selected', false);
        lstScripts.appendChild(newItem);
        lstScripts.selectItem(newItem);
        lstScripts.scrollToIndex(lstScripts.getRowCount()-1);
    }
}

/* Opens a dialog to edit an existing script. */
function editScript() {

    var listItem = lstScripts.selectedItem;

    if (!listItem) {
        return;
    }

    var script = listItem.script;
    
    openDialog("chrome://sneakpeek/content/scriptedit.xul",
               "scriptedit",
               "chrome,dialog,modal,centerscreen", script);

    if (script.saved) {
        setItemValues(listItem, script);
    }
}

/* Deletes an existing script. */
function deleteScript() {
    var index = lstScripts.selectedIndex;

    if (index == -1) {
        return;
    }

    try {
        var script = lstScripts.children[index].script;
        var del = SPLib.confirmYesNo(spstrings.getString('name'), spstrings.getFormattedString('delete.script', [script.name]));
        if (del) {
            lstScripts.removeChild(lstScripts.children[index]);
            sneakpeek.deleteScript(script.filename);
            lstScripts.selectedIndex = -1;
        }
    } catch(e) {
        alert(e);
    }
}

/** 
 * Event handler for the 'select' event of the listbox. Enables and
 * disables buttons as appropriate.
 */
function onSelect(event) {
    //This is called before the load event, don't want that.
    if (!window.lstScripts) {
        return;
    }
    var disable = lstScripts.selectedIndex == -1;
    btnEdit.disabled = disable;
    btnDelete.disabled = disable;
}

/**
 * Opens a new window with the help file for Sneak Peek.
 */
function openHelp() {
    var windowName = "sneakpeekHelp";
    var windowsMediator = Cc["@mozilla.org/appshell/window-mediator;1"].getService(Ci.nsIWindowMediator);
    var win;
    var iter = windowsMediator.getEnumerator(null);
    while (iter.hasMoreElements()) {
        win = iter.getNext();
        if (win.name == windowName) {
            win.focus();
            return;
        }
    }
    window.openDialog("chrome://sneakpeek/locale/help.html", windowName, "chrome,dialog,resizable=yes,location=0,toolbar=0,status=0,width=800px,height=600px,centerscreen", this);
}
