/**
 * $Id: sneakpeekprefs.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $
 * Licensing information: GPL, See license.txt for more information
 */
 
//Enables debug output, will be shown in error console.
pref("extensions.sneakpeek.debug", false); 

//CSS rules for the preview div that shows the previews.
//Use ! important to override the host pages styles.
pref("extensions.sneakpeek.previewStyle", 
'position:absolute ! important; 
background-color:#ddd ! important; 
border:solid 1px black ! important; 
padding:3px ! important; 
color:black ! important; 
width:500px ! important; 
font-family:Arial, sans-serif ! important; 
font-size:12px ! important; 
display:none 
');

//How long in milliseconds we wait on mouseover
//before issuing a http request for the content.
pref("extensions.sneakpeek.hoverThreshold", 500);

//Localize the extension description.
pref("extensions.sneakpeek@einaregilsson.com.description", "chrome://sneakpeek/locale/sneakpeek.properties");