/**
 * $Id: sneakpeek.js 135 2008-07-04 21:53:11Z einar@einaregilsson.com $
 * Licensing information: GPL, See license.txt for more information
 *
 * This is the global SneakPeek component. It is meant to be used as a service,
 * so there is only ever one object that takes care of CRUD operations for
 * new scripts. This also helps to make changes made in one window appear
 * instantly in all others since they share the component.
 */
 
Components.utils.import("resource://gre/modules/XPCOMUtils.jsm");

function SneakPeek() {
    loadLibs();
    this.initialize();
}

/**
 * Loads the SPLib library so that we can use utility functions e.g. logging and
 * the SneakPeekScript library.
 */
function loadLibs() {
    var jsLoader = Components.classes["@mozilla.org/moz/jssubscript-loader;1"]
                      .getService(Components.interfaces.mozIJSSubScriptLoader);
    jsLoader.loadSubScript('chrome://sneakpeek/content/splib.js');
    jsLoader.loadSubScript('chrome://sneakpeek/content/sneakpeekscript.js');
    SPLib.debug('Logging with SPLIB');
}

SneakPeek.prototype = {

    classDescription : "Sneak Peek Component",
    classID          : Components.ID("{3c2292c5-062d-425e-a9ce-4cc10a77d774}"),
    contractID       : "@einaregilsson.com/sneakpeek;1",
    scripts            : [], //List of all installed scripts
    folder           : null, //The script folder
    
    NO_OVERWRITE     : -1,

    QueryInterface: XPCOMUtils.generateQI([Components.interfaces.nsISupports]),

    /* Factory that creates a singleton instance of the component */
    _xpcom_factory: { 
        createInstance : function() {
            if (SneakPeek.instance == null) {
                SneakPeek.instance = new SneakPeek();
            }
            return SneakPeek.instance;
        }
    },
  
    /**
     * Initalizes member variables and creates the script folder if
     * it doesn't exist. Loads and parses all available script files and
     * stores them in the .scripts array.
     */
    initialize : function() {
        this.wrappedJSObject = this;
        var prop = Components.classes["@mozilla.org/file/directory_service;1"].getService(Components.interfaces.nsIProperties);
        this.folder = prop.get("ProfD", Components.interfaces.nsIFile);
        this.folder.append("sp_scripts");
    
        if (!this.folder.exists()) {
            this.folder.create(this.folder.DIRECTORY_TYPE, 664);
        }

        var entries = this.folder.directoryEntries;
        while(entries.hasMoreElements()) {
            var entry = entries.getNext();
            entry.QueryInterface(Components.interfaces.nsIFile);
            try {
                var script = this.parsePreviewFile(entry.path);
                this.scripts.push(script);
                SPLib.debug('Found Sneak Peek file for ' + script.name);
            } catch(e) {
                SPLib.debug(entry.path + ' : ' + e);
            }
        }
    },
  
    /**
     * Install a new script. 'script' is
     * the content of the script or a script object, 'filename' is the 
     * file name to use when saving (if null then a new unique name
     * is generated), 'overwritePrompt' is a callback
     * function which we'll call if we need to as the user if
     * an old file should be ovewritten. Returns the name of the
     * new script, raises an error if the new script cannot
     * be parsed correctly.
     */
    installScript : function(script, filename, overwritePrompt) {
        if (typeof script == "string") {
            var text = script;
            script = new SneakPeekScript();
            script.loadFromText(text);
        }

        script.filename = filename;
        if (!filename) {
            this.generateFilename(script);
        }
        
        var file = SPLib.getFile(this.folder.path);
        file.append(script.filename);
        
        if (file.exists()) {
            var overwrite = overwritePrompt(file.path);
            if (!overwrite) {
                return this.NO_OVERWRITE;
            }
        }

        //Remove an old item for this filename if it exists
        if (overwrite) {
            this.deleteScript(script.filename);
        }
        script.saveToFile(this.folder);
        this.scripts.push(script);
        return script.name;
    },
  
    /**
     * Generates a unique name for the script based on its
     * name, and a sequence number if other scripts with
     * the same name exists.
     */
    generateFilename: function (script) {
        if (script.filename) {
            return;
        }
        var fixedName = script.name.replace(/[^A-Za-z0-9]/g, '');
        var file = SPLib.getFile(this.folder.path);
        file.append(fixedName + '.sp');
        var sequenceNr = 1;
        while(file.exists()) {
            sequenceNr++;
            file = SPLib.getFile(this.folder.path);
            file.append(fixedName + sequenceNr + '.sp');
        }
        script.filename = file.leafName;
        SPLib.debug('Generated filename ' + file.leafName);
    },

    /**
     * Returns a new empty script. Every window that needs to create script
     * should use this function. If some scripts are created by the component
     * and other by XUL windows then we get weird scoping issues.
     */
    getEmptyScript : function() {
        return new SneakPeekScript();
    },
    
    /**
     * Parses a preview file, the parameter is a filename.
     * Returns a js object or null if the file contains an error.
     */
    parsePreviewFile : function (file) {
        var script = new SneakPeekScript();
        try {
            script.loadFromFile(file);
            return script;
        } catch(e) {
            SPLib.debug(e);
            return null;
        }
    },
    
    /**
     * Deletes a script with the given filename from
     * the scripts array and the filesystem.
     */
    deleteScript : function(filename) {
        for (var i = 0; i < this.scripts.length; i++) {
            if (this.scripts[i].filename == filename) {
                this.scripts.splice(i, 1);
                SPLib.debug('Removed script ' + filename);
                break;
            }
        }
        var file = SPLib.getFile(this.folder.path);
        SPLib.debug('appending ' + filename);
        file.append(filename);
        if (file.exists()) {
            file.remove(false);
            SPLib.debug('Removed script file ' + filename);
        }
    },
    
    /* String representation of object */
    toString : function() {
        return "SneakPeek Component";
    }
}

/* Plumbing stuff for components */
var components = [SneakPeek];
function NSGetModule(compMgr, fileSpec) {
    return XPCOMUtils.generateModule(components);
}