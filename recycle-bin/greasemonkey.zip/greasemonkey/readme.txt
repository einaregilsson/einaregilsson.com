[This is the original page that was at http://tech.einaregilsson.com/projects/greasemonkey]

Greasemonkey scripts

Greasemonkey is probably the best Firefox addon of them all. It allows you to
write small scripts in javascript to fix or add functionality to specific web 
pages. I�ve used it to fix a number of annoyances in the websites I use most
frequently. All of these have been written to scratch my own itch, maybe they
can be useful for someone else as well.



Boligportal

I wrote this while looking for a new rental apartment in Denmark. It fixes some
shortcomings of the boligportal.dk website.

The features are:

    * Auto logs you in. Go to Tools->Greasemonkey->User Script Commands->Set 
      boligportal username and password to set the username and password used.

    * Redirects from http://boligportal.dk to http://www.boligportal.dk because
      you can be logged into one and not the other.

    * Adds a link to the apartment on findvej.dk which is a map site based on
      google maps, which is much better than kort.krak.dk or kort.eniro.dk
      which the site normally uses.

    * Adds a link to rejseplanen.dk with the apartment address as the �from�
      address. You can set the �to� address to be a default address by going to
      Tools->Greasemonkey->User Script Commands->Set rejseplanen destination

    * Adds the option on the listing page to hide certain apartments so they
      will never be displayed again and stop cluttering up new results. They
      can be unhidden by clicking a �Show� link on the left hand side of the
      page



DTU Campusnet

This script was written for Denmarks Technical University�s Campusnet website.
I�m currently studying at DTU and there were some things about this site that
annoyed me. The script automatically logs you in, you can set your username and
password by going to Tools->Greasemonkey->User Script Commands->Set username
and password. It also calculates your GPA on the grades page and shows how many
ECTS points are finished. I will probably add some more small stuff to it over 
the next year.



Joel on Software Forum Preview

This script was written for the Joel on Software Forums that I read quite a 
lot. With this script you can hover over a topic link on the main page and
you�ll get a preview of the thread that will show the whole text of the first
post. The preview should appear right under the topic you�re hovering over.
Fetched topics are cached so if you hover over a topic twice you should get it
instantly the second time. This script is a bit outdated since I�ve now
released a Firefox extension, Sneak Peek, that is a generalized version of this
script, where it is possible to define simple scripts to get previews on any
message board.



XKCD Preview

Shows previews of XKCD comics when hovering over links to them on any page
(example). XKCD is my favorite comic and a lot of forums and websites I read
link to these comics. To make it easy to see which comics are being linked to
without going to the comics page I created this script. When hovering over a
link to a comic the script will insert the comic image along with its title
right below the link in the page you are viewing. To get rid of it simply click
the inserted image.