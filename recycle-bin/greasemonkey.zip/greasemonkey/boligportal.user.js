// ==UserScript==
//
// @name            Boligportal
// @namespace       http://tech.einaregilsson.com/projects/greasemonkey#boligportal
// @description     Fixes some shortcomings of the boligportal.dk website
// @author          Einar Egilsson (greasemonkey@einaregilsson.com)
// @include         http://*boligportal.dk*
// @include         http://kort.eniro.dk*
// @include         http://kort.krak.dk*
//
// ==/UserScript==


// version 0.1 - 2008-08-24
//  * Auto login
//  * Show or hide search results
//  * Link to findvej.dk
//  * Link to rejseplanen.dk

function openWindow(url) {
    var width = document.body.offsetWidth * 80 / 100
    var height = document.body.offsetHeight * 80 / 100
    var win = open(url, "", "toolbar=no,location=no,directories=no,status=yes,menubar=no,"
                            +"scrollbars=yes,resizable=yes,copyhistory=no,width="+width+",height="+height);
    win.focus()
}

//Adds a link under the image on the apartment display page
function addLink(url, text, exampleLink) {
    var td = exampleLink.parentNode.cloneNode(true);
    var imgTd = exampleLink.parentNode.previousSibling.previousSibling.cloneNode(true);
    var row = exampleLink.parentNode.parentNode;
    var textLink = td.firstChild.nextSibling;
    var imgLink = imgTd.firstChild;

    textLink.innerHTML = text;    

    for each (var newLink in [textLink, imgLink]) {
        newLink.setAttribute('href', url);
        newLink.setAttribute('onclick', 'return false;');
        newLink.addEventListener('click', function(event) {
            openWindow(url);
            event.preventDefault();
        }, true);
       row.insertBefore(newLink.parentNode, row.firstChild);
    }
    td.parentNode.parentNode.parentNode.style.whiteSpace= 'nowrap';
}

//Adds links to findvej.dk and Rejseplanen.dk to the apartment display page
function addMapAndRouteLinks() {
    
    var links = document.getElementsByTagName('a');
    var link = null;    
    for (var i in links) {
        link = links[i];
        var href = link.href;
        if (link.firstChild && link.innerHTML == 'Vis kort') {
            var url = href.substr(21);
            url = 'http://www.boligportal.dk' + url.substr(0, url.indexOf("'"));
            break;
        }
    }
    
    if (!url) {
        return;
    }
    var iframe = document.createElement('iframe');
    iframe.style.display = 'none';
    document.getElementsByTagName('body')[0].appendChild(iframe);
    /annonceId=(\d+)/.exec(document.location.href);
    var annonceId = RegExp.$1;    
    iframe.addEventListener('load', function() {
        var streetname = GM_getValue('streetname', '');
        if (streetname.substr(0, annonceId.length) == annonceId) {
            if (window.addedLinks) {
                return;
            }
            streetname = streetname.substr(annonceId.length+1);
            var findvejUrl = 'http://www.findvej.dk/' + streetname;
            var rejseplanenUrl = 'http://www.rejseplanen.dk/bin/query.exe/mn?z=' + GM_getValue('rejseplanenTo', '') + '&s=' + streetname;
            addLink(rejseplanenUrl, 'Rejseplanen ', link);
            addLink(findvejUrl, 'Findvej.dk ', link);
            window.addedLinks = true;
        }
    }, true);
    iframe.src = url + '#' + annonceId;
}

//Shows or hides a single apartment listing
function toggleTable(table, visible) {
    var values = visible ? ['', 'red', 'show', 'Hide', -1] : ['none', 'blue', 'hide', 'Unhide', 1];
    var a = table.getElementsByTagName('a')[2];

    table.style.display = values[0];
    if (document.getElementById('showhide').innerHTML == 'Hide') {
        table.style.display = '';
    }

    a.style.color = values[1];
    table.setAttribute('bolig', values[2]);
    a.innerHTML = '&nbsp;&nbsp;&nbsp;' + values[3];
    hiddenCount += values[4];
    document.getElementById('hiddenCount').innerHTML = '<b>' + hiddenCount + '</b>&nbsp;';
}

//Adds info about how many apartments are hidden
function addSummaryInfo() {
    var cells = document.getElementsByTagName('td');
    
    for (var i in cells) {
        var html = cells[i].innerHTML;
        if (html && (html == 'i alt udlejeannoncer' || html == 'ialt udlejeannoncer')) {
            var newRow = cells[i].parentNode.cloneNode(true);
            var summaryTable = cells[i].parentNode.parentNode.parentNode;
            break;
        }
    }
    newRow.childNodes[3].innerHTML = '<b>0</b>&nbsp;';
    newRow.childNodes[3].setAttribute('id', 'hiddenCount');
    newRow.childNodes[5].innerHTML = 'hidden apartments<br><a id="showhide" href="javascript:showHiddenApartments()" onclick="return false;">Show</a>';
    summaryTable.appendChild(newRow);
    document.getElementById('showhide').addEventListener('click', function(event) {
        var tables = getTables();
        if (event.target.innerHTML == 'Show') {
            for (var i in tables) { 
                if (tables[i].style.display == 'none') {
                    tables[i].style.display = '';
                }
            }
            event.target.innerHTML = 'Hide';
        } else {
            for (var i in tables) { 
                if (tables[i].getAttribute('bolig') == 'hide') {
                    tables[i].style.display = 'none';
                }
            }
            event.target.innerHTML = 'Show';
        }
    }, true);
}


//Gets all apartment listing tables
function getTables() {
    var tables = document.getElementsByTagName('table');
    var result = [];
    for (var i in tables) {
        if (tables[i].getAttribute('class') == 'tekstAnnonce2') {
            result.push(tables[i]);    
        }
    }
    return result;
}


//Hides listings that should be hidden, adds 'hide' link to all listings
function processSearchListings() {
    addSummaryInfo();
    var tables = getTables();
    window.hidden = GM_getValue('hidden', '');
    if (!hidden) {
        hidden = [];
    } else {
        hidden = hidden.split(';');
    }   
    window.hiddenCount = 0;
    for (var i in tables) {
        var table = tables[i];
        var td = table.firstChild.nextSibling.firstChild.firstChild.nextSibling;
        var id = td.getAttribute('onclick');
        
        if  (table.parentNode.parentNode.nextSibling.tagName  == 'TR') {
            var prevTr = table.parentNode.parentNode.previousSibling.previousSibling;
            var appendTd = prevTr.childNodes[3];
            table.parentNode.removeChild(table);
            appendTd.appendChild(table);
        }
        
        if (!id) {
            continue;
        }
        id = id.substr(3);
        id = id.substr(0, id.indexOf(')'));
        var a = table.getElementsByTagName('a')[1];
        
        var hideLink = document.createElement('a');
        hideLink.innerHTML = '&nbsp;&nbsp;&nbsp;Hide';
        hideLink.style.color = 'red';
        hideLink.boligID = id;
        hideLink.setAttribute('href', 'javascript:hideApartment()');
        hideLink.setAttribute('onclick', 'return false;');
        hideLink.setAttribute('id', id);
        hideLink.addEventListener('click', function(event) {
            var parentTable = event.target.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode.parentNode;
            var boligID = event.target.getAttribute('id');
            if (event.target.innerHTML.indexOf('Hide') != -1) {
                hidden.push(boligID);
                toggleTable(parentTable, false);
            } else if (event.target.innerHTML.indexOf('Unhide') != -1) {
                toggleTable(parentTable, true);
                for (var j in window.hidden) {
                    if (hidden[j] == boligID) {
                        hidden.splice(j, 1);
                        break;
                    }
                }
            }
            GM_setValue('hidden', hidden.join(';'));

        }, true);
        hideLink.setAttribute('class', 'forsideKnapLogin');
        a.parentNode.appendChild(hideLink);

        for (var j in hidden) {
            if (id == hidden[j]) {
                toggleTable(table, false);
                break;
            }
        }

    }
    
}

//Checks whether you're logged in and logs you in if you're not.
function checkLoginStatus() {
    var isLoggedIn = document.evaluate("//a[@href='/lejebolig/din_find_bolig_pakke.php']", document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null).snapshotLength > 0;
    if (!isLoggedIn) {
    
        var user = GM_getValue('user', '');
        var password = GM_getValue('password', '');
        if (!user || !password) {
            return;
        }
        
        var inputs = document.getElementsByTagName('input');
        for (var i in inputs) {
            if (inputs[i].getAttribute('name') == 'login') {
                var form = inputs[i].parentNode.parentNode.parentNode.parentNode.parentNode;
                inputs[i].value = user;
            } else if (inputs[i].getAttribute('name') == 'password') {
                inputs[i].value = password;
            }
        }

    }
    if (form) {
        form.submit();
    }
}

//Adds commands to enter the rejseplanen address and user/pass.
function registerMenuCommands() {
    GM_registerMenuCommand('Set Rejseplanen destination', function() {
        GM_setValue('rejseplanenTo', prompt('Enter the Rejseplanen destination', GM_getValue('rejseplanenTo', '')));
    });
    GM_registerMenuCommand('Set boligportal username and password', function() {
        var user = prompt('Enter boligportal username:', GM_getValue('user', ''));
        var password = prompt('Enter boligportal password:');
        if (user != null) {
            GM_setValue('user', user);
        }
        if (password != null) {
            GM_setValue('password', password);
        }
    });
}

//////////// Main script starts ////////////////////////

if (document.location.href.indexOf('http://boligportal') != -1) {
    //www.boligportal.dk and boligportal.dk conflict, you can be logged into one but not the other
    //so lets alway use the www. version.
    document.location.href = document.location.href.replace('http://', 'http://www.');
    return;
}

if (document.location.href.indexOf('boligportal') != -1) {
    registerMenuCommands();
    checkLoginStatus();
}

if (document.location.href.indexOf('vis_annonce.php') != -1) {
    addMapAndRouteLinks();
} else if (document.location.href.indexOf('soeg_leje_bolig.php?submit') != -1) {
    processSearchListings();
} else if (document.location.href.indexOf('kort.krak.dk') != -1 || document.location.href.indexOf('eniro') != -1) {

    var id = document.location.href.split('#')[1];    
    if (!id || !/^\d+$/.exec(id)) {
        return;
    }

    if (document.location.href.indexOf('kort.krak.dk') != -1) {
        var spans = document.getElementsByTagName('span');
        for (var i in spans) {
            if (spans[i].getAttribute('class') == 'routeinputtodescription') {
                var street = spans[i].innerHTML.substr(0, spans[i].innerHTML.indexOf(',')+6);
                GM_setValue('streetname', id + '#' + street);
                break;
            }
        }
    } else {
        var input = document.getElementById('where');
        GM_setValue('streetname', id + '#' + input.value);
    }
}
