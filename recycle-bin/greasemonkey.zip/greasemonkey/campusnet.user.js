// ==UserScript==
//
// @name            DTU Campusnet
// @namespace       http://tech.einaregilsson.com/projects/greasemonkey#campusnet
// @description     Fixes some shortcomings of DTU's Campusnet website
// @author          Einar Egilsson (greasemonkey@einaregilsson.com)
// @include         https://*campusnet.dtu.dk/cnnet/Grades/Grades.aspx*
// @include         https://*campusnet.dtu.dk*
// @include         https://auth.dtu.dk/dtu/index.jsp?service=https%3a%2f%2fwww.campusnet.dtu.dk*
//
// ==/UserScript==


GM_registerMenuCommand('Set campusnet username and password', function() {
    var user = prompt('Enter campusnet username:', GM_getValue('user', ''));
    var password = prompt('Enter campusnet password:');
    if (user != null) {
        GM_setValue('user', user);
    }
    if (password != null) {
        GM_setValue('password', password);
    }
});

if (document.location.href.indexOf('auth.dtu.dk') != -1) {
    var user = GM_getValue('user', '');
    var password = GM_getValue('password', '');
    if (user && password) {
        document.getElementById('ctl00_ContentPlaceHolder1_Textbox_Username').value = user;
        document.getElementById('ctl00_ContentPlaceHolder1_TextBox_Password').value = password;
        document.forms[0].submit();
    }
    return;
} else if (document.location.href.indexOf('Grades.aspx') != -1) {
    var rows = document.evaluate("//form[@id='Grades']/table/tbody/tr", document, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
    var grade, points, total = 0, totalPoints = 0, tbody;
    for (var i = 1; i < rows.snapshotLength; i++) {
        var row = rows.snapshotItem(i);
        tbody = row.parentNode;
        for (var j in row.childNodes) {
            if (row.childNodes[j].tagName.toUpperCase() == 'TD') {
                if (j == 2) {
                    grade = parseFloat(row.childNodes[j].innerHTML);
                } else if (j == 3) {
                    points = parseFloat(row.childNodes[j].innerHTML);
                }
            }
        }

        total += (grade * points);
        totalPoints += points;
    }

    var gpa = total / totalPoints;
    var newRow = document.createElement('tr');
    for (var i = 0; i < 5; i++) {
        newRow.appendChild(document.createElement('td'));
    }

    newRow.childNodes[1].style.textAlign = 'right';
    newRow.childNodes[1].innerHTML= '<b>GPA:&nbsp;</b>';
    newRow.childNodes[2].innerHTML = '<b>' + gpa + '</b>';
    newRow.childNodes[3].innerHTML = '<b>' + totalPoints + '</b>';
    tbody.appendChild(newRow);
}

// version 0.1 - 2008-08-18
//   Initial version. Calculates GPA, total ECTS finished and automatically logs you in.
