[this is the original page http://tech.einaregilsson.com/projects/highlander/]

This was done as a request for someone, I can’t find the thread anymore. Then 
later another extension developer, Malte Kraus, pretty much rewrote the thing 
from scratch (version 1.0) and sent me his changes. I fixed some more things 
and added some more features for 1.1 so now it’s about 50 % mine, 50 % his :).

What this extension does: when you click a link to an url that’s already open 
in another tab then you’ll switch to that tab instead of actually opening the 
link. In the latest version this should also work for ctrl+click, javascript 
opening urls and pretty much anything. Version 1.1 adds the ability to 
whitelist certain urls, using wildcard patterns, and the ability to disable 
Highlander completely. Version 1.1.1 adds the option to ignore #bookmark signs
in urls so index.html#foo and index.html#bar are considered the same thing. See 
version notes for more info.

Works with: Firefox: 2.0b1 – 3.0.*
Latest version: 1.2


VERSION HISTORY

Version 1.2 — May 24, 2007

  Firefox 3.0.* compatibility.

Version 1.1.3 — September 21, 2007

  Added german locale, thanks to Fux from www.firefox-browser.de who 
  translated. Also fixed a bug where if you had www.example.com open in new 
  window, but then tried to open it in another window then Highlander would 
  stop it from loading, but not switch to the window that had it open before. 
  That’s been fixed now, thanks to Jason Phillips for sending in that bug 
  report.

Version 1.1.2 — September 11, 2007

  This is just a quick fix for those with a German locale. I ripped out the 
  german locale from v1.1 because I added some more gui but didn’t have a 
  translator but forgot to remove it from chrome.manifest. So all german users 
  got errors. This is now fixed. But if someone wants to submit a german 
  translation please contact me and I’ll be happy to include it. It’s only 
  like 10 strings or something.

Version 1.1.1 — September 9, 2007

  This version adds an option to ignore hash signs (bookmarks) in urls. So for 
  instance:
  http://example.com/index.html#chapter1
  and
  http://example.com/index.html#somethingelse
  would be considered the same url. However, you have to turn on this 
  functionality specifically by going to about:config and setting 
  extensions.highlander.ignoreHash to true. I didn’t want to set this as 
  default because if you have index.html open on #something and you’re clicking
  a link that goes to #anotherthing then you could be pretty annoyed if the 
  link didn’t take you where you want to go. So, enable if you want, otherwise 
  there is no change.

Version 1.1 — August 25, 2007

  This version adds two much-requested features:

    1. Whitelist of urls not affected. These can be specified with wildcards, 
       * is the wildcard character and will match any characters zero or more 
       times. Access through Tools - Highlander - Whitelist.
    2. Ability to disable Highlander. Access through Tools - Highlander - Enabled.

  Other changes include some internal code rewrites, and making sure that POST 
  requests are never stopped, even if there is a tab with the same url already 
  open, as the post data may be different in them.

Version 1.0 — March 7, 2007

  Malte Kraus wrote this version and pretty much rewrote the extension from 
  scratch. It now supports open in new tab, open from javascript, ctrl+click, 
  open from bookmarks, pretty much everything. Now there really can only be one 
  tab for each url :)

Version 0.1 — December 14, 2006

  Note: This doesn’t work if you Ctrl + click a link, then it’ll still load in 
  a background tab, even if it’s already open in another tab. I might fix that,
  or maybe make it configurable in a later version.



COMMENTS

###############################################################################

  ken meece | 25 Aug 2007 9:00 pm

  thanks for the whitelist feature. GREAT!

  may i suggest one little enhancement/tweak for a future version? i’d like to 
  use an icon in the status bar to turn on-off and add the current site to the 
  whitelist.

  great extension!
  ken
  
###############################################################################
  
  ken meece | 26 Aug 2007 6:53 pm

  bug?

  go to http://www.washingtonpost.com/wp-srv/mostemailed/index.html

  middle click any article.

  (i use middle click to load a link into a new, background tab…. that may be a
  TMP option, or a ff option - i don’t recall)

  nothing happens

  disable Highlander, then

  middle-click again — it works (load article in background tab)

  enable Highlander, but whilelist “www.washingtonpost.com*”

  middle-click article — it doesn’t work again, the article isn’t loaded — ie, 
  the whitelist makes no difference, doesn’t seem to disable Highlander

  so, when highlander is enabled, regardless of any whitelisting, the middle 
  click is disabled in all cases. (this is true on other sites as well)

  this appears to be a bug, an unwanted behavior
  
###############################################################################
  
  einar | 27 Aug 2007 8:07 am
  
  Hmmm. I have a laptop and just use the touchpad, I don’t even own a mouse so 
  I can’t really test it until I get a mouse. Could you try something for me?

  1. Goto about:config and change the extensions.highlander.debug setting to 
     true.
  
  2. Goto the site you mentioned.
  3. Goto Tools - Error Console. Clear all the messages.
  4. Now try middleclicking an article. You should see some debug output in the
     Error console.
  5. Post it here :)

  If you could do that it would be great. Otherwise I’ll try to check this out 
  sometime when I have access to a normal mouse.
  
###############################################################################
  
  wrongwrider | 30 Aug 2007 11:52 am

  In der Deutschen Version wird folgender Fehler angezeigt:

  ——–^

###############################################################################

  einar | 31 Aug 2007 2:09 pm

  Hi

  If I understand you correctly you just said ‘In the German version the 
  following error is indicated’. But I don’t see any error message. Did it 
  include > or < ? If so it might have been cut out by the blog system. You can 
  also send it to me directly at highlander@einaregilsson.com

###############################################################################

  Peuj | 06 Sep 2007 12:09 pm

  Hi,

  Really great extension!! Thanks

  @ken meece: I’ve tested on the web site as I use the middleclick but I don’t 
  reproduce your problem.

###############################################################################

  Chris Bloom | 07 Sep 2007 7:10 pm

  Great extension! I saw it in the add-ons directory and thought, why would I 
  ever need that? Two days later I found myself thinking “Boy I wish I had that 
  with extension now all these tabs open” :) Is there a posibility of adding in
  the option of ignoring inline bookmarks in URLs? i.e. So that 
  http://somesite.com#section_2 is considered the same as 
  http://somesite.com#section_5?
  
###############################################################################
  
  einar | 07 Sep 2007 9:37 pm

  Yeah, that definitely sounds like a feature that should be there. I’ll put it
  in the next version.

###############################################################################

  einar | 09 Sep 2007 3:26 pm

  Chris, I’ve added the functionality in version 1.1.1 that is available now on 
  this site, and soon on AMO. You’ll have to turn it on specifically though, by 
  going to about:config and setting extensions.highlander.ignoreHash to true. 
  Enjoy :)

###############################################################################

  Speravir | 10 Sep 2007 10:34 am

  In addition to “wrongwrider”:
  In German version of FFx appears after installation of “Highlander” below the
  status bar following error message:

  ——–^

  According to 
  http://www.firefox-browser.de/forum/viewtopic.php?p=392218#392218 the reason 
  is, that you deleted the german locale (which came from Dr. Evil, didn’t it?)
  , but have forgotten to delete the corresponding entry in “chrome.manifest”.
  And I must say, that’s right: I changed this manually, and now Highlander 
  works fine.
  
###############################################################################
  
  Speravir | 10 Sep 2007 10:37 am

  Oh, there’s the problem …

  Let’s try it again with escaping the angles - the error message is:

  <menu id=”menu_Highlander” label=”&HighlanderMenuItem. label;” accesskey=”HighlanderMenuItem. accesskey;”>
  ——–^

###############################################################################

  einar | 10 Sep 2007 3:45 pm

  Aha, ok, now I understand. Thanks for letting me know, I’ll try to rip that 
  out soon and post a new version. Unless someone wants to translate the rest 
  of it to german… ;)
  
###############################################################################
  
  einar | 11 Sep 2007 10:58 am

  I’ve put up version 1.1.2 which completely removes all traces of german 
  locale so there should be no errors. Still waiting on volunteers to do a 
  proper translation however…
  
###############################################################################
  
  neihrick | 12 Sep 2007 7:01 pm

  Hi, i like the idea of this extension. For some reason, it doesn’t seem to 
  work. after installing then restarting firefox, i opened 
  http://xbox360.ign.com/, then opened another tab and went to 
  http://pc.ign.com/. I clicked the link to direct me to 
  http://xbox360.ign.com/ and it opened that page. Now i have 2 tabs with 
  URL = http://xbox360.ign.com/. it does this for other sites as well, am i 
  doing something wrong?
  
###############################################################################
  
  einar | 12 Sep 2007 7:26 pm

  Hi neihrick

  I tried those two sites and it worked for me. Doesn’t it work at all for you?
  Here are a couple of things you can try:

  1. Goto about:config and set extensions.highlander.debug to true. Then you 
     can look at the error console under the tools menu and should see a lot 
     of output from Highlander, some of it might explain why this isn’t 
     working.
  2. Do you have the latest version, 1.1.2 ?
  3. Do you have a german version of Firefox? There have been some problems 
  with the german localization but I thought they were fixed now.

  Let me know how it goes :)

###############################################################################

  neihrick | 13 Sep 2007 1:58 am

  Hi, thanks for the quick response.
  No, it doesn’t work at all for me.
  Using 1.1.2, not using german version.
  I turned debug on but saw nothing in the error console pertaining to 
  Highlander other than “Highlander: Initializing…” I restarted Firefox with 
  debug on and tried clicking on links with URLs being the same as open tabs 
  and I dont see anything in the Error Console. I am going to try the older 
  versions.
  
###############################################################################
  
  neihrick | 13 Sep 2007 3:38 am

  i created a new ff profile with only Highlander installed and it works. got 
  all my previous add ons installed and still working so not sure what the 
  problem was. thanks

###############################################################################

  cubefox | 14 Sep 2007 11:45 pm

  I have a feature request:

  could you provide an option (about:config is enough) that tells highlander 
  _not_ to switch to the tab which’s duplicate just was getting blocked by 
  highlander? this would be very useful. :)

  I hope you know what I mean.
  thanks

###############################################################################

  einar | 15 Sep 2007 1:28 pm

  Hi

  So you want nothing at all to happen? You just press a link, it doesn’t take 
  you there but it also doesn’t switch to another tab that has the url open? 
  That sounds like a usability nightmare :) I don’t think I’ll add it as a 
  feature, but if you’re comfortable with some hacking of your own, you can go 
  into

  %your profile folder%\extensions\highlander@einaregilsson.com\chrome\content 
  
  and edit the highlander.js

  Find this code:


  selectTab: function(tab) {
	  var win = tab.ownerDocument.defaultView;
	  // focus tab and containing window
	  win.getBrowser().selectedTab = tab;
	  if(win != window)
		win.focus();
	},

  and change it to:


  selectTab: function(tab) {
	 return; //NEVER SELECT THE TAB
	  var win = tab.ownerDocument.defaultView;
	  // focus tab and containing window
	  win.getBrowser().selectedTab = tab;
	  if(win != window)
		win.focus();
	},

  That way you should never switch to the tab you found. If you’re not 
  comfortable hacking the extension you can mail me and I’ll send you a custom
  build, but these changes won’t go into the released version, sorry.
  
###############################################################################
  
  cubefox | 15 Sep 2007 6:55 pm

  thank you, I will test the code later (at home).

  my requestet feature is not completly useless, even though it seems so.
  when your are opening some/many tabs in backround, you don’t want to switch 
  to another.

  perhaps you can implement a feature that highlander only doesn’t switch tab 
  when you open a tab in backround?
  
###############################################################################

  einar | 18 Sep 2007 10:59 am

  Ah, yes, now I understand. Of course, if you’re trying to open in a 
  background tab of course you don’t want to immediately switch to it, makes 
  perfect sense. I’ll see what I can do for the next version. It’ll probably be 
  a few weeks until I publish it though, because I’m very busy with school at 
  the moment.
  
###############################################################################
  
  einar | 21 Sep 2007 7:36 pm

  Sorry cubefox, your feature didn’t make it into 1.1.3 that was just released 
  but I’ll keep it in mind for 1.2.
  
###############################################################################
  
  cubefox | 21 Sep 2007 11:10 pm

  okay, thank you.

###############################################################################

  ken meece | 30 Sep 2007 5:25 am

  highlander has simply stopped working for me. i see the solution below, and 
  someday when a have a whole lotta time i might try it. but in the meantime 
  there seems to be an extension clash, or an odd preference by hilander to be 
  loaded before (some particular?) other extension(s). i’m hoping that a fix 
  for this can be found before i have to try to sort out the incompatibilities 
  and/or sequencing myself.

###############################################################################
  
  neihrick | September 13th, 2007 at 3:38 am

  i created a new ff profile with only Highlander installed and it works. got 
  all my previous add ons installed and still working so not sure what the 
  problem was. thanks
  
###############################################################################
  
  einar | 30 Sep 2007 10:56 am

  If the problem was fixed for Neihrick by installing Highlander first and 
  then all other extension then it’s probably something about the order in 
  which the extensions load, Highlander seems to need to be loaded first or 
  something like that. Or maybe it needs to be the last one to load. I’ll try 
  to look into how extensions load in Firefox, if it’s always in the same order 
  as they were installed or what. Maybe I can hack up some solution where I 
  delay the loading a bit or something.

###############################################################################

  Reporter | 03 Oct 2007 6:15 pm

  Would you mind adding the following options:
  - (don’t) switch tab if you type the URL (on the address bar)

  The reason why I want it because I need to open the same URL in different 
  tabs once in a while, eg when you do a search, when you want to compare 
  pages etc. The whitelist is a bit less convenient (it doesn’t support 
  wildcards) but the real issue is I don’t want to whitelist the site (eg when 
  I compare pages, I may do it nearly everywhere. “Adding into whitelist -> 
  Compare pages -> Remove it from whitelist”… this is very clumsy and 
  inconvenient).

  I need it very much. Plese consider adding it. Thanks for your reading. :D

  PS: You may consider adding more options (eg don’t switch open new tab/window
  via context menu, or middle-click the link, and so on) but the first one is 
  what I want.
  
###############################################################################
  
  Reporter | 03 Oct 2007 6:19 pm

  Forget to mention. Your extension is very useful to me (although it creates 
  some annoyances due to my own browsing habits). Thank you so much for your 
  time to create a great addon to the community. :D
  
###############################################################################
  
  einar | 03 Oct 2007 6:24 pm

  Hi Reporter, glad you find the extension useful. I probably won’t update in a 
  while since I have a lot to do at work and in university but I’ll consider it 
  when I do the next release.

  Probably the easiest way for you to bypass this is to disable highlander 
  temporarily when you need to open two tabs. You can do that by going to 
  Tools -> Highlander and turning off the “Enabled” item. It’s a bit of a 
  hassle but still easier than using the whitelist.
  
###############################################################################
  
  Reporter | 04 Oct 2007 1:36 pm

  Thanks for your idea. The reason why I choose the “temporary whitelist” 
  approach is because I want the functions to be on while I can still type he 
  site URL without redirection.

  Wish you getting first-honour when you graduate.
  …… and please don’t forget my requests ;)
  
###############################################################################
  
  neihrick | 10 Oct 2007 5:30 am

  is there a way to add support for Chrome://*.xul?

###############################################################################

  einar | 10 Oct 2007 5:35 pm

  hmm, there might be. I would have thought that it would work automatically, 
  since it’s just a different string as the address. I’ll look into it for the 
  next release, but it’ll be a while.
  
  Anonymous | 15 Oct 2007 5:45 am

  I agree that an icon to toggle it on/off would be very helpful
  
###############################################################################
  
  Peuj | 09 Jan 2008 3:49 pm

  Hi,

  I know it can sound as a stupid situation but Highlander doesn’t work if the 
  duplicated window is the same than the active one.
  For example if I’m in the web page 
  http://tech.einaregilsson.com/projects/highlander/ and there is a link to 
  http://tech.einaregilsson.com/projects/highlander/ if I click on this link 
  then it opens a duplicated web page.

  Thanks
  
###############################################################################
  
  Anonymous | 23 Jun 2008 3:27 pm

  Hi,

  I’m using the latest version 1.2 with Firefox 3.

  I have 2 situations where Highlander doesn’t work:

  1 - If I open an already existing link from the Bookmarks, Highlander doesn’t 
      detect it and open a new tab.
  2 - If I use the extension “Snap Links” 
      https://addons.mozilla.org/en-US/firefox/addon/4336

  Thanks
  
###############################################################################
  
  Peuj | 23 Jun 2008 3:29 pm

  Previous comment is from me. :)
  
###############################################################################
  
  VisitorG | 30 Aug 2008 7:59 am

  Hi, hope you’re still reading this.

  Highlander is axactly what I was looking for, cause as a web developper it is
  great not to have a new tab opening every time you build your project.
  Except it doesn’t work when opening a file instead of an url.
  No need to tel me I could use local server, I need to actualy open an html 
  file.

  I would really appreciate this add on if this worked fine.

  Also, the “enable/disable” button is not a bad idea.

  Thanks.
  
###############################################################################
  
  cubefox | 23 Sep 2008 4:37 pm

  Highlander is not compatible with actual Tab Mix Plus builds. :(
  see http://tmp.garyr.net - dev-build.
  If you try to open a link in a new tab by middle clicking on it, nothing 
  happens. only this error message appears in the error console:

  error: origHandleLinkClick is not defined
  source: chrome://tabmixplus/content/minit/tablib.js
  row: 275
  
###############################################################################
  
  Peuj | 30 Sep 2008 8:35 pm

  The issue with Tab Mix Plus has been fixed with the latest build

###############################################################################

  Kurt | 27 Dec 2008 6:58 pm

  I have found an incompatibility with tree style tabs. Effect:
  The indention of child tabs doesn’t work anymore.
  Should I tell this also the author of tree style tabs (piro.sakura.ne.jp)?
  And… is there a way to prevent FF to open more than one tab with an identical 
  URL - no matter, how this new tab is opened (bookmark, link, typed-in URL in 
  URL bar)? Only with a possibility to override this behavior together with a 
  hotkey or something like this?
  But… a very good idea, Highlander.
  
###############################################################################
  
  Reverend Darwin | 30 Mar 2009 7:49 pm

  Kudos on the good work, this extension will surely be assimilated into the 
  official release one day (long overdue). My two-buttons-from-anywhere 
  shortcut to https://mail.google.com/mail/ (so I can use Start > Mail Search: 
  Start Key, M, in the dark or drunk or whatever) would still open duplicates 
  when there were trailing Query Strings on it in any open tab/window. So in 
  [profile]\extensions\highlander@einaregilsson.com\chrome\content\highlander.js 
  I replaced the 3 calls to checkHash() with a new getRedactedURI() (which 
  calls checkHash() AND a new checkQueryString()) — to turn it on, in 
  about:config I right-click and add New > Boolean 
  extension.highlander.ignoreQueryString as ‘true.’
  
  My kludge below:
  getRedactedURI : function(uri) {
      if (uri == Highlander.checkQueryString(uri)) {
          if (uri == Highlander.checkHash(uri)) {
              return uri.spec;
          } else {
              return Highlander.checkHash(uri);
          }
      } else {
          return Highlander.checkQueryString(uri);
      }
  },

  checkQueryString : function(uri) {
      if (!SeanConnery.getBoolPref(’ignoreQueryString’)) {
           return uri.spec;
      }
      var posQueryString = uri.spec.indexOf(’?');
      if (posQueryString != -1) {
          SeanConnery.debug(’Cutting ? query string of uri %1?._(uri.spec));
          return uri.spec.substr(0, posQueryString);
      } else {
          return uri.spec;
      }
  },

  checkHashSign : function(uri) {
      if (!SeanConnery.getBoolPref(’ignoreHash’)) {
          return uri.spec;
      }
      var posHash = uri.spec.indexOf(’#');
      if (posHash != -1) {
          SeanConnery.debug(’Cutting # bookmark of uri %1?._(uri.spec));
          return uri.spec.substr(0, posHash);
      } else {
          return uri.spec;
      }
  },

###############################################################################

  Eric | 02 Jun 2009 7:20 pm

  I have been hapy if there has been a setting to chose that if a new address 
  opens that already is open. The new tab then will not be opend. Instead of 
  showing the tab containing the address.

###############################################################################

  Leon | 12 Jun 2009 4:16 am e

  Very useful, but it doesn’t work if you shift + middle click on the “Back” or
  “Forward” button.

  Suggestions:
  -option of whether to switch to the existing tab or to just ignore the 
   command that would otherwise open a duplicate tab
  -ability to ignore certain (user-defined) strings at the end of the URL for 
   purposes of duplicate checking. With Javascript-coded sites, links within 
   one page may result in URLs ending in a hash mark possibly followed by an 
   identifier, which - although still on the same page - is considered by your 
   extension to be different because the addresses don’t quite match.

###############################################################################
