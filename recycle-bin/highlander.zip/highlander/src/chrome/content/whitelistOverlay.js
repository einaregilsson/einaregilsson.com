var WhitelistOverlay = {

  id          : "highlander@einaregilsson.com",
  name        : "Highlander",

  onLoad : function() {
    SeanConnery.initialize(this);
    HighlanderWhitelist.init();
    this.addPatternsToListBox(HighlanderWhitelist.list);
  },

  addPatternsToListBox : function(patterns) {

    var list = $('lstWhitelist');
    var pattern, row;

    for each (pattern in patterns) {
      var row = this.createRow(pattern);
      list.appendChild(row);
    }

  },
  
  createRow : function(pattern) {
    var row = document.createElement('listitem');
    var cell = document.createElement('listcell');
    cell.setAttribute('label', pattern);
    cell.setAttribute('value', pattern);
    row.appendChild(cell);
    row.item = { 'pattern' : pattern };
    return row
  
  },

  close : function() {
    window.close();
  },

  addPattern: function() {

    var item = { pattern : ''};

    window.openDialog("chrome://highlander/content/whitelistPattern.xul",
                      "whitelistPattern",
                      "chrome,dialog,modal,centerscreen", item);

    if (item.saved) {
      var row = this.createRow(item.pattern);
      $('lstWhitelist').appendChild(row);
      HighlanderWhitelist.add(item.pattern);
    }

  },

  editPattern : function() {

    var listItem = $('lstWhitelist').selectedItem;

    if (!listItem) {
      return;
    }

    var item = listItem.item;

    window.openDialog("chrome://highlander/content/whitelistPattern.xul",
                      "whitelistPattern",
                      "chrome,dialog,modal,centerscreen", item);

    if (item.saved) {
      var map = [item.pattern, item.exampleUrl, item.redirectUrl, item.onlyIfLinkExists, item.patternType];

      listItem.childNodes[0].setAttribute('value', item.pattern);
      listItem.childNodes[0].setAttribute('label', item.pattern);
      
      HighlanderWhitelist.updateAt($('lstWhitelist').selectedIndex, item.pattern);
      HighlanderWhitelist.save();
    }

  },

  deletePattern : function() {
    var list = $('lstWhitelist');
    var index = list.selectedIndex;

    if (index == -1) {
      return;
    }

    list.removeItemAt(index);
    HighlanderWhitelist.deleteAt(index);
  },

  selectionChange : function() {
    var index = $('lstWhitelist').selectedIndex;

    $('btnEdit').disabled = (index == -1);
    $('btnDelete').disabled = (index == -1);
  }

};
