/* ***** BEGIN LICENSE BLOCK *****
 *   Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is Highlander.
 *
 * The Initial Developer of the Original Code is
 *
 * Einar Egilsson. (email: highlander@einaregilsson.com)
 *
 * Portions created by the Initial Developer are Copyright (C) 2006 - 2007
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *   Malte Kraus <firefox@maltekraus.de>
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */


var Highlander = {

  id          : "highlander@einaregilsson.com",
  name        : "Highlander",
  initialized : false,


  onLoad : function(event) {
    // initialization code
    SeanConnery.initialize(Highlander);
    SeanConnery.debug("Initializing...");

    //Setup all handlers
    Highlander.checkForNewWindowUrl();
    Highlander.overrideHandleLinkClick();
    Highlander.overrideContextMenuOpenLink();
    Highlander.overrideContextMenuOpenLinkInTab();
    Highlander.overrideOnStateChange();
    HighlanderWhitelist.init();
    getBrowser().mPanelContainer.addEventListener("click", Highlander.onClick, true);
    var menuitem = $('highlander-enabled');
    if (menuitem) {
      menuitem.setAttribute('checked', SeanConnery.getBoolPref('enabled'));
    }

    Highlander.prefObserver.register();
    Highlander.initialized = true;
    
  },

  onUnload : function(event) {
    Highlander.prefObserver.unregister();
  },
  
  checkForNewWindowUrl : function () {
    // this window could have been opened for loading a page that's
    // already open somewhere
    if (window.arguments && window.arguments[0]) {
      var tab = Highlander.findTabForURI(makeURI(window.arguments[0]));
      if(tab) {
        SeanConnery.debug('Captured in new window');

        Highlander.selectTab(tab);
        BrowserTryToCloseWindow(); // Leak Monitor reports some leaks here
        // but I can't imagine what could be the cause
        return;
      }
    }
  }, 

  // this is for middleclicked links and such
  overrideHandleLinkClick : function() {
  
    var origHandleLinkClick = handleLinkClick;
    handleLinkClick = function handleLinkClick(event, href, linkNode) {
      if (event.button == 0 || event.button == 1) {
        var linkURI = makeURI(href);
        var tab = Highlander.findTabForURI(linkURI);
        if(tab) {
          SeanConnery.debug("Intercepted in handleLinkClick...");
          Highlander.selectTab(tab);
          return true;
        }
      }
      return origHandleLinkClick.apply(this, arguments);
    };

  },

    // right-click "open link in new window"
  overrideContextMenuOpenLink : function() {

    nsContextMenu.prototype.openLink = function() {
      var tab = Highlander.findTabForURI(this.linkURI);
      if(tab) {
        SeanConnery.debug("Intercepted in openLink...");
        Highlander.selectTab(tab);
      } else {
        openNewWindowWith(this.linkURL, this.docURL, null, false);
      }
    };
  },

  overrideContextMenuOpenLinkInTab : function() {
    // right-click "open link in new tab"
    nsContextMenu.prototype.openLinkInTab = function() {
      var tab = Highlander.findTabForURI(this.linkURI);
      if(tab) {
        SeanConnery.debug("Intercepted in openLinkInTab...");
        var win = tab.ownerDocument.defaultView;
        // focus tab and containing window
        win.getBrowser().selectedTab = tab;
        if(win != window) {
          win.focus();
        }
      } else {
        openNewTabWith(this.linkURL, this.docURL, null, null, false);
      }
    };
  },

  // this is for any action that would load a new uri besided clicking a
  // link (e.g. javascript, bookmarks, link in external application ...)
  overrideOnStateChange : function() {

    var origOnStateChange = nsBrowserStatusHandler.prototype.onStateChange;

    nsBrowserStatusHandler.prototype.onStateChange = function(aWebProgress, aRequest, aStateFlags, aStatus) {

      if(aStateFlags & Ci.nsIWebProgressListener.STATE_START &&
      aStateFlags & Ci.nsIWebProgressListener.STATE_IS_NETWORK &&
      aRequest && aWebProgress.DOMWindow == content) {
      
        //If it's not a GET request then relying on the URI is bad, abort...
        try {
          var method = aRequest.QueryInterface(Ci.nsIHttpChannel).requestMethod;
          
          if (method != "GET") {
            SeanConnery.debug("Not a GET request, aborting ...");
            origOnStateChange.apply(this, arguments);
            return;
          }
        
        } catch(ex) {
          origOnStateChange.apply(this, arguments);
          return;
        }

        var uri = aRequest.QueryInterface(Ci.nsIChannel).URI;

        var tab = Highlander.findTabForURI(uri), browser;
        if(tab) {
          // the fact that we're stopping all requests in this browser
          // means we're also stopping the previous page (if it's still
          // loading)
          browser = getBrowser();
          tab.linkedBrowser.stop();
          const NS_BINDING_ABORTED = 0x804b0002;
          aRequest.cancel(NS_BINDING_ABORTED);
          var newStateFlags = Ci.nsIWebProgressListener.STATE_STOP | Ci.nsIWebProgressListener.STATE_IS_NETWORK;
          origOnStateChange.call(this, aWebProgress, aRequest, newStateFlags, "");

          if(browser.selectedBrowser.currentURI.spec == "about:blank") {
            if(browser.mTabs.length == 1) {
              BrowserTryToCloseWindow();
            } else {
              browser.removeCurrentTab();
            }
          }
          SeanConnery.debug('Captured in onStateChange');
          Highlander.selectTab(tab);
          return;
        }
      }
      origOnStateChange.apply(this, arguments);
    };
  },

  checkHashSign : function(uri) {
    if (!SeanConnery.getBoolPref('ignoreHash')) {
      return uri.spec;
    }
    
    var pos = uri.spec.indexOf('#');
    if (pos != -1) {
      SeanConnery.debug('Cutting # bookmark of uri %1'._(uri.spec));
      return uri.spec.substr(0, pos);
    } else {
      return uri.spec;
    }
  },

  findTabForURI: function(linkURI) {
  
    linkURI = Highlander.checkHashSign(linkURI);
    
    SeanConnery.debug("Checking %1"._(linkURI));
    if(linkURI == "about:blank")
      return null;

    if (!SeanConnery.getBoolPref('enabled')) {
      SeanConnery.debug('Highlander is disabled');
      return null;
    }

    if (HighlanderWhitelist.isWhitelisted(linkURI)) {
      return null;
    }
    var tab, tabURI, browser, wins;
    try {
      if(getBrowser() && // maybe the window is still loading
      Highlander.checkHashSign(getBrowser().selectedTab.linkedBrowser.currentURI) == linkURI) {
        return null;
      }
    } catch(e) {}
    
    wins = Cc["@mozilla.org/appshell/window-mediator;1"]
            .getService(Ci.nsIWindowMediator)
              .getEnumerator("navigator:browser");
    
    while(wins.hasMoreElements()) {

      try {
        browser = wins.getNext().getBrowser();
        for(var j = 0; browser && j < browser.mTabs.length; ++j) {
          tab = browser.mTabs[j];
          tabURI = Highlander.checkHashSign(tab.linkedBrowser.currentURI);
          if(tabURI && tabURI == linkURI) {
            SeanConnery.debug("Tab with url %1 found!"._(linkURI));
            return tab;
          }
        }
      } catch(e) {
        SeanConnery.debug("ERROR: " + e);
        Components.reportError(e);
      }
    }
    return null;
  },

  selectTab: function(tab) {
    var win = tab.ownerDocument.defaultView;
    // focus tab and containing window
    win.getBrowser().selectedTab = tab;

    if(win != window) {
      setTimeout(function(){win.focus();}, 50); //async because sync wasn't working all the time
    }
  },

  onClick: function(event) {

    // those clicks with other buttons or with key modifiers are handled by
    // the modified handleLinkClick()
    if(event.button != 0 || event.ctrlKey || event.shiftKey || event.altKey || event.metaKey) {
      return true;
    }

    // let's find a link!
    var target = event.target, linkNode = target, href;
    if (!(target instanceof HTMLAnchorElement ||
          target instanceof HTMLAreaElement ||
          target instanceof HTMLLinkElement)) {

      while (linkNode && !(linkNode instanceof HTMLAnchorElement)) {
        linkNode = linkNode.parentNode;
      }
    }

    if(linkNode && linkNode.hasAttribute("href")) {
      href = linkNode.href;
    } else {
      // Try simple XLink
      var realHref, baseURI;
      linkNode = target;
      while (linkNode) {
        if (linkNode.nodeType == Node.ELEMENT_NODE) {
          wrapper = linkNode;

          realHref = wrapper.getAttributeNS("http://www.w3.org/1999/xlink", "href");
          if (realHref) {
            href = realHref;
            baseURI = wrapper.baseURI
          }
        }

        linkNode = linkNode.parentNode;
      }
      if (href) {
        href = makeURLAbsolute(baseURI, href);
      }
    }

    if(href) {
      SeanConnery.debug("Link click captured: %1"._(href));
      var tab = Highlander.findTabForURI(makeURI(href));
      if(tab) {
        event.preventDefault();
        event.stopPropagation();
        Highlander.selectTab(tab);
        return false;
      }
    }
    return true;
  },
  
  
  openWhitelist : function() {
    window.openDialog("chrome://highlander/content/whitelist.xul",
                      "whitelist",
                      "chrome,dialog,modal,centerscreen", this);
  
  },
  
  toggleEnabled : function() {
    SeanConnery.setBoolPref('enabled', !SeanConnery.getBoolPref('enabled'));
  },
  
  
  prefObserver : {

    getService : function() {
      return Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefBranchInternal);
    },

    register: function() {
      this.getService().addObserver('extensions.highlander.enabled', this, false);
    },

    unregister: function() {
      this.getService().removeObserver('extensions.highlander.enabled', this);
    },

    observe : function(subject, topic, data) {
      if (topic != 'nsPref:changed') {
        return;
      }

      if (data == 'extensions.highlander.enabled') {
        var menuitem = $('highlander-enabled');
        if (menuitem) {
          menuitem.setAttribute('checked', SeanConnery.getBoolPref('enabled'));
        }
        
      }
    }

  }
  
};

window.addEventListener("load", Highlander.onLoad, false);
window.addEventListener("unload", Highlander.onUnload, false);

