pref("extensions.highlander.debug", false);

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.highlander@einaregilsson.com.description", "chrome://highlander/locale/highlander.properties");
pref("extensions.highlander.whitelist", "[]");
pref("extensions.highlander.ignoreHash", false);
pref("extensions.highlander.enabled", true);

