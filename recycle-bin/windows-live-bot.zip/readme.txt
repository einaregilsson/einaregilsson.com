[This is the text that was on the original page http://tech.einaregilsson.com/projects/windows-live-bot]

This is a program written in C# that can log into the Windows Live messenger 
service and speak to people on Windows Live Messenger. The program uses the 
excellent DotMSN library to connect the service. The bot is defined in a .bot file. It 
has categories of answers and things to say in response to what the other person 
says. Each category has a MATCH_TYPE that specifies how to match responses 
to categories, and a list of words or phrases to match to. The bot phrases can also 
include some variables that will be replaced, such as #SENDER# for sender name, 
#BOT_NAME# for the name of the bot itself, #RANDOM_WORD# for a random word 
from the last response and more. Detailed explanation of how the bot file works is 
in the file MsnBot.bot inside the zip file that you can download. Only problem is 
that it�s in icelandic, but I�ll try to translate it someday :).

I�m currently changing the program so it can be run as a windows service or 
console program. I�ve also changed the structure of the program so the bot engine 
is independent of the bot implementation. It now dynamically inspects all .dlls in 
the program folder and finds classes that inherit from the WLiveBot.Engine.Bot 
class and can run any of them. This is only half-finished so the trunk of the source 
code won�t work properly for a while, you can check out from the 0.1 tag if you want 
a working version of the code.