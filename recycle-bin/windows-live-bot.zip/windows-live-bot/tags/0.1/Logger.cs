using System;
using System.Collections;
using System.IO;

namespace Icarus.MsnBot
{
	public delegate void LogChangedHandler(Logger sender, LogEventArgs e);

	public class Logger
	{
		private static Hashtable loggers = new Hashtable();
		private StreamWriter writer;
		private long midnight;
		public event LogChangedHandler LogChanged;
		private string todaysLog = "";
		private string loggerName;
		private string currentLogFileName;
		private string folder;
		private bool isOpen = false;
		private static string locker = "locked";

		private Logger()
		{
			midnight = DateTime.Now.Date.Ticks;
		}

		public string TodaysLog
		{
			get { return todaysLog;}
		}

		public string CurrentLogFile
		{
			get { return currentLogFileName; }
		}

		private void CheckNewFile()
		{
			lock(locker)
			{
				if (DateTime.Now.Ticks > midnight)
				{
					todaysLog = "";
					if (writer != null)
					{
						writer.Flush();
						writer.Close();
					}

					DateTime t = new DateTime(midnight);
					currentLogFileName = folder + "/" + loggerName + "." + t.ToShortDateString() + ".log";
					writer = new StreamWriter(new FileStream(currentLogFileName, FileMode.Append, FileAccess.Write));
					long day = DateTime.Now.Date.Subtract(DateTime.Now.Date.AddDays(-1)).Ticks;
					midnight += day;
				}
			}
		}

		public static Logger GetLogger(string loggername, string folder)
		{
			Logger log = (Logger) loggers[loggername.ToLower()];

			if (log == null)
			{
				log = new Logger();
				log.loggerName = loggername;
				log.folder = folder;
				loggers.Add(loggername.ToLower(), log);
			}
			return log;
		}


		public void Info(string msg)	{Write("INFO: ", msg);}
		public void Warn(string msg)	{Write("WARNING: ", msg);}
		public void Error(string msg)	{Write("ERROR: ", msg);}
		public void Crash(string msg)	{Write("CRASH: ", msg);}
		public void Text(string msg)	{Write("", msg);}

		private void Write(string prefix, string msg)
		{
			isOpen = true;
			CheckNewFile();
			DateTime now = DateTime.Now;
			string sec;
			if (now.Second < 10)
				sec = "0" + now.Second;
			else
				sec = now.Second.ToString();

			string logEntry = now.ToShortTimeString() + ":" + sec + " " + prefix + msg; 
			writer.WriteLine(logEntry);
			writer.Flush();
			logEntry = "\n" + logEntry;
			todaysLog += logEntry;

			if (LogChanged != null)
				LogChanged(this, new LogEventArgs(logEntry));
		}

		public void Close()
		{
			if (isOpen)
				writer.Close();
		}
	}

	public class LogEventArgs : EventArgs
	{
		private string logEntry;
		public LogEventArgs(string logEntry)
		{
			this.logEntry = logEntry;
		}

		public string LogEntry
		{
			get { return this.logEntry; }
		}
	}

}
