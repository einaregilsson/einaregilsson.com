namespace Icarus.MsnBot
{
	public class LogForm : System.Windows.Forms.Form
	{
		private System.Windows.Forms.RichTextBox txtLog;
		private System.ComponentModel.Container components = null;
		Logger log;
		public LogForm(Logger log, string windowTitle)
		{
			InitializeComponent();
			this.Text = windowTitle;
			this.log = log;
			txtLog.Text = log.TodaysLog;
			log.LogChanged += new LogChangedHandler(OnLogChanged);
		}

		public void OnLogChanged(Logger sender, LogEventArgs e)
		{
			txtLog.Text += e.LogEntry;
			this.Focus();
			txtLog.SelectionStart = txtLog.TextLength -2;
			txtLog.ScrollToCaret();
		}

		protected override void Dispose( bool disposing )
		{
			log.LogChanged -= new LogChangedHandler(OnLogChanged);
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(LogForm));
			this.txtLog = new System.Windows.Forms.RichTextBox();
			this.SuspendLayout();
			// 
			// txtLog
			// 
			this.txtLog.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
				| System.Windows.Forms.AnchorStyles.Left) 
				| System.Windows.Forms.AnchorStyles.Right)));
			this.txtLog.BackColor = System.Drawing.SystemColors.MenuText;
			this.txtLog.Cursor = System.Windows.Forms.Cursors.Arrow;
			this.txtLog.DetectUrls = false;
			this.txtLog.Font = new System.Drawing.Font("Tahoma", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((System.Byte)(0)));
			this.txtLog.ForeColor = System.Drawing.SystemColors.InactiveCaption;
			this.txtLog.Location = new System.Drawing.Point(0, 0);
			this.txtLog.Name = "txtLog";
			this.txtLog.ReadOnly = true;
			this.txtLog.Size = new System.Drawing.Size(496, 472);
			this.txtLog.TabIndex = 0;
			this.txtLog.Text = "";
			// 
			// LogForm
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(492, 470);
			this.Controls.Add(this.txtLog);
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.MinimumSize = new System.Drawing.Size(300, 300);
			this.Name = "LogForm";
			this.Text = "MsnBot v0.1 - Log";
			this.ResumeLayout(false);

		}
		#endregion

	}
}
