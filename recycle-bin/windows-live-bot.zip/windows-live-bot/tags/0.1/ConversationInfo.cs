using System;
using System.Collections;
using System.IO;

namespace Icarus.MsnBot
{
	public class ConversationInfo
	{
		private DateTime lastMessage;
		private ArrayList pendingReplies;
		private string email;
		private StreamWriter writer;		
		private string logName;
		private MsnBot bot;

		public ConversationInfo(string email, ArrayList pendingReplies, 
			DateTime lastMessage, MsnBot bot)
		{
			this.email = email;
			this.pendingReplies = pendingReplies;
			this.lastMessage = lastMessage;
			this.bot = bot;
			logName = "MessageLogs/" + this.email + ".txt";
			this.writer = new StreamWriter(logName, true);
		}

		public string Email
		{
			get { return email; }
		}


		public DateTime LastMessageTime
		{
			get { return lastMessage; }
			set { lastMessage = value; }
		}

		public MsnBot Bot
		{
			get { return bot; }
			set { bot = value; }
		}

		public override int GetHashCode()
		{
			return email.GetHashCode();
		}
		
		public string GetPendingReply()
		{
			if (pendingReplies.Count == 0)
				return null;
			else
			{
				string reply = (string) pendingReplies[0];
				pendingReplies.RemoveAt(0);
				return reply;
			}
		}

		public void AddPendingReply(string reply)
		{
			pendingReplies.Add(reply);
		}

		public void Close()
		{
			writer.Close();
		}

		public void TimeOut()
		{
			pendingReplies.Clear();
		}

		public void WriteMessage(string msg, string sender, DateTime time)
		{
			writer.WriteLine(time + ": " + sender + " says:");
			writer.WriteLine("\t" + msg + "\r\n");
			writer.Flush();
		}
	}
}
