using System;
using System.Collections;
using System.IO;
using System.Text;
using System.Text.RegularExpressions;

namespace Icarus.MsnBot
{
	public class MsnBot
	{
		private ArrayList categories = new ArrayList();
		private Logger log = Logger.GetLogger("cmd", "Logs");
		
		//Indices for the categories list
		private const int STANDARD			= 0; //Used when no match is found
		private const int STARTUP			= 1; //The first thing a bot says in a conversation
		private const int ERRORS			= 2; //Error messages from the bot
		private const int TIMEOUT			= 3; //Messages to send if person has stopped talking
		private const int TEXT_MATCH_START	= 4; //From this to categories.Count-1 are textMatch categories
		private Random rng = new Random();
		
		//Basic bot info, used in messages
		private string botName = "";
		private string botAuthor = "";
		private string botAuthorEmail = "";
		private string botDescription = "";

		

		public MsnBot(string filename)
		{
			log.Info("Reading bot from file: " + filename);
			ReadBotFile(filename);			
		}

		private MsnBot()
		{
			
		}

		public string Name
		{ get { return botName; } }

		public string Author
		{ get { return botAuthor; } }

		public string Description
		{ get { return botDescription; } }

		public string AuthorEmail
		{ get { return botAuthorEmail; }}


		public MsnBot Clone()
		{
			MsnBot clone = new MsnBot();
			clone.botName = this.botName;
			clone.botAuthor = this.botAuthor;
			clone.botAuthorEmail = this.botAuthorEmail;
			clone.botDescription = this.botDescription;

			clone.log = this.log;
			clone.categories = new ArrayList();

			foreach (Category cat in this.categories)
				clone.categories.Add(cat);

			return clone;
		}

		public void RunConsole(string sender)
		{

			string input;
			Console.Out.WriteLine("ConsoleBot v0.1");
			Console.Out.Write("YOU: ");
			ArrayList pending = new ArrayList();
			while ((input = Console.ReadLine()).ToLower() != "exit")
			{
				string reply;
				if (pending.Count > 0)
				{
					reply = (string) pending[0];
					pending.RemoveAt(0);
				}
				else
					reply = GetReply(input, sender);

				string[] msgs = reply.Split(new char[] {'$'});
				
				if (msgs.Length > 1)
				{
					for (int i = 1 ; i < msgs.Length; i++)
						pending.Add(msgs[i]);
				}
				string[] nowMsgs = msgs[0].Split(new char[] {'&'});
				for (int c = 0; c < nowMsgs.Length; c++)
					Console.Out.WriteLine("BOT: " + nowMsgs[c]);

				Console.Out.Write("YOU: ");
			}
		}


		
		public string GetStartupReply(string message, string sender)
		{
			log.Info("Getting startup reply for sender: " + sender);
			Category cat = (Category) categories[STARTUP];
			return ReplacePlaceholders(cat.GetRandomReply(),null, message, sender);
		}

		public string GetTimeoutReply(string sender)
		{
			log.Info("Getting timeout reply for sender: " + sender);
			Category cat = (Category) categories[TIMEOUT];
			return ReplacePlaceholders(cat.GetRandomReply(),null, null, sender);
		}

		//Get reply for a message from a sender
		public string GetReply(string message, string sender)
		{
			try
			{
				for (int i = TEXT_MATCH_START; i < categories.Count; i++)
				{
					Category cat = (Category) categories[i];
					string match = cat.GetMatch(message);
					if (match != null)
					{
						string reply = cat.GetRandomReply();
						reply = ReplacePlaceholders(reply, match, message, sender);
						return reply;// + " (MATCH = '" + match + ')';
					}
				}
				//If no match was found, return a standard reply
				return ReplacePlaceholders(((Category) categories[STANDARD]).GetRandomReply(), "", message, sender);
			}
			catch(Exception e)
			{
				log.Error("Failed to get reply. Exception: " + e.Message);
				return ReplacePlaceholders(((Category) categories[ERRORS]).GetRandomReply(), "", message, sender);
			}
		}

		//Replace the variables that are in the replies in the bot file
		private string ReplacePlaceholders(string reply, string match, string originalMessage, string sender)
		{
			try
			{
				//First are the simple replacements:
				reply = reply.Replace("#SENDER#", sender );
				reply = reply.Replace("#BOT_NAME#", botName);
				reply = reply.Replace("#BOT_AUTHOR#", botAuthor);
				reply = reply.Replace("#BOT_AUTHOR_EMAIL#", botAuthorEmail);
				reply = reply.Replace("#BOT_DESCRIPTION#", botDescription);
				
				if (originalMessage != null && originalMessage.Trim() != "")
				{
					string[] msgWords = originalMessage.Split(new char[] {' '});
					reply = reply.Replace("#RANDOM_WORD#", msgWords[rng.Next() % msgWords.Length]);
					reply = reply.Replace("#ORIGINAL_MESSAGE#", originalMessage);
				}

				if (match != null)
				{
					reply = reply.Replace("#MATCH#", match);

					//Then come the hard ones:
					Regex regMatchCutOff = new Regex(@"#<\d*>MATCH_CUT_OFF<\d>#");
					Regex regFrontCut = new Regex(@"#<\d*");
					Regex regBackCut = new Regex(@"F<\d*");
					MatchCollection matches = regMatchCutOff.Matches(reply);
					
					string regMatch, cutFront, cutBack;
					int front, back;
					for (int i = 0; i< matches.Count; i++)
					{
						regMatch = matches[i].Value;
						cutFront = regFrontCut.Match(regMatch).Value.Substring(2);
						cutBack = regBackCut.Match(regMatch).Value.Substring(2);
						front = Int32.Parse(cutFront);
						back = Int32.Parse(cutBack);
						string replacement = match.Substring(front, match.Length - front - back);
						reply = reply.Replace(regMatch, replacement);
					}
				}
			}
			catch(Exception e)
			{
				log.Error("Failed to replace placeholder. Exception: " + e.Message);		
			}
			return reply;
		}

		private void ReadBotFile(string botfile)
		{
			try
			{
				StreamReader sr = new StreamReader(botfile, Encoding.Unicode);
				string s = "";
				while (!s.ToUpper().StartsWith("$BOT_NAME="))
					s = sr.ReadLine().Trim();

				if (s.Length > "$BOT_NAME=".Length)
					botName = s.Substring("$BOT_NAME=".Length);

				s = sr.ReadLine().Trim();
				if (s.Length > "$BOT_AUTHOR=".Length)
					botAuthor = s.Substring("$BOT_AUTHOR=".Length);

				s = sr.ReadLine().Trim();
				if (s.Length > "$BOT_AUTHOR_EMAIL=".Length)
					botAuthorEmail = s.Substring("$BOT_AUTHOR_EMAIL=".Length);

				s = sr.ReadLine().Trim();
				if (s.Length > "$BOT_DESCRIPTION=".Length)
					botDescription = s.Substring("$BOT_DESCRIPTION=".Length);

				//Byrjum n� a� n� � flokkana
				Category c;
				while ( (c = ReadCategory(sr)) != null)
					categories.Add(c);

				sr.Close();
				log.Info("Successfully created bot: " + botName);
			}
			catch(Exception e)
			{
				string msg = "Failed to read bot from file: " + botfile + ". Exception: " + e.Message;
				log.Error(msg);
				throw new BotException(msg, e);
			}
		}

		//Reads in a single category, skips all whitespace
		//and comments that come before it. Returns null at end of file.
		private Category ReadCategory(StreamReader sr)
		{	
			string s = "";
			string title = "", matchType = "";
			ArrayList repliesList = new ArrayList();
			string[] matchWords = null;

			while (!title.ToUpper().Trim().StartsWith("$CATEGORY="))
			{
				title = sr.ReadLine();
				if (title == null)
					return null;
			}

			title = title.Substring("$CATEGORY=".Length);
			matchType = sr.ReadLine();
			matchType = matchType.Substring("$MATCH_TYPE=".Length).ToUpper();

			if (matchType != Category.TYPE_NONE)
			{
				string w = sr.ReadLine().Substring("$MATCH_WORDS=".Length);
				matchWords = w.Split(Category.MATCH_WORD_SPLITTER);
			}

			while ( (s = sr.ReadLine()) != null && s.Trim() != "" && !s.Trim().StartsWith("//"))
			{
				repliesList.Add(s);
			}
			
			string[] replies = new string[repliesList.Count];

			for (int i = 0; i < repliesList.Count; i++)
				replies[i] = (string) repliesList[i];

			return new Category(title, matchType, matchWords, replies);
		}

		public override string ToString()
		{
			return botName;
		}


		public void TestCategories()
		{
			string junkText = " asdf lkjlk wleiru lkj lkj ";
			foreach (Category cat in categories)
			{

				if (cat.MatchType != Category.TYPE_NONE
					&& cat.MatchType != Category.TYPE_REGEX)
				{
					string[] words = cat.MatchWords;

					for (int i=0; i < words.Length; i++)
					{
						string matchTest = null;
						if (cat.MatchType == Category.TYPE_BEGINS_WITH)
							matchTest = words[i] + junkText;
						else if (cat.MatchType == Category.TYPE_ENDS_WITH)
							matchTest = junkText + words[i];
						else if (cat.MatchType == Category.TYPE_CONTAINS)
							matchTest = junkText + words[i] + junkText;
						else if (cat.MatchType == Category.TYPE_IS_EXACTLY)
							matchTest = words[i];

						string match = null;
						for (int c = 0; c < categories.Count; c++)
						{
							Category cat2 = (Category) categories[c];
							match = cat2.GetMatch(matchTest);
							if (match != null)
							{
								if (cat.Title == cat2.Title)
									log.Info("Word '" + words[i] + "' was correctly matched in category: " + cat2.Title);
								else
									log.Warn("Word '" + words[i] + "' was matched in category: " + cat2.Title + ", should have been in " + cat.Title);

								break;
							}
						}

						if (match == null)
							log.Warn("Word '" + words[i] + "' was not matched in any category");

					}
				}
			}
		}


	}

	public class BotException : Exception
	{
		public BotException(string msg) : base(msg)
		{}

		public BotException(string msg, Exception innerException) : base(msg, innerException)
		{}
	}

}
