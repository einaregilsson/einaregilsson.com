from WLiveBot.Engine import Bot
from XihSolutions.DotMSN import TextMessage
from System.IO import Path, Directory, FileInfo


class FileSystemBot(Bot):
    
    def Initialize(self):
        self.folder = 'c:\\'

    def MessageReceived(self, msgr, sender, message):
        txt = message.Text.lower().strip()
        
        if txt == 'cd':
            self.Send(msgr, 'Working folder is %s' % self.folder)
        elif txt.startswith('cd '):
            txt = txt[3:]
            tmp_folder = Path.Combine(self.folder, txt)
            
            if Directory.Exists(tmp_folder):
                self.folder = tmp_folder
                self.Send(msgr, 'Working folder changed to %s' % self.folder)
            else:
                self.Send(msgr, 'Folder %s does not exist!' % tmp_folder)
        elif txt == 'dir':
            self.Send(msgr, msg)


    def dircmd(self):
        entries = [FileInfo(f) for f in Directory.GetFileSystemEntries(self.folder)]
        msg = ''
        for f in entries:
            date = f.LastWriteTime.ToString('dd.MM.yyyy  hh:mm')
            if Directory.Exists(f.FullName):
                size_or_dir = '   <DIR>        '
            else:
                size_or_dir = f.Length.ToString("#,###").rjust(17)
            name = f.Name
            msg += '\n%s %s %s' % (date, size_or_dir, name)
        return msg
    
    def Send(self, msgr, txt):
        msg = TextMessage(txt)
        msg.Font = '"Courier New"'
        msgr.SendTextMessage(msg)
        
    def Shutdown(self):
        pass
        
    def ConversationCreated(self, conversation):
        pass

    @property
    def Name(self):
       return "FileSystemBot"
       
    @property
    def DisplayName(self):
       return "FileSystemBot"

AddBot(FileSystemBot())       