using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using log4net;

namespace WLiveBot.ExampleBots.TextBot
{
    /// <summary>
    /// A class to prepare the replies before they are sent, replacing placeholder
    /// words and more.
    /// </summary>
    public class ReplyFixer
    {
        #region Members
        private Random _rng = new Random();
        #endregion

        #region Logging
        private ILog _log = LogManager.GetLogger(typeof(ReplyFixer));
        protected ILog Log { get { return _log; } }
        #endregion

        #region Public Methods
        /// <summary>
        /// Replaces all placeholders that are in the reply with their correct values.
        /// </summary>
        /// <param name="reply">The reply being fixed</param>
        /// <param name="match">The match that was made in a Category</param>
        /// <param name="originalMessage">The original message from sender</param>
        /// <param name="sender">Sender email</param>
        /// <param name="bot">The bot instance</param>
        /// <returns>The reply string with all placeholder vars replaced</returns>
        public string ReplacePlaceholders(string reply, string match, string originalMessage, string sender, TextBot bot)
        {
            try
            {
                reply = ReplaceSimpleVariables(reply, bot);
                reply = ReplaceSender(reply, sender);
                reply = ReplaceOriginalMessageWords(reply, originalMessage);
                reply = ReplaceMatch(reply, match);
                reply = ReplaceMatchCutoffs(reply, match);
            }
            catch (Exception e)
            {
                Log.ErrorFormat("Failed to replace placeholder. Exception: {0}", e.Message);
            }
            return reply;
        }
        #endregion

        #region Private Methods
        /// <summary>
        /// Replaces the simple variables like #BOT_NAME#, #BOT_AUTHOR#, #BOT_AUTHOR_EMAIL#
        /// and #BOT_DESCRIPTION#.
        /// </summary>
        /// <param name="reply">The reply being fixed</param>
        /// <param name="bot">The bot instance</param>
        /// <returns>Reply with placeholders replaced</returns>
        private string ReplaceSimpleVariables(string reply, TextBot bot)
        {
            return reply.Replace("#BOT_NAME#", bot.BotName)
                        .Replace("#BOT_AUTHOR#", bot.BotAuthor)
                        .Replace("#BOT_AUTHOR_EMAIL#", bot.BotAuthorEmail)
                        .Replace("#BOT_DESCRIPTION#", bot.BotDescription);

        }

        /// <summary>
        /// Replaces the #SENDER# variable
        /// </summary>
        /// <param name="reply">The reply being fixed</param>
        /// <param name="sender">The sender email</param>
        /// <returns>Reply with placeholders replaced</returns>
        private string ReplaceSender(string reply, string sender)
        {
            return reply.Replace("#SENDER#", sender);
        }

        /// <summary>
        /// Replaces the placeholders dealing with words from the original message, the
        /// #RANDOM_WORD# and #ORIGINAL_MESSAGE# placeholders.
        /// </summary>
        /// <param name="reply">The reply being fixed</param>
        /// <param name="originalMessage">The original message received</param>
        /// <returns>Reply with placeholders replaced</returns>
        private string ReplaceOriginalMessageWords(string reply, string originalMessage)
        {
            if (!String.IsNullOrEmpty(originalMessage))
            {
                string[] msgWords = originalMessage.Split(new char[] { ' ' });
                reply = reply.Replace("#RANDOM_WORD#", msgWords[_rng.Next() % msgWords.Length]);
                reply = reply.Replace("#ORIGINAL_MESSAGE#", originalMessage);
            }
            return reply;
        }

        /// <summary>
        /// Replaces the placeholder #MATCH# with the match words.
        /// </summary>
        /// <param name="reply">The reply being fixed</param>
        /// <param name="match">The words that matched in the reply</param>
        /// <returns>Reply with placeholders replaced</returns>
        private string ReplaceMatch(string reply, string match)
        {
            return String.IsNullOrEmpty(match) ? reply : reply.Replace("#MATCH#", match);
        }

        /// <summary>
        /// Replaces the placeholder #MATCH_CUT_OFF# with the match words formatted
        /// according to the numbers surrounding #MATCH_CUT_OFF#.
        /// </summary>
        /// <param name="reply">The reply being fixed</param>
        /// <param name="match">The words that matched in the reply</param>
        /// <returns>Reply with placeholders replaced</returns>
        private string ReplaceMatchCutoffs(string reply, string match)
        {
            if (String.IsNullOrEmpty(match))
            {
                return reply;
            }

            Regex rx = new Regex(@"#<(\d+)>MATCH_CUT_OFF<(\d+)>#");
            MatchCollection matches = rx.Matches(reply);

            int front, back;
            foreach (Match replyMatch in matches)
            {
                front = Int32.Parse(replyMatch.Groups[1].Value);
                back = Int32.Parse(replyMatch.Groups[2].Value);
                string replacement = match.Substring(front, match.Length - front - back);
                reply = reply.Replace(replyMatch.Value, replacement);
            }

            return reply;
        }
        #endregion
    }
}
