using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using log4net;

namespace WLiveBot.ExampleBots.TextBot
{
    /// <summary>
    /// Class for parsing the configuration file and loading the categories.
    /// </summary>
    internal class TextBotLoader
    {
        #region Members
        private StreamReader _reader;
        private Dictionary<string, string> _vars = new Dictionary<string,string>();
        private List<Category> _categories = new List<Category>();
        #endregion

        #region Properties

        /// <summary>
        /// Bot's display name
        /// </summary>
        public string BotName { get { return _vars["$BOT_NAME"]; } }
        
        /// <summary>
        /// Bot author's name
        /// </summary>
        public string BotAuthor { get { return _vars["$BOT_AUTHOR"]; } }
        
        /// <summary>
        /// Bot author's email address
        /// </summary>
        public string BotAuthorEmail { get { return _vars["$BOT_AUTHOR_EMAIL"]; } }
        
        /// <summary>
        /// Description for bot
        /// </summary>
        public string BotDescription { get { return _vars["$BOT_DESCRIPTION"]; } }
        
        /// <summary>
        /// List of categories from the bot config file
        /// </summary>
        public List<Category> Categories { get { return _categories; } }
        #endregion

        #region Logging
        private ILog _log = LogManager.GetLogger(typeof(TextBotLoader));
        private ILog Log { get { return _log; } }
        #endregion

        #region Load Bot File
        /// <summary>
        /// Reads in all info from the botfile.
        /// </summary>
        /// <param name="botfile">Path to bot file</param>
        public TextBotLoader(string botfile)
        {
            ReadBotFile(botfile);
        }

        /// <summary>
        /// Parses the bot file and loads variables and categories.
        /// </summary>
        /// <param name="botfile">Path to botfile</param>
        private void ReadBotFile(string botfile)
        {
            try
            {
                if (_reader != null)
                {
                    throw new InvalidOperationException("ReadBotFile has already been called and should not be called again!");
                }
                _reader = new StreamReader(botfile, Encoding.Unicode);
                ReadVariables();
                ReadCategories();
                _reader.Close();
            }
            catch (Exception ex)
            {
                Log.ErrorFormat("Failed to load bot from file: {0}", ex);
                throw ex;
            }
        }
        #endregion

        #region Read Variables
        /// <summary>
        /// Reads all the variables from the bot config file
        /// </summary>
        private void ReadVariables()
        {
            ReadVariable("$BOT_NAME");
            ReadVariable("$BOT_AUTHOR");
            ReadVariable("$BOT_AUTHOR_EMAIL");
            ReadVariable("$BOT_DESCRIPTION");
        }

        /// <summary>
        /// Reads a variable from the beginning of the bot file.
        /// </summary>
        /// <param name="varName">Variable name</param>
        private void ReadVariable(string varName)
        {
            string s;
            do
            {
                s = _reader.ReadLine().Trim();
            } while (!s.ToUpper().StartsWith(varName + "="));
            _vars.Add(varName, s.Substring(varName.Length + 1));
        }
        #endregion

        #region Read Categories
        /// <summary>
        /// Reads in the categories from the config file
        /// </summary>
        private void ReadCategories()
        {
            Category c;
            while ((c = ReadCategory()) != null)
                _categories.Add(c);
        }

        /// <summary>
        /// Reads in a single category, skips all whitespace
        /// and comments that come before it. Returns null at end of file.
        /// </summary>
        /// <returns>Category object</returns>
        private Category ReadCategory()
        {
            string s = "";
            string title = "", matchType = "";
            List<string> repliesList = new List<string>();
            List<string> matchWords = null;

            while (!title.ToUpper().Trim().StartsWith("$CATEGORY="))
            {
                title = _reader.ReadLine();
                if (title == null)
                    return null;
            }

            title = title.Substring("$CATEGORY=".Length);
            matchType = _reader.ReadLine();
            matchType = matchType.Substring("$MATCH_TYPE=".Length).ToUpper();

            if (matchType != Category.TYPE_NONE)
            {
                string w = _reader.ReadLine().Substring("$MATCH_WORDS=".Length);
                matchWords = new List<string>(w.Split(Category.MATCH_WORD_SPLITTER));
            }

            while ((s = _reader.ReadLine()) != null && s.Trim() != "" && !s.Trim().StartsWith("//"))
            {
                repliesList.Add(s);
            }

            return new Category(title, matchType, matchWords, repliesList);
        }
        #endregion
    }
}
