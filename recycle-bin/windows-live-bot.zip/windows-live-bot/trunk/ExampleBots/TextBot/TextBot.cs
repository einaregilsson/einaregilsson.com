using System;
using System.Collections.Generic;
using System.Text;
using System.Text.RegularExpressions;
using WLiveBot.Engine;
using XihSolutions.DotMSN;
using log4net;

namespace WLiveBot.ExampleBots.TextBot
{
    /// <summary>
    /// Bot that can talk to you, match some words in your messages and try to reply
    /// accordingly. Bot text is defined in the TextBot.conf file.
    /// </summary>
    public class TextBot : Bot
    {
        #region Members
        private TextBotLoader _loader;
        private ReplyFixer _replyFixer = new ReplyFixer();
        private PendingRepliesCollection _pendingReplies = new PendingRepliesCollection();
        #endregion

        #region Properties
        public override string Name { get { return "TextBot"; } }
        public override string DisplayName { get { return BotName; } }
        
        //Basic info about bot
        public string BotName { get { return _loader.BotName; } }
        public string BotAuthor { get { return _loader.BotAuthor; } }
        public string BotAuthorEmail { get { return _loader.BotAuthorEmail; } }
        public string BotDescription { get { return _loader.BotDescription; } }
        
        //Reply categories
        public List<Category> Categories { get { return _loader.Categories; } }
        #endregion

        #region Constants
        //Indices for the categories list
        private const int STANDARD = 0; //Used when no match is found
        private const int STARTUP = 1; //The first thing a bot says in a conversation
        private const int ERRORS = 2; //Error messages from the bot
        private const int TIMEOUT = 3; //Messages to send if person has stopped talking
        private const int TEXT_MATCH_START = 4; //From this to categories.Count-1 are textMatch categories

        //Chars to split up the reply lines
        public const char REPLY_SPLITTER = '$';
        public const char SINGLE_REPLY_SPLITTER = '&';
        #endregion

        #region Logging
        private ILog _log = LogManager.GetLogger(typeof(Category));
        protected ILog Log { get { return _log; } }
        #endregion

        #region Overriden methods
        
        /// <summary>
        /// Loads the answers from the config file.
        /// </summary>
        public override void Initialize() 
        {
            _loader = new TextBotLoader(this.ConfigFilePath);
            this.WordsPerMinute = 65;
        }

        /// <summary>
        /// Answers the message received from the sender.
        /// </summary>
        /// <param name="msgHandler">DotMSN object to send messages</param>
        /// <param name="sender">Sender of message</param>
        /// <param name="message">Message</param>
        public override void MessageReceived(SBMessageHandler msgHandler, Contact sender, TextMessage message) 
        {
            string[] replies = GetReply(message.Text, sender.Mail);
            foreach (string reply in replies)
            {
                SendTextMessage(msgHandler, reply);
            }
        }

        public override void ShutDown() { /*Do nothing*/ }
        public override void ConversationCreated(Conversation conversation) { /*We don't really care*/ }

        #endregion

        #region Get Replies
        /// <summary>
        /// This should get a reply from the STARTUP category of replies. Is currently not
        /// used but will be in a future version.
        /// </summary>
        /// <param name="message">Received message</param>
        /// <param name="sender">Sender of message</param>
        /// <returns>Reply to message</returns>
        public string GetStartupReply(string message, string sender)
        {
            Log.InfoFormat("Getting startup reply for sender: {0}", sender);
            return Categories[STARTUP].GetRandomReply(sender);
        }

        /// <summary>
        /// This should get a reply from the TIMEOUT category of replies. In a future version
        /// it will be called when a sender has stopped replying to us. Then we can send him
        /// one final timeout message.
        /// </summary>
        /// <param name="message">Received message</param>
        /// <param name="sender">Sender of message</param>
        /// <returns>Reply to message</returns>
        public string GetTimeoutReply(string sender)
        {
            Log.InfoFormat("Getting timeout reply for sender: {0}", sender);
            return Categories[TIMEOUT].GetRandomReply(sender);
        }

        /// <summary>
        /// Gets a reply to the given message, by trying to match it to the reply category match words,
        /// and if that fails get a reply from the standard reply category.
        /// </summary>
        /// <param name="message">Received message</param>
        /// <param name="sender">Sender of message</param>
        /// <returns>Array of reply strings</returns>
        public string[] GetReply(string message, string sender)
        {
            if (_pendingReplies.HasPendingReplies(sender))
            {
                return _pendingReplies.GetPendingReply(sender).Split(SINGLE_REPLY_SPLITTER);
            }

            string reply = null;
            try
            {
                for (int i = TEXT_MATCH_START; i < Categories.Count; i++)
                {
                    Category cat = Categories[i];
                    string match = cat.GetMatch(message);
                    if (match != null)
                    {
                        reply = cat.GetRandomReply(sender);
                        reply = _replyFixer.ReplacePlaceholders(reply, match, message, sender,this);
                    }
                }
                if (reply == null)
                {
                    //If no match was found, return a standard reply
                    reply = _replyFixer.ReplacePlaceholders(Categories[STANDARD].GetRandomReply(sender), null, message, sender, this);
                }

                _pendingReplies.AddPendingReplies(sender, reply.Split(REPLY_SPLITTER));
                return _pendingReplies.GetPendingReply(sender).Split(SINGLE_REPLY_SPLITTER);
                
            }
            catch (Exception e)
            {
                Log.ErrorFormat("Failed to get reply. Exception: {0}", e.Message);
                //return directly, error messages should not queue up their parts.
                return new string[] { _replyFixer.ReplacePlaceholders(Categories[ERRORS].GetRandomReply(sender), null, message, sender, this) };
            }

        }
        #endregion
    }

    #region PendingRepliesCollection
    /// <summary>
    /// Class to keep track of pending replies for different senders.
    /// </summary>
    internal class PendingRepliesCollection 
    {
        private Dictionary<string, Queue<string>> _replies = new Dictionary<string, Queue<string>>();

        /// <summary>
        /// Adds pending replies for a given sender.
        /// </summary>
        /// <param name="email">Email address of sender</param>
        /// <param name="pendingReplies">Collection of replies</param>
        public void AddPendingReplies(string email, IEnumerable<string> pendingReplies)
        {
            if (!_replies.ContainsKey(email))
            {
                _replies.Add(email, new Queue<string>());
            }
            if (HasPendingReplies(email))
            {
                throw new ArgumentException("Can't add new replies for " + email + " to PendingRepliesCollection, there are already pending replies that have not been fetched!");
            }

            foreach(string s in pendingReplies)
            {
                _replies[email].Enqueue(s);
            }
        }

        /// <summary>
        /// Checks if a given sender has pending replies.
        /// </summary>
        /// <param name="email">Email of sender</param>
        /// <returns>True if there are pending replies, otherwise false.</returns>
        public bool HasPendingReplies(string email)
        {
            return _replies.ContainsKey(email) && _replies[email].Count > 0;
        }

        /// <summary>
        /// Gets pending reply for given sender.
        /// </summary>
        /// <param name="email">Email address of sender</param>
        /// <returns>Reply if it exists, otherwise null</returns>
        public string GetPendingReply(string email)
        {
            if (HasPendingReplies(email))
            {
                return _replies[email].Dequeue();
            }
            else
            {
                return null;
            }
        }
    }
    #endregion
}






