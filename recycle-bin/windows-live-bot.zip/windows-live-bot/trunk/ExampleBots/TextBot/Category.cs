using System;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using log4net;

namespace WLiveBot.ExampleBots.TextBot
{
    /// <summary>
    /// Class for a category of replies. A category contains match words that are used to try
    /// to match a senders message, and a collection of replies.
    /// </summary>
    public class Category
    {

        #region Constants
        //Category types
        public const string TYPE_BEGINS_WITH = "BEGINSWITH";
        public const string TYPE_ENDS_WITH = "ENDSWITH";
        public const string TYPE_CONTAINS = "CONTAINS";
        public const string TYPE_IS_EXACTLY = "ISEXACTLY";
        public const string TYPE_REGEX = "REGEX";
        public const string TYPE_NONE = "NONE";

        public const char MATCH_WORD_SPLITTER = '|';
        #endregion

        #region Members
        private string _title;
        private string _matchType;
        private List<string> _matchWords;
        private List<Regex> _regexes;
        private List<string> _replies = new List<string>();
        private Random _rng = new Random();
        private Dictionary<string, List<int>> _repliesLeft = new Dictionary<string, List<int>>();
        #endregion

        #region Properties
        /// <summary>
        /// List of this category's match words
        /// </summary>
        public List<string> MatchWords { get { return _matchWords; } }
        
        /// <summary>
        /// This category's match type, one of the TYPE_* constants.
        /// </summary>
        public string MatchType { get { return _matchType; } }
        
        /// <summary>
        /// This category's title.
        /// </summary>
        public string Title { get { return _title; } }
        #endregion

        #region Logging
        private ILog _log = LogManager.GetLogger(typeof(Category));
        protected ILog Log { get { return _log; } }
        #endregion

        #region Constructor
        /// <summary>
        /// Constructs a new category.
        /// </summary>
        /// <param name="title">Category title</param>
        /// <param name="matchType">Type of match, one of the TYPE_* constants</param>
        /// <param name="matchWords">List of matchwords</param>
        /// <param name="replies">List of replies</param>
        public Category(string title, string matchType, List<string> matchWords, List<string> replies)
        {
            _title = title;
            _matchType = matchType;
            _matchWords = matchWords;
            _replies = replies;
            FixMatchWords();

            Log.DebugFormat("Created new Category: {0}", title);
        }
        #endregion

        #region Get Match
        /// <summary>
        /// Checks if this category contains a match for the given message.
        /// </summary>
        /// <param name="msg">Message being checked for a match</param>
        /// <returns>The match if it exists, otherwise null</returns>
        public string GetMatch(string msg)
        {
            try
            {
                if (_matchType == TYPE_BEGINS_WITH)
                    return GetBeginsWithMatch(msg);
                else if (_matchType == TYPE_ENDS_WITH)
                    return GetEndsWithMatch(msg);
                else if (_matchType == TYPE_CONTAINS)
                    return GetContainsMatch(msg);
                else if (_matchType == TYPE_IS_EXACTLY)
                    return GetIsExactlyMatch(msg);
                else if (_matchType == TYPE_REGEX)
                    return GetRegexMatch(msg);
            }
            catch (Exception e)
            {
                Log.ErrorFormat("Error in getting match for msg '{0}', exception: {1}", msg, e.Message);
            }
            return null;
        }

        /// <summary>
        /// Checks match words for a BEGINS_WITH match.
        /// </summary>
        /// <param name="msg">The message being checked</param>
        /// <returns>True if msg begins with any of the match words, otherwise false</returns>
        private string GetBeginsWithMatch(string msg)
        {
            msg = msg.TrimStart();
            string lmsg = msg.ToLower();

            for (int i = 0; i < _matchWords.Count; i++)
            {
                if (lmsg.StartsWith(_matchWords[i]))
                    return msg.Substring(0, _matchWords[i].Length);
            }
            return null;
        }

        /// <summary>
        /// Checks match words for a ENDS_WITH match.
        /// </summary>
        /// <param name="msg">The message being checked</param>
        /// <returns>True if msg ends with any of the match words, otherwise false</returns>
        private string GetEndsWithMatch(string msg)
        {
            msg = msg.TrimEnd();
            string lmsg = msg.ToLower();

            for (int i = 0; i < _matchWords.Count; i++)
            {
                if (lmsg.EndsWith(_matchWords[i]))
                    return msg.Substring(msg.Length - _matchWords[i].Length, _matchWords[i].Length);
            }
            return null;
        }

        /// <summary>
        /// Checks match words for a IS_EXACTLY match.
        /// </summary>
        /// <param name="msg">The message being checked</param>
        /// <returns>True if msg equals any of the match words, otherwise false</returns>
        private string GetIsExactlyMatch(string msg)
        {
            msg = msg.Trim();
            string lmsg = msg.ToLower();
            for (int i = 0; i < _matchWords.Count; i++)
            {
                if (lmsg == _matchWords[i])
                    return msg;
            }
            return null;
        }

        /// <summary>
        /// Checks match words for a CONTAINS match.
        /// </summary>
        /// <param name="msg">The message being checked</param>
        /// <returns>True if msg begins contains any of the match words, otherwise false</returns>
        private string GetContainsMatch(string msg)
        {
            msg = msg.Trim();
            string lmsg = msg.ToLower();
            for (int i = 0; i < _matchWords.Count; i++)
            {
                int index = lmsg.IndexOf(_matchWords[i]);
                if (index != -1)
                    return msg.Substring(index, _matchWords[i].Length);
            }
            return null;
        }

        /// <summary>
        /// Checks match words for a REGEX match.
        /// </summary>
        /// <param name="msg">The message being checked</param>
        /// <returns>True if msg matches any of the regular expression matchwords, otherwise false</returns>
        private string GetRegexMatch(string msg)
        {
            msg = msg.Trim();
            string lmsg = msg.ToLower();
            for (int i = 0; i < _regexes.Count; i++)
            {
                Match m = _regexes[i].Match(lmsg);
                if (m.Success)
                    return m.Value;
            }
            return null;
        }
        #endregion

        #region Private
        /// <summary>
        /// Sets up the matchwords, converting them to lowercase and trimming whitespace.
        /// </summary>
        private void FixMatchWords()
        {
            if (_matchType == TYPE_REGEX)
            {
                _regexes = new List<Regex>(_matchWords.Count);
                foreach (string pattern in _matchWords)
                {
                    _regexes.Add(new Regex(pattern));
                }
            }
            else if (_matchType != TYPE_NONE)
            {
                //Get the matchwords ready:
                for (int i = 0; i < _matchWords.Count; i++)
                {
                    _matchWords[i] = _matchWords[i].ToLower();

                    if (_matchType == TYPE_BEGINS_WITH)
                        _matchWords[i] = _matchWords[i].TrimStart();
                    else if (_matchType == TYPE_ENDS_WITH)
                        _matchWords[i] = _matchWords[i].TrimEnd();
                    else if (_matchType == TYPE_IS_EXACTLY)
                        _matchWords[i] = _matchWords[i].Trim();
                    else if (_matchType != Category.TYPE_CONTAINS)
                        Log.WarnFormat("Got non recognized MatchType: {0}", _matchType);
                }
            }
        }

        /// <summary>
        /// Returns a list of reply indices that can then be used
        /// to keep track of which replies have been used.
        /// </summary>
        /// <returns>List of indices</returns>
        private List<int> GetReplyIndices()
        {
            List<int> l = new List<int>();
            for (int i = 0; i < _replies.Count; i++)
            {
                l.Add(i);
            }
            return l;
        }
        #endregion

        #region Get Random Reply
        /// <summary>
        /// Returns a random reply for this category. The category keeps track of which replies
        /// have been used for the given uniqueID and won't use them again until all replies 
        /// have been used, so you can't get the same reply twice in a row for the same uniqueID.
        /// </summary>
        /// <param name="uniqueId">A unique id for the persion requesting the reply.</param>
        /// <returns>A random reply from this category</returns>
        public string GetRandomReply(string uniqueId)
        {
            List<int> _left = new List<int>();
            if (!_repliesLeft.ContainsKey(uniqueId))
                _repliesLeft.Add(uniqueId, GetReplyIndices());

            _left = _repliesLeft[uniqueId];

            if (_left.Count == 0)
            {
                _repliesLeft[uniqueId] = GetReplyIndices();
                _left = _repliesLeft[uniqueId];
            }

            int index = _left[_rng.Next() % _left.Count];
            _left.Remove(index);
            return _replies[index];
        }
        #endregion
    }
}

