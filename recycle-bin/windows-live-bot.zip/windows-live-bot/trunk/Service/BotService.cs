using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.ServiceProcess;
using System.Text;
using System.Threading;
using WLiveBot.Engine;
using log4net;

namespace WLiveBot.Service
{
    public partial class BotService : ServiceBase
    {
        private static BotService _service;
        private Engine.BotEngine _engine;
        private ILog _log = LogManager.GetLogger(typeof(BotService));
        private ILog Log { get { return _log; } }

        public BotService()
        {
            InitializeComponent();
        }

        public void StartConsole(string[] args)
        {
            Log.Info("Starting in Console mode");
            OnStart(args);
        }

        protected override void OnStart(string[] args)
        {
            Log.Info("Starting WLivebot Service");
            _engine = BotEngine.Instance;
            _engine.Start(AppSettings.Username, AppSettings.Password, AppSettings.StartupBot, AppSettings.AdministratorEmail);
            Log.Info("Started WLiveBot engine");
        }

        public void StopConsole()
        {
            OnStop();
        }

        protected override void OnStop()
        {
            Log.Info("Shutting down WLiveBot Service");
            _engine.Stop();
        }

        static void Main(string[] args)
        {
            log4net.Config.XmlConfigurator.Configure();

            _service = new BotService();

            if (Environment.UserInteractive)
            {
                _service.StartConsole(args);
                Console.Read();
                _service.StopConsole();
            }
            else
            {
                ServiceBase.Run(_service);
            }
        }
    }
}

