using System;
using System.Collections.Generic;
using System.Text;
using System.Configuration;

namespace WLiveBot.Service
{
    public class AppSettings
    {
        private static AppSettingsReader _reader = new AppSettingsReader();
        public static string Username
        {
            get { return (string) _reader.GetValue("Username", typeof(string)); }
        }

        public static string Password
        {
            get { return (string)_reader.GetValue("Password", typeof(string)); }
        }

        public static string StartupBot
        {
            get { return (string)_reader.GetValue("StartupBot", typeof(string)); }
        }

        public static string AdministratorEmail
        {
            get { return (string)_reader.GetValue("AdministratorEmail", typeof(string)); }
        }
    }
}
