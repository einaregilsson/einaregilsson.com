namespace WLiveBot.Service
{
    partial class BotService
    {
        private System.ComponentModel.IContainer components = null;

        protected  void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            //base.Dispose(disposing);
        }

        #region Component Designer generated code

        private void InitializeComponent()
        {
            components = new System.ComponentModel.Container();
            //this.ServiceName = "WLiveBotService";
        }

        #endregion
    }
}
