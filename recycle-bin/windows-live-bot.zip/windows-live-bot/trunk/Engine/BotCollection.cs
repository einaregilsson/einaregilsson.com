using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using System.IO;
using log4net;
using IronPython;
using IronPython.Hosting;


namespace WLiveBot.Engine
{
    public delegate void BotsReloadedEventHandler(object sender, BotsReloadedEventArgs e);
    public class BotsReloadedEventArgs : EventArgs
    {
        public BotsReloadedEventArgs(List<string> names)
        {
            _names = names;
        }
        
        private List<string> _names;

        /// <summary>
        /// Names of all bots that were reloaded.
        /// </summary>
        public List<string> BotNames
        {
            get { return _names; }
        }
    }

    /// <summary>
    /// Class that holds all loaded Bots. It will load all bots in the %APPDIR%\bots folder, both those
    /// in .dll files or .py files. Python bots will be reloaded when a .py file is changed in the folder,
    /// and a BotsReloaded event will be raised.
    /// </summary>
    public sealed class BotCollection
    {
        #region Events
        /// <summary>
        /// Raised whenever a .py file has been changed, created or deleted in the bots folder
        /// and the BotCollection has reloaded all its Python bots.
        /// </summary>
        public event BotsReloadedEventHandler BotsReloaded;
        #endregion

        #region Logging
        private ILog _log = LogManager.GetLogger(typeof(BotCollection));
        private ILog Log { get { return _log; } }
        #endregion

        #region Members
        private PythonEngine _pyEngine;
        private FileSystemWatcher _fsWatcher = new FileSystemWatcher(BotCollection.BotFolder, "*.py");
        private Dictionary<string, Bot> _dllBots = new Dictionary<string, Bot>();
        private Dictionary<string, Bot> _pythonBots = new Dictionary<string, Bot>();
        private DateTime _lastReload;
        #endregion

        #region Properties
        /// <summary>
        /// The path for the folder where the bot files are kept. It's a 'bots' folder under
        /// the main application folder.
        /// </summary>
        public static string BotFolder
        {
            get { return Path.Combine(Path.GetDirectoryName(Assembly.GetExecutingAssembly().Location), "bots"); }
        }
        #endregion

        #region Constructor
        internal BotCollection()
        {
            Log.Debug("Loading bots into BotCollection");
            InitializePythonEngine();
            LoadDllBots();
            LoadPythonBots();
            _fsWatcher.EnableRaisingEvents = true;
            _fsWatcher.Changed += new FileSystemEventHandler(PythonFileChanged);
            _fsWatcher.Deleted += new FileSystemEventHandler(PythonFileChanged);
            _fsWatcher.Created += new FileSystemEventHandler(PythonFileChanged);
        }
        #endregion

        #region Dll Bots
        /// <summary>
        /// Loads all bot objects it can find in .NET assemblies that are stored in the %APPDIR%\bots folder.
        /// </summary>
        private void LoadDllBots()
        {
            foreach (string file in Directory.GetFiles(BotFolder, "*.dll", SearchOption.TopDirectoryOnly))
            {
                Log.DebugFormat("Found bot assembly: {0}", file);
                try
                {
                    Assembly ass = Assembly.LoadFile(file);
                    foreach (Type t in ass.GetTypes())
                    {
                        if (typeof(Bot).IsAssignableFrom(t) && typeof(Bot) != t)
                        {
                            Log.InfoFormat("Loading bot: {0}", t.Name);
                            _dllBots.Add(t.Name, (Bot)Activator.CreateInstance(t));
                        }
                    }
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Failed to load assembly {0}: {1}", file, ex);
                }
            }
        }
        #endregion

        #region Python Bots
        /// <summary>
        /// Sets up the python engine so the Python bots can be loaded.
        /// </summary>
        private void InitializePythonEngine()
        {
            Log.Debug("Initializing Python Engine");
            _pyEngine = new PythonEngine();
            _pyEngine.Globals.Add("bots", _pythonBots);
            _pyEngine.Execute("def AddBot(bot): bots.Add(bot.Name, bot)");

            //You can print directly to the console, although you should use log4net
            _pyEngine.SetStandardOutput(Console.OpenStandardOutput());
            _pyEngine.SetStandardError(Console.OpenStandardError());

            Log.Debug("Loading assemblies for Pythone Engine");
            //Preload assemblies so python bots won't have to mess around with clr.AddReference
            _pyEngine.LoadAssembly(Assembly.GetExecutingAssembly());
            _pyEngine.LoadAssembly(Assembly.GetAssembly(typeof(log4net.LogManager)));
            _pyEngine.LoadAssembly(Assembly.GetAssembly(typeof(XihSolutions.DotMSN.Messenger)));
        }

        /// <summary>
        /// Executes all .py files in the %APPDIR%\bots folder. The .py files themselves are responsible
        /// for adding their bots to the collection since we have no way of knowing what bots are in there
        /// or what they are named.
        /// </summary>
        private void LoadPythonBots()
        {
            foreach (string file in Directory.GetFiles(BotFolder, "*.py", SearchOption.TopDirectoryOnly))
            {
                Log.DebugFormat("Found Python file: {0}", file);
                try
                {
                    _pyEngine.ExecuteFile(file);
                }
                catch (Exception ex)
                {
                    Log.ErrorFormat("Failed to execute python file {0}: {1}", file, ex);
                }
            }
        }

        /// <summary>
        /// Called whenever a .py file is changed in the bots folder. Initializes a new Python Engine, 
        /// reloads ALL Python bots and then raises the BotsReloaded event.
        /// </summary>
        /// <param name="sender">BotCollection</param>
        /// <param name="e">EventArgs with names of reloaded bots.</param>
        private void PythonFileChanged(object sender, FileSystemEventArgs e)
        {
            Log.DebugFormat("A Python file has been changed in the bots folder");
            lock (this)
            {
                if (DateTime.Now.Subtract(_lastReload).Seconds < 5)
                {
                    Log.DebugFormat("Only {0} seconds since last FileWatcher event, aborting", DateTime.Now.Subtract(_lastReload));
                    return;
                }
                _lastReload = DateTime.Now;
            }
            //Small sleep because we usually get a file lock exception otherwise
            System.Threading.Thread.Sleep(2000);
            _pyEngine.Dispose();
            InitializePythonEngine();
            ReloadPythonBots();
            Log.Debug("Finished reloading Python bots");
        }

        /// <summary>
        /// Reloads all Python bots in the bots folder.
        /// </summary>
        private void ReloadPythonBots()
        {
            _pythonBots.Clear();
            LoadPythonBots();
            if (BotsReloaded != null)
            {
                BotsReloaded(this, new BotsReloadedEventArgs(new List<string>(_pythonBots.Keys)));
            }
        }

        #endregion

        #region Public Methods
        /// <summary>
        /// Returns true if the collection contains a bot with the given name.
        /// </summary>
        /// <param name="botName">Name of the bot</param>
        /// <returns>true if the bot exists in the collection, otherwise false</returns>
        public bool ContainsBot(string botName)
        {
            return _dllBots.ContainsKey(botName) || _pythonBots.ContainsKey(botName);
        }

        /// <summary>
        /// Returns a Bot object with the given name.
        /// </summary>
        /// <param name="name">Name of the bot to get.</param>
        /// <returns>A Bot object.</returns>
        public Bot GetBot(string name)
        {
            Log.DebugFormat("Getting bot '{0}'", name);
            if (_dllBots.ContainsKey(name))
            {
                return _dllBots[name];
            }
            else if (_pythonBots.ContainsKey(name))
            {
                return _pythonBots[name];
            }
            else
            {
                throw new ArgumentException("No bot with name '" + name + "' exists!");
            }
        }
        #endregion
    }
}
