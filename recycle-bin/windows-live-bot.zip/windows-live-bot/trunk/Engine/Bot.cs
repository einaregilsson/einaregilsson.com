using System;
using System.IO;
using System.Collections.Generic;
using System.Text;
using WLiveBot.Engine;
using XihSolutions.DotMSN;
using log4net;
using log4net.Appender;

namespace WLiveBot.Engine
{
    /// <summary>
    /// The class that all Bot implementations should inherit from. It provides the interface that any new
    /// bot must implement (See "Interface" region) and some convenience methods to access contacts, send 
    /// messages and access the DotMSN API.
    /// </summary>
    public abstract class Bot
    {
        #region Members
        /// <summary>
        /// Main DotMSN object.
        /// </summary>
        private Messenger _messenger;
        private string _adminEmail;
        private int _wordsPerMinute = 0; //Default value gives no delay/typing messages.
        #endregion

        private const string MessageLogFormat = "{0} says:\n\t{1}";

        public virtual int WordsPerMinute
        {
            get { return _wordsPerMinute; }
            set { _wordsPerMinute = value; }
        }

        protected virtual ILog MessageLog(SBMessageHandler msgHandler)
        {
            string name = "";
            foreach (string mail in msgHandler.Contacts.Keys)
            {
                name += ", " + mail;
            }
            name = name.Substring(2);
            ILog log = LogManager.GetLogger(name);
            log4net.Repository.Hierarchy.Logger logger = (log4net.Repository.Hierarchy.Logger)log.Logger;

            if (logger.Appenders.Count == 0)
            {
                FileAppender appender = new FileAppender();
                appender.Layout = new log4net.Layout.PatternLayout("%level: %message%newline");
                appender.ImmediateFlush = true;
                appender.File = "d:\\foo.log";
                logger.AddAppender(appender);
            }
            return log;
        }

        #region Properties

        /// <summary>
        /// Returns the path to the bot's config file, or null if the file doesn't exist.
        /// The config file should have the same name as the bot's .Name property, and end 
        /// with .config.
        /// </summary>
        protected virtual string ConfigFilePath
        {
            get
            {
                string path = Path.Combine(BotCollection.BotFolder, Name + ".config");
                return File.Exists(path) ? path : null;
            }
        }

        /// <summary>
        /// Returns the contents of the Bot's config file, or null if the file doesn't exist.
        /// </summary>
        protected virtual string ConfigFileContents
        {
            get
            {
                return ConfigFilePath == null ? null : System.IO.File.ReadAllText(ConfigFilePath);
            }
        }

        /// <summary>
        /// Returns the DotMSN Messenger object, which can be used to access the full DotMSN API.
        /// </summary>
        protected virtual Messenger Messenger
        {
            get { return _messenger; }
        }

        /// <summary>
        /// Returns the logged in user's contact list.
        /// </summary>
        protected virtual ContactList Contacts
        {
            get { return _messenger.ContactList; }
        }

        /// <summary>
        /// Returns the logged in user's contact groups.
        /// </summary>
        protected virtual ContactGroupList ContactGroups
        {
            get { return _messenger.ContactGroups; }
        }
        #endregion

        #region Convenience methods

        protected virtual bool IsAdministrator(Contact sender)
        {
            return sender.Mail == BotEngine.Instance.AdministratorEmail;
        }
        /// <summary>
        /// Sends a text message to a conversation, and logs it to a file.
        /// </summary>
        /// <param name="msgHandler">The DotMSN SBMessageHandler object, that you receive in MessageReceived.</param>
        /// <param name="msg">The text of the message you want to send.</param>
        protected virtual void SendTextMessage(SBMessageHandler msgHandler, string msg)
        {
            //MessageLog(msgHandler).InfoFormat(MessageLogFormat, _messenger.Owner.Name, msg);

            if (WordsPerMinute <= 0)
            {
                msgHandler.SendTextMessage(new TextMessage(msg));
                return;
            }

            double words = msg.Length / 5; //5 = characters per average word
            double seconds = words / WordsPerMinute * 60; //seconds
            seconds = Math.Max(seconds, 1);
            seconds = Math.Min(seconds, 20); //there's a limit to how long people will wait for a bot...

            while (seconds-- > 0)
            {
                msgHandler.SendTypingMessage();
                System.Threading.Thread.Sleep(1000);
            }
            msgHandler.SendTextMessage(new TextMessage(msg));
        }
        #endregion

        #region Internal implementation
        internal void InternalMessageReceived(SBMessageHandler msgHandler, Contact sender, TextMessage message)
        {
            MessageLog(msgHandler).InfoFormat(MessageLogFormat, sender.Name, message.Text);
            MessageReceived(msgHandler, sender, message);
        }

        internal void InternalInitialize(Messenger messenger)
        {
            _messenger = messenger;
            Initialize();
        }
        #endregion

        #region Interface

        /// <summary>
        /// The bots name. This is the name it will be identified by in the .config file
        /// or when switching Bots.
        /// </summary>
        public abstract string Name { get; }
        
        /// <summary>
        /// The display name. This is the name that clients that speak with the bot will see.
        /// </summary>
        public abstract string DisplayName { get; }
        
        /// <summary>
        /// Called when the bot is loaded for the first time. Bots should do their setup here, not
        /// in their constructor, because when this is called the Bot will have full access to the DotMSN API,
        /// through the .Messenger property. At construction time that is not available.
        /// </summary>
        public abstract void Initialize();
        
        /// <summary>
        /// This is called when the program is shutting down, do any clean-up work you need here.
        /// </summary>
        public abstract void ShutDown();
        
        /// <summary>
        /// This is called when a new message is received.
        /// </summary>
        /// <param name="msgHandler">The DotMSN object needed to communicate with the sender. Send it into the .SendMessage function.</param>
        /// <param name="sender">The sender of the message.</param>
        /// <param name="message">The message itself.</param>
        public abstract void MessageReceived(SBMessageHandler msgHandler, Contact sender, TextMessage message);
        
        /// <summary>
        /// Called when a new conversation has been created, either because you called .Invite or because
        /// someone else started contacting you. 
        /// </summary>
        /// <param name="conversation">DotMSN conversation object.</param>
        public abstract void ConversationCreated(Conversation conversation);
        
        #endregion
    }
}
