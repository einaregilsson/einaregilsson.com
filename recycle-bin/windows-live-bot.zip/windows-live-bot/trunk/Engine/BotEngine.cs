using System;
using System.Collections.Generic;
using System.Text;
using XihSolutions.DotMSN;
using XihSolutions.DotMSN.Core;
using log4net;

namespace WLiveBot.Engine
{
    public class BotEngine
    {
        #region Constants
        const string MsnMessengerClientID = "msmsgs@msnmsgr.com";
        const string MsnMessengerClientCode = "Q1P7W2E4J9R8U3S5";
        #endregion

        #region Member variables
        private Messenger _msn = new Messenger();
        private BotCollection _bots = new BotCollection();
        private ILog _log = LogManager.GetLogger(typeof(BotEngine));
        private Bot _activeBot;
        private string _adminEmail;

        private static BotEngine _instance = new BotEngine();
        #endregion

        #region Properties
        
        protected virtual ILog Log
        {
            get { return _log; }
        }

        public virtual string AdministratorEmail
        {
            get { return _adminEmail; }
        }
        public static BotEngine Instance
        {
            get { return _instance; }
        }

        #endregion

        #region Startup

        private BotEngine()
        {
            //Default windows client
            _msn.Credentials.ClientID = MsnMessengerClientID;
            _msn.Credentials.ClientCode = MsnMessengerClientCode;
        }



        public void Start(string username, string password, string startupBotName, string adminEmail)
        {
            _msn.Credentials.Account = username;
            _msn.Credentials.Password = password;
            _adminEmail = adminEmail;
            _bots.BotsReloaded += new BotsReloadedEventHandler(BotsReloaded);
            if (_bots.ContainsBot(startupBotName))
            {
                _activeBot = _bots.GetBot(startupBotName);
                _activeBot.InternalInitialize(_msn);
            }
            else
            {
                _activeBot = new NullBot();
                Log.ErrorFormat("Startup bot '{0}' not loaded, no active bot!", startupBotName);
            }
            AddEventHandlers();
            Connect();
        }

        private void BotsReloaded(object sender, BotsReloadedEventArgs e)
        {
            if (e.BotNames.Contains(_activeBot.Name))
            {
                _activeBot = _bots.GetBot(_activeBot.Name);
                _activeBot.InternalInitialize(_msn);
            }
        }

        public void Stop()
        {
          Log.Info("Disconnecting...");
            _msn.Disconnect();
        }

        private void AddEventHandlers()
        {
            _msn.NameserverProcessor.ConnectionEstablished += new EventHandler(OnConnectionEstablished);
            _msn.Nameserver.SignedIn += new EventHandler(OnSignedIn);
            _msn.Nameserver.SignedOff += new SignedOffEventHandler(OnSignedOff);
            _msn.NameserverProcessor.ConnectionException += new ProcessorExceptionEventHandler(OnConnectionException);
            _msn.Nameserver.ExceptionOccurred += new HandlerExceptionEventHandler(OnExceptionOccurred);
            _msn.Nameserver.AuthenticationError += new HandlerExceptionEventHandler(OnAuthenticationError);
            _msn.Nameserver.ServerErrorReceived += new ErrorReceivedEventHandler(OnServerErrorReceived);
            _msn.ConversationCreated += new ConversationCreatedEventHandler(OnConversationCreated);
            _msn.NameserverProcessor.ConnectionClosed += new EventHandler(OnConnectionClosed);
            _msn.Owner.StatusChanged += new Contact.StatusChangedEventHandler(OnStatusChanged);
            _msn.Nameserver.SynchronizationCompleted += new EventHandler(OnSynchronizationCompleted);
        }

        private void OnSynchronizationCompleted(object sender, EventArgs e)
        {
            Log.Info("Synchronization completed");
            _msn.Owner.Name = _activeBot.DisplayName;
            _msn.Owner.Status = PresenceStatus.Online;
            Log.Info("Status set to online");
        }

        private void OnStatusChanged(object sender, StatusChangeEventArgs e)
        {
            Log.DebugFormat("Status changed from {0} to {1}", e.OldStatus, _msn.Owner.Status);
        }

        private void OnConnectionClosed(object sender, EventArgs e)
        {
            Log.Info("Connection closed");
        }

        private void OnConnectionEstablished(object sender, EventArgs e)
        {
            Log.Info("Connection Established");
        }

        private void OnConnectionException(object sender, ExceptionEventArgs e)
        {
            Log.InfoFormat("Connection Exception: {0}", e.Exception);
        }

        private void OnSignedIn(object sender, EventArgs e)
        {
            Log.Info("Signed in");
            Log.Info("Synchronizing contact list");
            _msn.Nameserver.SynchronizeContactList();
        }

        private void Connect()
        {
            Log.InfoFormat("Connecting to MSN as {0}", _msn.Credentials.Account);
            _msn.Connect();
        }
        

        #endregion

        #region DotMSN event handlers

        void OnConversationCreated(object sender, ConversationCreatedEventArgs e)
        {
            Log.Info("Conversation created");
            _activeBot.ConversationCreated(e.Conversation);
            e.Conversation.Switchboard.TextMessageReceived += new TextMessageReceivedEventHandler(OnTextMessageReceived);
        }

        void OnTextMessageReceived(object sender, TextMessageEventArgs e)
        {
            if (HandleCommand(e.Message.Text, (SBMessageHandler) sender, e.Sender.Mail))
            {
                return;
            }
            _activeBot.InternalMessageReceived((SBMessageHandler) sender, e.Sender, e.Message);
        }


        private bool HandleCommand(string command, SBMessageHandler msgHandler, string senderEmail)
        {
            if (!BotEngineCommands.IsCommand(command) || senderEmail != AdministratorEmail)
            {
                return false;
            }
            switch (command)
            {
                case BotEngineCommands.CONTACTS:
                    StringBuilder builder = new StringBuilder();
                    foreach (Contact c in _msn.ContactList.All)
                    {
                        builder.AppendFormat("{0} ({1}){2}", c.Name, c.Mail, Environment.NewLine);
                    }
                    msgHandler.SendTextMessage(new TextMessage(builder.ToString()));
                    msgHandler.NSMessageHandler.w
                    break;
                case BotEngineCommands.DISCONNECT:
                    Stop();
                    break;
            }
            return true;
        }

        void OnServerErrorReceived(object sender, MSNErrorEventArgs e)
        {
          Log.ErrorFormat("Server Error Received: {0}", e.MSNError); 
        }

        void OnAuthenticationError(object sender, ExceptionEventArgs e)
        {
            Log.ErrorFormat("Authentication error: {0}", e.Exception);
        }

        void OnExceptionOccurred(object sender, ExceptionEventArgs e)
        {
            Log.ErrorFormat("Exception occured: {0}", e.Exception.Message);
        }

        void OnSignedOff(object sender, SignedOffEventArgs e)
        {
            Log.InfoFormat("Signed off, reason: {0}", e.SignedOffReason);
        }

        #endregion

        #region NullBot

        private class NullBot : Bot
        {
            public override string Name { get { return "NullBot"; } }
            public override string DisplayName { get { return "Windows Live! Bot"; } }
            public override void Initialize() { }
            public override void ShutDown() { }
            public override void MessageReceived(SBMessageHandler msgHandler, Contact sender, TextMessage message)
            { 
                TextMessage msg = new TextMessage("ERROR: No bot loaded!");
                msg.Color = System.Drawing.Color.Red;
                SendTextMessage(msgHandler, "Error");
            }

            public override void ConversationCreated(Conversation conversation) { }
        }

        #endregion

    }
}
