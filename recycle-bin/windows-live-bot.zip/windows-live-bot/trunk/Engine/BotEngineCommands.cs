using System;
using System.Collections.Generic;
using System.Text;

namespace WLiveBot.Engine
{
    public class BotEngineCommands
    {
        public const string CONTACTS = "$CONTACTS";
        public const string DISCONNECT = "$DISCONNECT";


        public static bool IsCommand(string text)
        {
            return text == CONTACTS || text == DISCONNECT;
        }
    }
}
