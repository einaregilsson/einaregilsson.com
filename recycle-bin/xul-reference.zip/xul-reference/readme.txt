[This is the original page that was at http://tech.einaregilsson.com/projects/xul-reference/]

NOTE: As of 22.10.2008 this project has been discontinued, there will be no further updates. 
The reason for this is that xulplanet.com is no longer being updated so this reference is 
becoming more and more out of date.

This is one of the few extension I didn�t do for a request. I did it for myself when I was 
learning xul and constantly looking things up on xulplanet.com. The extension allows you 
to highlight names of xpcom/xul/xbl components and interfaces in webpages, then right-click 
and go straight to its page on xulplanet.com, which is the best xul reference out there.. This 
is more than a search engine plugin because the extension knows the names of all XPCOM 
components and interfaces, XUL elements, XBL Elements, events, scriptable objects and 
common properties/attributes/style-classes of the XULElement. If you highlight one of those, 
then the right click menu will show you what type of object you�ve selected and open a 
background tab with the reference page for that object. For instance, if you select the word 
nsIMsgFolder, then the right click menu will show �XUL Reference (XPCOM interface)� and 
clicking on it will open the reference page for nsIMsgFolder in a background tab.

The selection doesn�t have be be totally accurate, these will all work:

@mozilla.org/addressbook/cardproperty;1
Components.classes["@mozilla.org/addressbook/cardproperty;1"].QueryInterface
Cc["@mozilla.org/addressbook/cardproperty;1"]
["@mozilla.org/addressbook/cardproperty;1"]
nsIMsgFolder
(Components.interfaces.nsIMsgFolder)

button
[button id="foo"]

click
onclick

The data files with all the names ship with the extension, but they can be updated by going 
to Tools - XULReference and there hitting the �Reload data� button. Then it will fetch all 
component names again from xulplanet.com

Works with: Firefox: 2.0 � 3.0.*
Latest version: 1.0.2


VERSION HISTORY

Version 1.0.2 - May 24, 2008

  Updated for Firefox 3.0 compatibility and updated with latest reference files.
  NOTE: xulplanet.com is no longer being updated so this reference will start to become 
  more and more out of date. This will probably be the last version of this addon, if 
  xulplanet.com closes it will be removed from AMO.

Version 1.0 - August 25, 2007

  Only technical changes. The extension now no longer loads all the component data from 
  xulplanet every time a window starts. Instead it ships with text files with the names, but 
  they can be updated by going into Tools - XUL Reference and hitting �Reload data�.
  
  I also changed some error handling, now it won�t continually throw up dialog error boxes 
  when something is wrong with xulplanet.com, which was very annoying.

Version 0.2 - December 1, 2006

  Added support for:

  1. Events (both �onclick� and �click� will work)
  2. Scriptable objects
  3. Common properties/attributes/style-classes of XUL Element.

Version 0.1.1 - November 26, 2006

  Fixes the path for xbl elements which was not working. Fixes searching for unknown objects, 
  search for the original selected text instead of the processed text used to find elements.

Version 0.1 - November 25, 2006

  Initial version. I�m planning to add events and scriptable objects in future versions.