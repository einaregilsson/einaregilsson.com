/* ***** BEGIN LICENSE BLOCK *****
 *   Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is XUL Reference.
 *
 * The Initial Developer of the Original Code is
 *
 * Einar Egilsson. (email: xulreference@einaregilsson.com)
 *
 * Portions created by the Initial Developer are Copyright (C) 2006
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */


var XRLoader = {

    id          : "xulreference@einaregilsson.com",
    name        : "XULReference",
    initialized : false,
    loadFailed  : false,
    strings     : null,
    asyncLoading: false,

    //Urls to get object info from
    ifaceAndCompList    : "http://xulplanet.com/references/xpcomref/",
    xul_xblList         : "http://xulplanet.com/references/elemref/refall_elemref.xml",
    objList             : "http://www.xulplanet.com/references/objref/",
    xulElementCommonList: "http://www.xulplanet.com/references/elemref/ref_XULElement.html",

    onLoad : function(event) {

        try {
            XRLib.initialize(this);
            XRLib.debug("Initializing...");
            this.strings = document.getElementById("xulreference-strings");
            XRObjects.loadObjectsFromFile();
            
            $('txtComponents').setAttribute("value", "  : " + this.getCount(XRObjects.comps));
            $('txtInterfaces').setAttribute("value", "  : " + this.getCount(XRObjects.ifaces));
            $('txtEvents').setAttribute("value", "  : " + this.getCount(XRObjects.events));
            $('txtXul').setAttribute("value", "  : " + this.getCount(XRObjects.xul));
            $('txtXbl').setAttribute("value", "  : " + this.getCount(XRObjects.xbl));
            $('txtXulXblCommon').setAttribute("value", "  : " + this.getCount(XRObjects.xulElementCommon));
            $('txtScriptableObjects').setAttribute("value", "  : " + this.getCount(XRObjects.obj));

            this.initialized = true;

            XRLib.debug("Finished initialization");

        } catch(e) {
            alert(e);
        }
    },

    btnLoadClick : function() {
        $('btnLoad').disabled = true;
        document.getElementsByTagName('dialog')[0].style.cursor = 'wait';
        for each (var s in ['txtComponents', 'txtInterfaces', 'txtEvents', 'txtXul', 'txtXbl', 'txtXulXblCommon', 'txtScriptableObjects']) {
            this.setLoadingMsg(s, '');
        }
        setTimeout('XRLoader.loadObjectInfo();', 2);    
    },

    loadObjectInfo : function() {
        
        try {
            $('btnLoad').disabled = true;
            for each (var s in ['txtComponents', 'txtInterfaces', 'txtEvents', 'txtXul', 'txtXbl', 'txtXulXblCommon', 'txtScriptableObjects']) {
                this.setLoadingMsg(s, '');
            }
            this.oldCounts = {
                xul : this.getCount(XRObjects.xul),
                xbl : this.getCount(XRObjects.xbl),
                xulElementCommon : this.getCount(XRObjects.xulElementCommon),
                obj : this.getCount(XRObjects.obj),
                events : this.getCount(XRObjects.events),
                ifaces : this.getCount(XRObjects.ifaces),
                comps : this.getCount(XRObjects.comps)
            };

            this.setupRequest(this.ifaceAndCompList, this.loadIfacesAndCompsGroup, this.asyncLoading);
            this.setupRequest(this.xul_xblList, this.loadXulAndXbl, this.asyncLoading);
            this.setupRequest(this.objList, this.loadScriptableObjects, this.asyncLoading);
            this.setupRequest(this.xulElementCommonList, this.loadXulElementCommon, this.asyncLoading);

            XRObjects.saveObjectsToFile();
            
            var msg = "";
            var map = { xul : 'newXul'
                      , xbl : 'newXbl'
                      , events : 'newEvents'
                      , comps : 'newComps'
                      , ifaces : 'newIfaces'
                      , xulElementCommon : 'newXulXblCommon'
                      , obj : 'newObj' };

            for (var name in map ) {
                msg += this.strings.getString(map[name])._(this.getCount(XRObjects[name]) - this.oldCounts[name]) + '\n';                             
            }
            XRLib.msgBox(this.strings.getString('reloadResultTitle'), msg);

        } catch (ex) {
            this.showError(ex);
        }
        $('btnLoad').disabled = false;
        document.getElementsByTagName('dialog')[0].style.cursor = 'default';
    },

    setLoadingMsg : function(elemId, param) {
        $(elemId).setAttribute('value', "  : " + this.strings.getString('loadMsg')._(param));
    },

    setupRequest : function(url, callback, async) {

        var req = new XMLHttpRequest();
        if (async) {
            req.onreadystatechange = function() { XRLoader.onReadyStateChange(req, callback); };
        }

        //Attach this so we can check for it later.
        req.url = url;

        req.open("GET", url, async);
        req.send(null);

        if (!async) {
            XRLoader.onReadyStateChange(req, callback);
        }
    },

    onReadyStateChange : function(req, callback) {

        try {
            if (req.readyState == 4) {

                if (req.status == 200) {

                    callback.call(this, req);

                } else {
                    this.showLoadError("loadError", req.status + " " + req.statusText + "(URL = " + req.url + ")");
                }
            }
        } catch(ex) {
            this.showLoadError("connectError", ex.message);
        }
    },
    
    getCount : function(obj) {
        var count = 0;
        
        for (var x in obj) {
            count++;
        }
        return count;
    },

    showLoadError : function(stringName, param) {
        if (!this.loadFailed) {
            this.loadFailed = true;
            Components.reportError(this.strings.getString(stringName)._(param));
        }
    },

    loadXulAndXbl : function(req) {

        var doc = req.responseXML;
        var elem, name, lang;
        var xulCount = 0, xblCount = 0;
        this.loadEvents(doc);
        
        XRObjects.xul = {};
        XRObjects.xbl = {};
        
        var elemList = doc.evaluate(
                "//element",
                doc,
                null,
                XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
                null);

        for (var i = 0; i < elemList.snapshotLength; i++) {
            elem = elemList.snapshotItem(i);
            name = elem.getAttribute("name");
            lang = elem.getAttribute("lang");

            if (lang == "xbl") {
                xblCount++;
                XRObjects.xbl[name] = name;
            } else {
                xulCount++;
                XRObjects.xul[name] = name;
            }
        }

        $('txtXul').setAttribute('value', '  : ' + xulCount);
        $('txtXbl').setAttribute('value', '  : ' + xblCount);
        XRLib.debug("Found %1 XUL Elements"._(xulCount));
        XRLib.debug("Found %1 XBL Elements"._(xblCount));
    },

    loadEvents : function(doc) {
        var elem
          , elemList
          , name
          , i;

        XRObjects.events = {};
        elemList = doc.evaluate(
                        "//event",
                        doc,
                        null,
                        XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE,
                        null);

        for (i = 0; i < elemList.snapshotLength; i++) {

            elem = elemList.snapshotItem(i);
            name = elem.getAttribute("name");
            XRObjects.events[name.toLowerCase()] = name;

            if (name.startsWith("on")) {
                XRObjects.events[name.substr(2).toLowerCase()] = name;
            }
        }

        $('txtEvents').setAttribute('value', '  : ' + i);
        XRLib.debug("Found %1 XUL Events"._(i));
    },


    loadXulElementCommon : function(req) {

        var s = req.responseText
          , match
          , name
          , rx
          , count = 0;


        rx = /href='#(.*?)'/g
        XRObjects.xulElementCommon = {};

        while (match = rx.exec(s)) {
            name = match[1];

            if (name.startsWith("attr_", "prop_", "class_")) {
                XRObjects.xulElementCommon[name.substr(name.indexOf("_")+1).toLowerCase().replace("-", "")] = name;
                count++;
            }
        }
        $('txtXulXblCommon').setAttribute('value', '  : ' + count);
        XRLib.debug("Found %1 properties/attributes/style-classes"._(count));
    },


    loadIfacesAndCompsGroup : function(req) {
        var s = req.responseText
          , match
          , name
          , rx;

        XRObjects.ifaces = {};
        XRObjects.comps = {};

        rx = /href='(group_.*?\.html)'/g;
        var g = "";
        while (match = rx.exec(s)) {
            name = match[1];
            this.setLoadingMsg('txtInterfaces', name.replace("group_", '').replace('.html', ''));
            this.setLoadingMsg('txtComponents', name.replace("group_", '').replace('.html', ''));
            this.setupRequest('http://xulplanet.com/references/xpcomref/' + name, this.loadIfacesAndComps, this.asyncLoading);
        }
        
        var ccount = this.getCount(XRObjects.comps);
        var icount = this.getCount(XRObjects.ifaces);
        $('txtComponents').setAttribute('value', '  : ' + ccount);
        $('txtInterfaces').setAttribute('value', '  : ' + icount);

        XRLib.debug("Found %1 components"._(ccount));
        XRLib.debug("Found %1 interfaces"._(icount));
    },

    
    loadIfacesAndComps : function(req) {

        var s = req.responseText
          , match
          , name
          , rxIface, rxComp
          , icount = 0, ccount = 0;

        rxIface = /href='ifaces\/(.*?)\.html'/g;
        rxComp= /href='comps\/c_(.*?)\.html'/g;


        while (match = rxIface.exec(s)) {
            name = match[1];
            XRObjects.ifaces[name.toLowerCase()] = name;
            icount++;
        }

        while (match = rxComp.exec(s)) {
            name = match[1];
            XRObjects.comps[name.toLowerCase()] = name;
            ccount++;
        }
    },

    loadScriptableObjects : function(req) {

        var s = req.responseText
          , match
          , name
          , rx
          , coll
          , isIfaces
          , count = 0;

        s = s.substr(s.indexOf('<div id="content">'));
        s = s.substr(0, s.indexOf('<div id="navbar">'));
        XRObjects.obj = {};
        rx = /href="(.*?)\.html".*?>(.*?)<\/a>/g

        while (match = rx.exec(s)) {
            XRObjects.obj[match[2].toLowerCase()] = match[1];
            count++;
        }

        $('txtScriptableObjects').setAttribute('value', '  : ' + count);
        XRLib.debug("Found %1 scriptable objects"._(count));
    },

    showError : function(msg) {
        XRLib.msgBox(this.strings.getString("errorTitle"), msg);
    },

};

window.addEventListener("load", function(event) { XRLoader.onLoad(event); }, false);
