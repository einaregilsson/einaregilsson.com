/* ***** BEGIN LICENSE BLOCK *****
 *   Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is XUL Reference.
 *
 * The Initial Developer of the Original Code is
 *
 * Einar Egilsson. (email: xulreference@einaregilsson.com)
 *
 * Portions created by the Initial Developer are Copyright (C) 2006
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */


var XULReference = {

    id          : "xulreference@einaregilsson.com",
    name        : "XULReference",
    initialized : false,
    loadFailed  : false,
    strings     : null,
    asyncLoading: false,

    //Known objects
    ifaces     : {},
    comps      : {},
    xul        : {},
    xbl        : {},
    obj        : {},
    events     : {},
    xulElementCommon : {},
    
    host       : "http://www.xulplanet.com",

    //Urls for objects
    ifaceUrl : "http://www.xulplanet.com/references/xpcomref/ifaces/%1.html",
    compUrl  : "http://www.xulplanet.com/references/xpcomref/comps/c_%1.html",
    xulUrl   : "http://www.xulplanet.com/references/elemref/ref_%1.html",
    xblUrl   : "http://www.xulplanet.com/references/elemref/ref_xbl%1.html",
    objUrl   : "http://www.xulplanet.com/references/objref/%1.html",
    eventUrl : "http://xulplanet.com/references/elemref/ref_EventHandlers.html#attr_%1",
    xulElementCommonUrl : "http://www.xulplanet.com/references/elemref/ref_XULElement.html#%1",
    searchUrl: "http://www.google.com/custom?cof=S:http://www.xulplanet.com;AH:left;LH:65;LC:4682B4;L:http://www.xulplanet.com/images/xulplanet.png;ALC:blue;LW:215;AWFID:0979f384d5181409;&domains=xulplanet.com&sitesearch=xulplanet.com&q=",

    onLoad : function(event) {

        try {

            // initialization code
            XRLib.initialize(this);
            $("contentAreaContextMenu")
                .addEventListener("popupshowing", function(e) { XULReference.showContextMenu(e); }, false);
            XRLib.debug("Initializing...");
            this.strings = document.getElementById("xulreference-strings");
            XRObjects.loadObjectsFromFile();
            this.initialized = true;

            XRLib.debug("Finished initialization");

        } catch(e) {
            //Don't use XRLib because it's initialization might have failed.
            if (this.strings) {
                alert(this.strings.getString("initError")._(this.name) + "\n\n" + e);
            } else {
                alert(e);
            }
        }
    },

    onUnload : function(event) {
        //Clean up here
        XRLib.debug("Finished cleanup");
    },

    showError : function(msg) {
        XRLib.msgBox(this.strings.getString("errorTitle"), msg);
    },

    showContextMenu : function(event) {

        var originalSel = content.getSelection().toString().trim();
        var menu = $("xulreference-context");
        var label = this.strings.getString("menuLabel");
        var name;

        if (menu.hidden = gContextMenu.onImage || !originalSel) return;

        sel = this.fixSelection(originalSel);

        //Bugfix. All the objects have this property, its the constructor function, and
        //we have to make sure that we don't try to insert it in an url :)
        if (sel == "constructor") {
            menu.label = label._(this.strings.getString("unknownObject"));
            this.url = this.searchUrl + escape(originalSel).replace("%20", "+");
            return;
        }

        if (name = XRObjects.comps[sel]) {

            menu.label = label._(this.strings.getString("xpcomComp"));
            this.url = this.compUrl._(name);

        } else if (name = XRObjects.ifaces[sel]) {

            menu.label = label._(this.strings.getString("xpcomIface"));
            this.url = this.ifaceUrl._(name);

        } else if (name = XRObjects.xul[sel]) {

            menu.label = label._(this.strings.getString("xulElem"));
            this.url = this.xulUrl._(name);

        } else if (name = XRObjects.xbl[sel]) {

            menu.label = label._(this.strings.getString("xblElem"));
            this.url = this.xblUrl._(name);

        } else if (name = XRObjects.events[sel]) {

            menu.label = label._(this.strings.getString("xulEvent"));
            this.url = this.eventUrl._(name);

        } else if (name = XRObjects.xulElementCommon[sel]) {

            var names = {"attr_" : "xulAttr", "prop_" : "xulProp", "class_" : "xulStyleClass" };
            var key = names[name.substr(0, name.indexOf("_")+1)];

            menu.label = label._(this.strings.getString(key));
            this.url = this.xulElementCommonUrl._(name);

        } else if (name = XRObjects.obj[sel]) {

            menu.label = label._(this.strings.getString("scriptableObject"));
            if (name.startsWith("/")) {
                //Some install objects have their reference page with an absolue path.
                this.url = this.host + name + ".html";
            } else {
                this.url = this.objUrl._(name);
            }


        } else {

            menu.label = label._(this.strings.getString("unknownObject"));
            this.url = this.searchUrl + escape(originalSel).replace("%20", "+");
        }

    },

    fixSelection : function(sel) {
        sel = sel.trim().toLowerCase();
        sel = sel.replace(/^[^a-z@]*/, "");
        sel = sel.replace(/[^a-z@0-9]*$/, "");
        var s, match;

        var starts = [ "components.interfaces."
                     , "components.classes['"
                     , 'components.classes["'
                     , "ci."
                     , "cc['"
                     , 'cc["'
                     , "@mozilla.org" ];

        for (s in starts) {
            if (sel.startsWith(starts[s])) {
                sel = sel.substr(starts[s].length);
            }
        }

        sel = sel.replace(/(\/|;|=|\?|&|\-)/g, "");

        if (match = /[^\w]/.exec(sel)) {
            sel = sel.substr(0, match.index);
        }

        return sel;
    },


    testSelectionFixing : function() {
        var testStrings = [
                "nsIMsgFolder)",
                "Components.classes['@mozilla.org/addressbook/cardproperty;1'];",
                'Components.classes["@mozilla.org/addressbook/cardproperty;1"];',
                "@mozilla.org/addressbook/cardproperty;1",
                '"@mozilla.org/addressbook/cardproperty;1"',
                "'@mozilla.org/addressbook/cardproperty;1'",
                "@mozilla.org/image/decoder;2?type=image/bmp",
                '= Components.classes["@mozilla.org/image/decoder;2?type=image/bmp"].',
                '= Cc["@mozilla.org/image/decoder;2?type=image/bmp"].',
                '= Cc["@mozilla.org/image/decoder;2?type=image/bmp"].QueryInterface',
                "nsIMsgFolder.DoStuff",
                "    Components.interfaces.nsIMsgFolder)  " ];

        for (var i in testStrings) {
            XRLib.debug(testStrings[i] + " => " + this.fixSelection(testStrings[i]));
        }

    },

    onContextMenuCommand: function(event) {
        gBrowser.addTab(this.url);
    },

    onMenuItemCommand: function(event) {
        window.openDialog("chrome://xulreference/content/loader.xul",
                    "xrloader",
                    "chrome,dialog,modal,centerscreen", this);

    }

};


window.addEventListener("load", function(event) { XULReference.onLoad(event); }, false);
