pref("extensions.xulreference.debug", false);

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.xulreference@einaregilsson.com.description", "chrome://xulreference/locale/xulreference.properties");