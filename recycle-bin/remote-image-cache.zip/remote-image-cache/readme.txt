[this is the original page http://tech.einaregilsson.com/projects/remote-image-cache/]

NOTE: As of 22.10.2008 this project has been discontinued, there will be no
further updates. This is done since Thunderbird v2.x has the same 
functionality built in.

This was done as a request for someone on the Mozillazine forums. It�s in the
sandbox at AMO so you�ll have to be a registered user to view it there. Here is 
the text from the AMO page explaining how it works:

Saves remote images from emails locally when mail is viewed for the first 
time. This allows you to view mails with remote images and have them display 
correctly even if you�re offline or the server hosting the remote images is down. 
The extension fully supports the remote content blocking policy of the user and 
won�t get the images until the user has allowed it for the given message.

So, some Q and A:

Q: How does it work?
A: Everytime you open a message with remote images, the extension will check if
it has downloaded the images previously and if so it will set the src attribute of the
image to the cached file, e.g. chrome://ricfiles/12345-filename.jpg. If it doesn�t 
have the image locally it will download it.

Q: Does it modify my emails permanently? What happens if I uninstall it?
A: The extension doesn�t modify the actual email, it only works on the DOM tree 
constructed when the email message is viewed. In english that basically means 
that if you uninstall the extensions then all your emails will be just as they were, 
referencing their remote images on their original servers.

Q: Can I tell it to download images for all my old messages?
A: No, sorry, as of version 1.0 it only downloads images for emails when the email
is being viewed. That means that if you want to cache all images from your old 
emails you�ll have to view each and every one of them. Maybe in future versions 
I�ll add some bulk download feature, who knows.

Q: What happens if I delete an email?
A: The images for it remain in the cache, I haven�t implemented a delete feature 
yet.

Q: Can I view the cache?
A: Yes, all images are stored in a folder called RemoteImageCache under your 
profile folder.

Q: I get lots of email from the same place with the same images being referenced. 
Are they stored once or many times?
A: If you get the same image in 2 emails it�s stored 2 times. The filename in cache
is basically messagenumber+filename. I did it like this because it�s easier to add 
things like deleting from cache when each message has its own unique images, 
but maybe I�ll change it later.

Q: If the images for a message are cached, is it guaranteed that no http requests 
will be made for them to the original server?
A: No. I haven�t found a way to block the requests from being made, so even if 
you have cached images you might also request them from the server. This 
extension is mostly just to make the messages display correctly when you�re 
offline or the original server has taken the images down.

Works with: Thunderbird: 1.5 � 2.0.0.*
Latest version: 1.0


VERSION HISTORY

Version 1.0 - April 21, 2007

First version. Basic functionality, send feature requests to remoteimagecache [at] einaregilsson.com