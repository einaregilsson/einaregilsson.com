/* ***** BEGIN LICENSE BLOCK *****
 *   Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is remoteimagecache.
 *
 * The Initial Developer of the Original Code is
 *
 * Einar Egilsson. (email: remoteimagecache@einaregilsson.com)
 *
 * Portions created by the Initial Developer are Copyright (C) 2007
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

//// $Id: remoteimagecache.js 48 2007-04-21 11:27:17Z einare $

var RemoteImageCache = {

    id          : "remoteimagecache@einaregilsson.com",
    name        : "RemoteImageCache",
    initialized : false,
    strings     : null,


    onLoad : function(event) {

        try {

            //we get 2 load events, only process once
            if (this.initialized) {
                return;
            }

            // initialization code
            RICLib.initialize(this);

            window.addEventListener("DOMContentLoaded", function(ev) { RemoteImageCache.messageLoaded(ev); }, false);

            RICLib.debug("Initializing...");

            this.strings = document.getElementById("remoteimagecache-strings");
            this.initalizeCache();

            RICLib.debug("Finished initialization");
            this.initialized = true;

        } catch(e) {
            //Don't use RICLib because it's initialization might have failed.
            if (this.strings) {
                alert(this.strings.getString("initError")._(this.name) + "\n\n" + e);
            } else {
                alert(e);
            }
        }
    },

    initalizeCache : function() {

        try {

            var cacheFolder = this.getCacheFolder();

            if (!cacheFolder.exists()) {
                RICLib.debug("Cache folder doesn't exist, creating...");
                cacheFolder.create(cacheFolder.DIRECTORY_TYPE, 664);
            }

        } catch (e) {
            alert(e);
        }
    },

    getCacheFolder : function() {

        var prop = Cc["@mozilla.org/file/directory_service;1"].getService(Ci.nsIProperties);

        var folder = prop.get("ProfD", Ci.nsIFile);

        folder.append("RemoteImageCache");
        return folder;
    },

    getChromeBase : function() {
        return "chrome://ricfiles/content/";
    },

    messageLoaded : function(event) {

        var img;

        try {

            if (window.top._content.document == event.target) {

                var doc = window.top._content.document.wrappedJSObject;
                var images = doc.getElementsByTagName("img");
                var hdr = this.getMsgHdr();

                if (!hdr) {
                    RICLib.debug("Failed to get message header");
                    return;
                }

                //For some reason we always get this event twice :/
                if (doc.processing == hdr.messageKey) {
                    RICLib.debug("Getting DOMContentLoaded again!!");
                    return;
                }
                doc.processing = hdr.messageKey;

                // Possible values:
                // kNoRemoteContentPolicy = 0
                // kBlockRemoteContent = 1
                // kAllowRemoteContent 2

                if (hdr.getUint32Property("remoteContentPolicy") == kBlockRemoteContent) {
                    RICLib.debug("User hasn't allowed remote content, aborting...");
                    return;
                }

                for (var i in images) {
                    img = images[i];
                    var url = img.src;
                    if (url && /^https?:\/\//.test(img.src.toLowerCase())) {

                        //RICLib.debug("Remote image: " + url);
                        localfile = this.getFile(url, hdr);

                        if (localfile.exists()) {
                            RICLib.debug("Cache hit for %1"._(url));
                            img.src = this.getChromeBase() + localfile.leafName;;
                        } else {
                            RICLib.debug("Cache miss for %1"._(url));
                            this.downloadImage(url, localfile.path);
                        }
                    } else if (url){ //Not http://
                        //RICLib.debug("Local image: " + url);
                    }
                }
            }

        } catch(e) {
            alert(e);
        }
    },

    getMsgHdr : function() {

        try {
            return messenger.msgHdrFromURI(GetSelectedMessages());
        } catch(e) {
            return null;
        }
    },

    createFilename : function(url, msgHdr) {
        return msgHdr.messageKey + "-" + url.substr(url.lastIndexOf("/")+1).replace(/(=|&|\?)/gi, '');
    },

    getFile : function(url, msgHdr) {
        var filename, nsIFile;

        filename = this.createFilename(url, msgHdr);
        nsIFile = this.getCacheFolder();

        nsIFile.append(filename);
        return nsIFile;
    },

    downloadImage : function(url, path) {
        //Set timeout so we don't delay the loading
        setTimeout(function() {
            try {
                var uri  = Cc['@mozilla.org/network/standard-url;1'].createInstance(Ci.nsIURI);
                var file = RICLib.getFile(path);
                var persist = Cc["@mozilla.org/embedding/browser/nsWebBrowserPersist;1"].createInstance(Ci.nsIWebBrowserPersist);
                uri.spec = url;
                persist.saveURI(uri, null, null, null, null, file);
            } catch(e) {
                RICLib.debug("Failed to download %1. \n\n%2"._(url, e));
                alert(RemoteImageCache.name + "\n\n" + RemoteImageCache.strings.getString("downloadError")._(url, path) + "\n\n" + e);
            }
        }, 1000);
    }

};

window.addEventListener("load", function(event) { RemoteImageCache.onLoad(event); }, false);