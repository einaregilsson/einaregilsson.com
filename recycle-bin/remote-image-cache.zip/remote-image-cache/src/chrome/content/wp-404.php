<?php
require('./wp-config.php');

$_SERVER['REQUEST_URI'] = substr($_SERVER['QUERY_STRING'], strpos($_SERVER['QUERY_STRING'], ':80')+3);
$_SERVER['PATH_INFO'] = $_SERVER['REQUEST_URI'];
$matches = array();

//Check for downloads
if (substr($_SERVER['REQUEST_URI'], 0, 10) == '/download/')
{
	if (preg_match('/^\/download\/[a-zA-Z0-9-]*\.php\.txt$/', $_SERVER['REQUEST_URI'])){
		$file = str_replace('/download/', '', $_SERVER['REQUEST_URI']);
		header('Content-type: text/plain');
		header("Content-disposition: attachment; filename=" . str_replace('.txt', '',$file));
		echo file_get_contents('./downloads/' . $file);
		exit;
	}
	else if (preg_match('/^\/download\/[a-zA-Z0-9-\.]*\.fp$/', $_SERVER['REQUEST_URI'])){
		$file = str_replace('/download/', '', $_SERVER['REQUEST_URI']);
		header('Content-type: text/plain');
		echo file_get_contents('./downloads/' . $file);
		exit;
	}
	#download syntax highlighted
	else if (preg_match('/^\/download\/([A-Za-z0-9-]*(\.user)?\.[a-z]{2,3}\.html$)/', $_SERVER['REQUEST_URI'], $matches))
	{
		$_GET['filename'] = $matches[1];
		include('./downloads/highlight.php');
	}
	else
	{
		$path = str_replace('/download/', '/downloads/', $_SERVER['REQUEST_URI']);
		header("Location: $path");
		exit;
	}
}
else //TODO: implement 404 logic
{
	include('index.php');
}
?>