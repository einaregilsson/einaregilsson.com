/* ***** BEGIN LICENSE BLOCK *****
 *   Version: MPL 1.1/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Mozilla Public License Version
 * 1.1 (the "License"); you may not use this file except in compliance with
 * the License. You may obtain a copy of the License at
 * http://www.mozilla.org/MPL/
 *
 * Software distributed under the License is distributed on an "AS IS" basis,
 * WITHOUT WARRANTY OF ANY KIND, either express or implied. See the License
 * for the specific language governing rights and limitations under the
 * License.
 *
 * The Original Code is remoteimagecache.
 *
 * The Initial Developer of the Original Code is
 *
 * Einar Egilsson. (email: remoteimagecache@einaregilsson.com)
 *
 * Portions created by the Initial Developer are Copyright (C) 2007
 * the Initial Developer. All Rights Reserved.
 *
 * Contributor(s):
 *
 * Alternatively, the contents of this file may be used under the terms of
 * either the GNU General Public License Version 2 or later (the "GPL"), or
 * the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the MPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the MPL, the GPL or the LGPL.
 *
 * ***** END LICENSE BLOCK ***** */

//// $Id: riclib.js 46 2007-04-19 07:29:09Z einare $

var RICLib = {

    _debug      : false,
    _ext        : null,
    _cout       : null,
    _prefBranch : null,
    version     : 0.2,

    initialize : function(extension) {
        this._ext = extension;
        this._cout = Cc["@mozilla.org/consoleservice;1"].getService(Ci.nsIConsoleService);
        this._debug = true;
        this._initPrefs();
    },

    debug : function(str) {
        if (this._ext.prefs.debug) {
            this._cout.logStringMessage("%1 (%2): %3"._(this._ext.name, this.time(), str));
        }
    },

    time : function() {
        var d = new Date();
        return d.getHours() + ":" + d.getMinutes() + ":" + d.getSeconds();
    },


    debugObject : function(name, obj) {
        s = name + ': ';
        for (x in obj)
            s += "\n\t%1 : %2"._(x, obj[x]);
        this.debug(s);
    },

    //Adds all prefs to a prefs object on the extension object, and registers a pref observer
    //for the branch.
    _initPrefs : function() {

        this._prefBranch = Cc["@mozilla.org/preferences-service;1"].getService(Ci.nsIPrefService)
                                .getBranch("extensions.%1."._(this._ext.id.split("@")[0]));
        this._ext.prefs = {};

        var list = this._prefBranch.getChildList("", {}).toString().split(",");

        for (i in list) {

            var name = list[i];

            var type = this._prefBranch.getPrefType(name);

            if (type == this._prefBranch.PREF_STRING) {
                this._ext.prefs[name] = this._prefBranch.getCharPref(name);
            } else if (type == this._prefBranch.PREF_INT)  {
                this._ext.prefs[name] = this._prefBranch.getIntPref(name);
            } else if (type == this._prefBranch.PREF_BOOL) {
                this._ext.prefs[name] = this._prefBranch.getBoolPref(name);
            }
        }
    },


    getCharPref : function(branch) {
        return this._prefBranch.getCharPref(branch);
    },

    getBoolPref : function(branch) {
        return this._prefBranch.getBoolPref(branch);
    },

    getIntPref : function(branch) {
        return this._prefBranch.getIntPref(branch);
    },

    getExtensionFolder : function() {
        return Cc["@mozilla.org/extensions/manager;1"]
                .getService(Ci.nsIExtensionManager)
                    .getInstallLocation(this._ext.id)
                        .getItemLocation(this._ext.id);

    },

    getEnvVar : function(name) {
        return Cc["@mozilla.org/process/environment;1"]
                .getService(Ci.nsIEnvironment)
                    .get(name);

    },

    setEnvVar : function(name, value) {
        return Cc["@mozilla.org/process/environment;1"]
                .getService(Ci.nsIEnvironment)
                    .set(name, value);

    },

    msgBox : function(title, text) {
        Cc["@mozilla.org/embedcomp/prompt-service;1"]
            .getService(Ci.nsIPromptService)
                .alert(window, title, text);
    },

    //Converts a chrome path to a local file path. Note that the
    //file specified at the end of the chrome path does not have
    //to exist.
    chromeToPath : function(path) {
        var rv;
        var ios = Cc["@mozilla.org/network/io-service;1"].createInstance(Ci.nsIIOService);
        var uri = ios.newURI(path, 'UTF-8', null);
        var cr = Cc["@mozilla.org/chrome/chrome-registry;1"].createInstance(Ci.nsIChromeRegistry);
        return cr.convertChromeURL(uri);
        return decodeURI(rv.spec.substr("file:///".length).replace(/\//g, "\\"));
    },

    //Saves 'content' to file 'filepath'. Note that filepath needs to
    //be a real file path, not a chrome path.
    saveToFile : function(filepath, content) {
        var file = this.getFile(filepath);

        if (!file.exists()) {
            file.create(Ci.nsIFile.NORMAL_FILE_TYPE, 420);
        }
        var outputStream = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);

        outputStream.init( file, 0x04 | 0x08 | 0x20, 420, 0 );
        var result = outputStream.write( content, content.length );
        outputStream.close();
    },

    startProcess: function(filename, args) {

        var file = this.getFile(filename);

        args = args ? args : [];

        if (file.exists()) {
            var nsIProcess = Cc["@mozilla.org/process/util;1"].getService(Ci.nsIProcess);
            nsIProcess.init(file);
            nsIProcess.run(false, args, args.length);
        } else {
            throw Error("File '%1' does not exist!"._(filename));
        }

   },

    //Simulates a double click on the file in question
    launchFile : function(filepath) {
        var f = this.getFile(filepath);
        f.launch();
    },


    //Gets a local file reference, return the interface nsILocalFile.
    getFile : function(filepath) {
        var f = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
        f.initWithPath(filepath);
        return f;
    },

    //Returns all elements that match the query sent in. The root used
    //in the query is the window.content.document, so this will only
    //work for html content.
    xpath : function(doc, query) {
        return doc.evaluate(query, doc, null, XPathResult.UNORDERED_NODE_SNAPSHOT_TYPE, null);
    },

    downloadFile : function(url, localPath) {

        //First we'll get the url data
        var req = new XMLHttpRequest();

        req.open("GET", url, false);

        //XHR binary charset opt by Marcus Granado 2006 [http://mgran.blogspot.com]
        req.overrideMimeType("text/plain; charset=x-user-defined");
        req.send(null);

        if (req.status != 200) {
            alert("Failed to download file at " + url);
        }

        //Write to local file

        //Initialize file
        var file = Cc["@mozilla.org/file/local;1"].createInstance(Ci.nsILocalFile);
        file.initWithPath(localPath);

        //File output stream
        var fout = Cc["@mozilla.org/network/file-output-stream;1"].createInstance(Ci.nsIFileOutputStream);

        fout.init(file, 0x02 | 0x08 | 0x20, 0664, 0); // write, create, truncate

        //Binary output stream
        var bout = Cc["@mozilla.org/binaryoutputstream;1"].createInstance(Ci.nsIBinaryOutputStream);
        bout.setOutputStream(fout);

        //Write to file
        for (var i = 0; i < req.responseText.length; i++) {
            bout.write8(req.responseText.charCodeAt(i) & 0xff);
        }
        bout.flush();
        bout.close();
    }

};

//************** Some prototype enhancements ************** //

if (!window.Cc) window.Cc = Components.classes;
if (!window.Ci) window.Ci = Components.interfaces;

//Returns true if the string contains the substring str.
String.prototype.contains = function (str) {
    return this.indexOf(str) != -1;
};

String.prototype.trim = function() {
    return this.replace(/^\s*|\s*$/gi, '');
};

String.prototype.startsWith = function(s) {
    return (this.length >= s.length && this.substr(0, s.length) == s);
};

String.prototype.endsWith = function(s) {
    return (this.length >= s.length && this.substr(this.length - s.length) == s);
};

//Inserts the arguments into the string. E.g. if
//the string is "Hello %1" then "Hello %1"._('johnny')
//would return "Hello johnny"
String.prototype._ = function() {
    s = this;
    for (var i = 0; i < arguments.length; i++) {
        var nr = "%" + (i+1);
        var repl;
        if (arguments[i] == null) {
            repl = "null";
        } else if (arguments[i] == undefined) {
            repl = "undefined";
        } else {
            repl = arguments[i];
        }
        s = s.replace(new RegExp(nr, "g"), repl);
    }
    return s;
};

function $(id) {
    return document.getElementById(id);
}