//// $Id: remoteimagecache.js 46 2007-04-19 07:29:09Z einare $
pref("extensions.remoteimagecache.debug", false);

// See http://kb.mozillazine.org/Localize_extension_descriptions
pref("extensions.remoteimagecache@einaregilsson.com.description", "chrome://remoteimagecache/locale/remoteimagecache.properties");