﻿namespace ZenCoding.VisualStudio.GUI
{
    partial class SnippetsControlBase
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lstSnippets = new System.Windows.Forms.ListView();
            this.colCategory = new System.Windows.Forms.ColumnHeader();
            this.colAbbreviation = new System.Windows.Forms.ColumnHeader();
            this.colText = new System.Windows.Forms.ColumnHeader();
            this.btnDelete = new System.Windows.Forms.Button();
            this.btnEdit = new System.Windows.Forms.Button();
            this.btnNew = new System.Windows.Forms.Button();
            this.grpSnippets = new System.Windows.Forms.GroupBox();
            this.grpSnippets.SuspendLayout();
            this.SuspendLayout();
            // 
            // lstSnippets
            // 
            this.lstSnippets.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
            this.colCategory,
            this.colAbbreviation,
            this.colText});
            this.lstSnippets.FullRowSelect = true;
            this.lstSnippets.GridLines = true;
            this.lstSnippets.Location = new System.Drawing.Point(6, 19);
            this.lstSnippets.MultiSelect = false;
            this.lstSnippets.Name = "lstSnippets";
            this.lstSnippets.ShowGroups = false;
            this.lstSnippets.Size = new System.Drawing.Size(376, 230);
            this.lstSnippets.TabIndex = 0;
            this.lstSnippets.UseCompatibleStateImageBehavior = false;
            this.lstSnippets.View = System.Windows.Forms.View.Details;
            // 
            // colCategory
            // 
            this.colCategory.Text = "Category";
            // 
            // colAbbreviation
            // 
            this.colAbbreviation.Text = "Abbreviation";
            this.colAbbreviation.Width = 76;
            // 
            // colText
            // 
            this.colText.Text = "Text";
            this.colText.Width = 236;
            // 
            // btnDelete
            // 
            this.btnDelete.Location = new System.Drawing.Point(316, 264);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(75, 23);
            this.btnDelete.TabIndex = 1;
            this.btnDelete.Text = "&Delete";
            this.btnDelete.UseVisualStyleBackColor = true;
            // 
            // btnEdit
            // 
            this.btnEdit.Location = new System.Drawing.Point(235, 264);
            this.btnEdit.Name = "btnEdit";
            this.btnEdit.Size = new System.Drawing.Size(75, 23);
            this.btnEdit.TabIndex = 2;
            this.btnEdit.Text = "&Edit...";
            this.btnEdit.UseVisualStyleBackColor = true;
            // 
            // btnNew
            // 
            this.btnNew.Location = new System.Drawing.Point(154, 264);
            this.btnNew.Name = "btnNew";
            this.btnNew.Size = new System.Drawing.Size(75, 23);
            this.btnNew.TabIndex = 3;
            this.btnNew.Text = "&New...";
            this.btnNew.UseVisualStyleBackColor = true;
            // 
            // grpSnippets
            // 
            this.grpSnippets.Controls.Add(this.lstSnippets);
            this.grpSnippets.Location = new System.Drawing.Point(3, 3);
            this.grpSnippets.Name = "grpSnippets";
            this.grpSnippets.Size = new System.Drawing.Size(388, 255);
            this.grpSnippets.TabIndex = 4;
            this.grpSnippets.TabStop = false;
            this.grpSnippets.Text = "ZenCoding snippets";
            // 
            // SnippetsOptionsPage
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.Controls.Add(this.grpSnippets);
            this.Controls.Add(this.btnNew);
            this.Controls.Add(this.btnEdit);
            this.Controls.Add(this.btnDelete);
            this.Name = "SnippetsOptionsPage";
            this.Size = new System.Drawing.Size(395, 290);
            this.grpSnippets.ResumeLayout(false);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ColumnHeader colCategory;
        private System.Windows.Forms.ColumnHeader colAbbreviation;
        private System.Windows.Forms.ColumnHeader colText;
        private System.Windows.Forms.GroupBox grpSnippets;
        protected System.Windows.Forms.ListView lstSnippets;
        protected System.Windows.Forms.Button btnEdit;
        protected System.Windows.Forms.Button btnNew;
        protected System.Windows.Forms.Button btnDelete;
    }
}
