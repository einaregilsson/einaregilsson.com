﻿/* 
ZenCoding Visual Studio AddIn
Copyright (C) 2009 Einar Egilsson
http://tech.einaregilsson.com/2009/11/12/zen-coding-visual-studio-addin/

Portions of this program (the ZenCoding Python library) were taken from
the ZenCoding project (http://code.google.com/p/zen-coding/)

Those parts are copyright (C) 2009 Sergey Chikuyonok (http://chikuyonok.ru)

This program is free software: you can redistribute it and/or modify
it under the terms of the GNU General Public License as published by
the Free Software Foundation, either version 3 of the License, or
(at your option) any later version.

This program is distributed in the hope that it will be useful,
but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
GNU General Public License for more details.

You should have received a copy of the GNU General Public License
along with this program.  If not, see <http://www.gnu.org/licenses/>.

$Id: EditSnippetBase.cs 329 2009-12-01 14:56:49Z einar@einaregilsson.com $ 
*/
using System.Windows.Forms;

namespace ZenCoding.VisualStudio.GUI
{
    public partial class EditSnippetBase : Form
    {
        public EditSnippetBase()
        {
            InitializeComponent();
        }
    }
}
