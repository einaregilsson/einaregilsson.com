# ZenCoding Visual Studio AddIn
# Copyright (C) 2009 Einar Egilsson
# http://tech.einaregilsson.com/2009/11/12/zen-coding-visual-studio-addin/
# 
# Portions of this program (the ZenCoding Python library) were taken from
# the ZenCoding project (http://code.google.com/p/zen-coding/)
# 
# Those parts are copyright (C) 2009 Sergey Chikuyonok (http://chikuyonok.ru)
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# 
# $Id: vs_mockup.py 333 2009-12-02 08:02:43Z einar@einaregilsson.com $ 

#Mock of the VS objects and function used, to make it possible to
#unit test the python implementation of the VS plugin.

NEWLINE = '\n'
class VisualStudioMock():
	def __init__(self):
		self.ActiveDocument = ActiveDocumentMock()

class ActiveDocumentMock():
	def __init__(self):
		self.Selection = SelectionMock(self)
		self.ProjectItem = ProjectItemMock()
		self.text = ''
		self.vs_sel_start = 1
		self.vs_sel_end = 1
	
	def get_text(self):	return self.text
	
	def set_text(self, val): 
		if '|' in val: #set cursor pos
			self.vs_sel_start = val.index('|')+1
			self.vs_sel_end = self.vs_sel_start
			self.text = val.replace('|', '')
		elif '[' in val and ']' in val:
			self.vs_sel_start = val.index('[')+1
			val = val.replace('[', '')
			self.vs_sel_end = val.index(']')+1
			self.text = val.replace(']', '')
		else:
			self.text = val
			self.vs_sel_start = 1
			self.vs_sel_end = 1
		
	Text = property(fget=get_text, fset=set_text)

	def Select(self, start, end):
		self.vs_sel_start = start
		self.vs_sel_end = end
		
	def to_string_with_selection(self):
		s,e = self.vs_sel_start-1,self.vs_sel_end-1
		if s == e:
			return self.text[:s]+'|'+self.text[s:]
		else:
			return self.text[:s]+'['+self.text[s:e] + ']' + self.text[e:]
			
	def get_top_point(self):
		return PointMock(self, self.vs_sel_start+1)

	def __str__(self):
		return self.to_string_with_selection()
		
	def get_bottom_point(self):
		return PointMock(self, self.vs_sel_end)

	def get_lines(self, vs_start, vs_end):
		return NEWLINE.join(self.text.split(NEWLINE)[vs_start-1:vs_end-1])
		
	def get_selection_text(self):
		return self.text[self.vs_sel_start-1:self.vs_sel_end-1]
	
	def replace_text(self, vs_pos, points, new_text):
		self.text = self.text[:vs_pos-1] + new_text + self.text[vs_pos-1+points:]
		
	def MoveToLineAndOffset(self, vs_line, vs_col):
		lines = self.text.split(NEWLINE)
		if len(lines) == 1:
			self.vs_sel_start = len(NEWLINE.join(lines[:vs_line-1])) + vs_col
		else:
			self.vs_sel_start = len(NEWLINE.join(lines[:vs_line-1])) + vs_col+1
		self.vs_sel_end = self.vs_sel_start
		
	def get_line(self, vs_pos):
		total = 1
		for nr, text in enumerate(self.text.split(NEWLINE)):
			total += len(text)+1
			if total >= vs_pos:
				return nr+1
		
	def get_line_offset(self, vs_pos):	
		line = self.get_line(vs_pos)
		lines = self.text.split(NEWLINE)
		count = len(NEWLINE.join(lines[:line-1]))
		if len(lines) == 1:
			return vs_pos - count
		else:
			return vs_pos - count-1
		
	def get_top_line(self):
		return self.get_line(self.vs_sel_start)

	def get_bottom_line(self):
		return self.get_line(self.vs_sel_end)
		
		
class PointMock():
	def __init__(self, doc, vs_pos):
		self.doc = doc
		self.vs_pos = vs_pos
		
	def CreateEditPoint(self):
		return EditPointMock(self.doc, self.vs_pos)
		
class EditPointMock():
	def __init__(self, doc, vs_pos):
		self.doc = doc
		self.AbsoluteCharOffset = vs_pos
		self.Line = doc.get_line(vs_pos)
		self.LineCharOffset = doc.get_line_offset(vs_pos)
	
	def GetLines(self, vs_start, vs_end):
		return self.doc.get_lines(vs_start, vs_end)
	
	def ReplaceText(self, points, text, flags):
		self.doc.replace_text(self.AbsoluteCharOffset, points, text)
		
	def CharLeft(self, points):
		self.AbsoluteCharOffset -= points
		self.LineCharOffset -= points
		
class SelectionMock():
	def __init__(self, doc):
		self.doc = doc
	
	def MoveToLineAndOffset(self, vs_line, vs_col, destroy):
		self.doc.MoveToLineAndOffset(vs_line,vs_col)
	
	def get_top_point(self):
		return self.doc.get_top_point()
	TopPoint = property(get_top_point)

	def get_bottom_point(self):
		return self.doc.get_bottom_point()
	BottomPoint = property(get_bottom_point)
	
	def get_text(self):
		return self.doc.get_selection_text()
	Text = property(get_text)
	
	def get_top_line(self):
		return self.doc.get_top_line()
	TopLine = property(get_top_line)

	def get_bottom_line(self):
		return self.doc.get_bottom_line()
	BottomLine = property(get_bottom_line)
	

class ProjectItemMock():
	def __init__(self):
		self.Name = 'somefile.html'		
		
		
import sys, os.path
#get the vs_zen_coding path in there
sys.path.insert(0, os.path.split(os.path.split(__file__)[0])[0])

def alert(s):
	print s
	
VisualStudio = VisualStudioMock()

#Setup environment so these are global
__builtins__['alert'] = alert
__builtins__['VisualStudio'] = VisualStudio
__builtins__['get_abbreviation'] = lambda: 'div#wrap'
__builtins__['SelectedProfile'] = 'xml'
		
	