# ZenCoding Visual Studio AddIn
# Copyright (C) 2009 Einar Egilsson
# http://tech.einaregilsson.com/2009/11/12/zen-coding-visual-studio-addin/
# 
# Portions of this program (the ZenCoding Python library) were taken from
# the ZenCoding project (http://code.google.com/p/zen-coding/)
# 
# Those parts are copyright (C) 2009 Sergey Chikuyonok (http://chikuyonok.ru)
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# 
# $Id: test_vs_expand.py 333 2009-12-02 08:02:43Z einar@einaregilsson.com $ 

from vs_mockup import *
import vs_zen_coding
import unittest



doc = VisualStudio.ActiveDocument


class Test(unittest.TestCase):
	def testSimpleTag(self):
		self._expand("foo|",'<foo>|</foo>')

	def testNestedTag(self):
		self._expand('table>tr>td|', '<table>\n\t<tr>\n\t\t<td>|</td>\n\t</tr>\n</table>')
		
	def _expand(self, input, exp):
		doc.set_text(input)
		vs_zen_coding.expand()
		#Don't care about newline issues right now
		result = str(doc).replace('\r\n','\n')
		exp = exp.replace('\r\n', '\n')
		#print exp
		#print result
		self.assertEquals(exp,result)
		
if __name__ == "__main__":
	unittest.main()		