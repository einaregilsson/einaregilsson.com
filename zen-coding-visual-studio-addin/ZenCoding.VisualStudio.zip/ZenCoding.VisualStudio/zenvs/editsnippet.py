﻿# ZenCoding Visual Studio AddIn
# Copyright (C) 2009 Einar Egilsson
# http://tech.einaregilsson.com/2009/11/12/zen-coding-visual-studio-addin/
# 
# Portions of this program (the ZenCoding Python library) were taken from
# the ZenCoding project (http://code.google.com/p/zen-coding/)
# 
# Those parts are copyright (C) 2009 Sergey Chikuyonok (http://chikuyonok.ru)
# 
# This program is free software: you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation, either version 3 of the License, or
# (at your option) any later version.
# 
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
# 
# You should have received a copy of the GNU General Public License
# along with this program.  If not, see <http://www.gnu.org/licenses/>.
# 
# $Id: editsnippet.py 333 2009-12-02 08:02:43Z einar@einaregilsson.com $ 

import zenvs.references
from ZenCoding.VisualStudio.GUI import EditSnippetBase
from System.Windows.Forms import *

class EditSnippet(EditSnippetBase):
	
	def __new__(cls, category=None, abbr=None, text=None, settings=None):
		self = EditSnippetBase.__new__(cls)
		self.abbr = abbr
		self.settings = settings
		if abbr:
			self.Text = "Edit ZenCoding snippet"
			self.cboCategory.Text = category
			self.txtAbbreviation.Text = abbr
			self.txtExpandedText.Text = text
		else:
			self.Text = "New ZenCoding snippet"
			self.cboCategory.SelectedIndex = 0
		
		self.btnOK.Click += self.OK
		self.btnCancel.Click += self.Cancel
		return self

	def get_category(self):
		return self.cboCategory.Text
	Category = property(fget=get_category)

	def get_abbreviation(self):
		return self.txtAbbreviation.Text
	Abbreviation = property(fget=get_abbreviation)
        
	def get_expanded_text(self):
		return self.txtExpandedText.Text
	ExpandedText = property(fget=get_expanded_text)
	
	def OK(self, *args):
		if self.Abbreviation != self.abbr:
			if self.Category in self.settings:
				s = self.settings[self.Category]
				if 'snippets' in s and self.Abbreviation in s['snippets'] \
					or 'abbreviations' in s and self.Abbreviation in s['abbreviations']:
						MessageBox.Show(self,'Another snippet with the abbreviation "%s" already exists in category "%s"' % (self.Abbreviation, self.Category), 'ZenCoding Error')
						return
		self.DialogResult = DialogResult.OK
		self.Close()
	
	def Cancel(self, *args):
		self.DialogResult = DialogResult.Cancel
		self.Close()
