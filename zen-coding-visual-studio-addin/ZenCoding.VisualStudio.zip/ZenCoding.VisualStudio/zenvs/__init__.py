﻿import clr
clr.AddReference('EnvDTE80')
clr.AddReference('EnvDTE')
clr.AddReference('Extensibility')
clr.AddReference('ZenCoding.VisualStudio')
clr.AddReference('System.Windows.Forms')
