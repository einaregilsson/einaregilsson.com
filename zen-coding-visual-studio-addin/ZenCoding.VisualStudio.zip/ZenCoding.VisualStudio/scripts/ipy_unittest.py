import sys, os, os.path, re, unittest


def ipyTest():
	basefolder = os.path.split(os.path.split(__file__)[0])[0]
	testfolder = os.path.join(basefolder,'zenunittest')
	sys.path.insert(0, basefolder)
	sys.path.insert(0, testfolder)
	files = [f for f in os.listdir(testfolder) if f.endswith('.py')]
	filenameToModuleName = lambda f: os.path.splitext(f)[0]
	moduleNames = map(filenameToModuleName, files)
	modules = map(__import__, moduleNames)
	load = unittest.defaultTestLoader.loadTestsFromModule
	return unittest.TestSuite(map(load, modules))

if __name__ == "__main__":
	unittest.main(defaultTest="ipyTest")