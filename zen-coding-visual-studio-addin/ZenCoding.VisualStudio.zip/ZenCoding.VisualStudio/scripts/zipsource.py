import os, os.path, zipfile

base = os.path.split(os.path.split(__file__)[0])[0]

zip = zipfile.ZipFile('ZenCoding.VisualStudio.zip','w')
ignore_folders = (r'\.svn', '_ReSharper', '\\bin\\', '\\obj\\')
ignore_files = ('.user', '.suo', '.zip', '.msi', '.pyc', '.cache')
for (root, folders, files) in os.walk(base):
	if any(x for x in ignore_folders if x in root):
		continue
	for f in files:
		if not f.lower().endswith(ignore_files):
			zip.write(os.path.join(root,f), os.path.join('ZenCoding.VisualStudio', root[len(base)+1:],f))

zip.close()
