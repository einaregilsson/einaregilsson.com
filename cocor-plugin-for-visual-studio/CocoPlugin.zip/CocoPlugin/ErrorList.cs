/*
 * Coco/R Plugin for Visual Studio
 * http://tech.einaregilsson.com/2009/03/20/coco-r-plugin-for-visual-studio/
 *
 * Copyright (C) 2009 Einar Egilsson [einar@einaregilsson.com]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 2 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */
using System;
using System.Collections.Generic;
using EnvDTE;
using System.Windows.Forms;
using Microsoft.VisualStudio.Shell;
using Microsoft.VisualStudio;
using Microsoft.VisualStudio.Shell.Interop;

namespace Coco
{
    public class ErrorList : IServiceProvider
    {

        private ErrorListProvider _errorListProvider;

        public ErrorList()
        {
            _errorListProvider = new ErrorListProvider(this);
            _errorListProvider.ProviderName = "Coco/R Parser Generator";
            _errorListProvider.ProviderGuid = new Guid("{051F078C-B363-4d08-B351-206E9E62BBEF}");
            _errorListProvider.Show();
        }

        public void AddError(Project project, ProjectItem projectItem, string errorText, TaskErrorCategory category, int iLine, int iColumn)
        {
            ErrorTask task;
            IVsSolution solution;
            IVsHierarchy hierarchy;

            try
            {
                solution = (IVsSolution)GetService(typeof(IVsSolution));
                ErrorHandler.ThrowOnFailure(solution.GetProjectOfUniqueName(project.UniqueName, out hierarchy));

                task = new ErrorTask();
                task.ErrorCategory = category;
                task.HierarchyItem = hierarchy;
                task.Document = projectItem.get_FileNames(0);

                // VS uses indexes starting at 0 while the automation model uses indexes starting at 1
                task.Line = iLine - 1;
                task.Column = iColumn;
                task.Text = errorText;
                task.Navigate += ErrorTaskNavigate;
                _errorListProvider.Tasks.Add(task);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        public void ClearErrors() {
            _errorListProvider.Tasks.Clear();
        }

        public void ClearErrors(string atgFile)
        {
            for (int i = _errorListProvider.Tasks.Count - 1; i >= 0; i--) {
                if (_errorListProvider.Tasks[i].Document.ToLower() == atgFile.ToLower()) {
                    _errorListProvider.Tasks.RemoveAt(i);
                }
            }
        }

        public object GetService(Type serviceType)
        {
            try
            {
                return Package.GetGlobalService(serviceType);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return null;
            }
        }

        private void ErrorTaskNavigate(object sender, EventArgs e)
        {
            ErrorTask task;
            try
            {
                task = (ErrorTask)sender;
                task.Line += 1;
                _errorListProvider.Navigate(task, new Guid(EnvDTE.Constants.vsViewKindTextView));
                task.Line -= 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString(), "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

    }
}
