﻿// Keyboard hook to play a rimshot sound. Press Ctrl+Shift+I to play the sound,
// and Ctrl+Shift+Alt+I to exit the application. More information at:
//
// http://tech.einaregilsson.com/2009/06/20/instant-rimshot/

using System;
using System.IO;
using System.Media;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Windows.Forms;

class InstantRimshot {
    
    const int WH_KEYBOARD_LL = 13;
    const int WM_KEYDOWN = 0x100;

    delegate int Hook(int code, IntPtr wParam, IntPtr lParam);

    [DllImport("user32.dll")]
    static extern IntPtr SetWindowsHookEx(int code, Hook func, IntPtr hInstance, int threadID);

    [DllImport("user32.dll")]
    static extern int UnhookWindowsHookEx(IntPtr hookHandle);

    [DllImport("user32.dll")]
    static extern int CallNextHookEx(IntPtr hhook, int code, IntPtr wParam, IntPtr lParam);

    static bool IsPressed(Keys check) {
        return ((Control.ModifierKeys & check) == check);
    }

    static void Main() {
        
        Stream sound = Assembly.GetExecutingAssembly().GetManifestResourceStream("InstantRimshot.rimshot.wav");
        SoundPlayer player = new SoundPlayer(sound);
        player.Load();
        IntPtr hookHandle = IntPtr.Zero;
        hookHandle = SetWindowsHookEx(WH_KEYBOARD_LL,
            delegate(int code, IntPtr wParam, IntPtr lParam) {
                if (code >= 0 && wParam == (IntPtr) WM_KEYDOWN) {
                    Keys vkCode = (Keys)Marshal.ReadInt32(lParam);
                    if (Keys.I == vkCode && IsPressed(Keys.Control) && IsPressed(Keys.Shift)) {
                        if (IsPressed(Keys.Alt)) {
                            UnhookWindowsHookEx(hookHandle);
                            Application.Exit();
                            return CallNextHookEx(hookHandle, code, wParam, lParam);
                        } else {
                            player.Play();
                        }
                    }
                }
                return CallNextHookEx(hookHandle, code, wParam, lParam);
            }, IntPtr.Zero, 0);
        Application.Run();
    }

 
}