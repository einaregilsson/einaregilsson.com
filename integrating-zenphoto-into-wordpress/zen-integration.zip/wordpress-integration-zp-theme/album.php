<?php include('head.php'); ?>
<?php include(TEMPLATEPATH . '/zp-album.php'); ?>
