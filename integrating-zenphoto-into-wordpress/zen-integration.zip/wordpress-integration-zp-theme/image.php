<?php include('head.php'); ?>
<?php include(TEMPLATEPATH .'/zp-image.php'); ?>
