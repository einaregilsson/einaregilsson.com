<?php if (!defined('WEBPATH')) die(); ?>
<?php require($_SERVER['DOCUMENT_ROOT'].'/wp-blog-header.php'); ?>

<?php

// add the zen css to the wordpress header
function add_css() {
  echo "\t<link rel=\"stylesheet\" href=\"" . get_bloginfo('stylesheet_directory') . "/zp-style.css\" type=\"text/css\" />\n";
}
add_action('wp_head', 'add_css');

// add the zen javascript to the wordpress header
function add_javascript() {
  echo "\t<link rel=\"stylesheet\" href=\"" . get_bloginfo('stylesheet_directory') . "/zp-style.css\" type=\"text/css\" />\n";
}
add_action('wp_head', 'zenJavascript');

?>