<?php get_header(); ?>
<div id="content" class="narrowcolumn">
	<div id="zenphoto">
		<h2><?php echo getGalleryTitle(); ?></h2>

		<div id="albums">
			<?php while (next_album()): ?>
			<div class="album">
				<a href="<?php echo getAlbumLinkURL();?>" title="View album: <?php echo getAlbumTitle();?>">
				<?php printAlbumThumbImage(getAlbumTitle()); ?>
				</a>
				<div class="albumdesc">
					<small><?php printAlbumDate("Date Taken: "); ?></small>
					<h3><a href="<?php echo getAlbumLinkURL();?>" title="View album: <?php echo getAlbumTitle();?>"><?php printAlbumTitle(); ?></a></h3>
					<p><?php printAlbumDesc(); ?></p>
				</div>
				<p style="clear: both;"></p>
			</div>
			<?php endwhile; ?>
		</div>

		<?php printPageListWithNav("&laquo; prev", "next &raquo;"); ?>

		<div id="enableSorting">
	  		<?php printSortableGalleryLink('Click to sort gallery', 'Manual sorting', NULL, 'credit'); ?>
	  	</div>

		<div id="credit"><?php printAdminLink('Admin', '', ' | '); ?>Powered by <a href="http://www.zenphoto.org" title="A simpler web photo album">zenphoto</a></div>
	</div>
</div>
<?php get_sidebar(); ?>
<?php get_footer(); ?>