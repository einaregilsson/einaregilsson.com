<?php get_header(); ?>
<div id="content" class="widecolumn">
	<div id="zenphoto">

		<h2><a href="<?php echo getGalleryIndexURL();?>" title="Gallery Index"><?php echo getGalleryTitle();?></a> &raquo; <?php printAlbumTitle(true);?></h2>
		<?php printAlbumDesc(true); ?>

		<div id="album-images">
			<?php while (next_image()): ?>
			<a href="<?php echo getImageLinkURL();?>" title="<?php echo getImageTitle();?>"><?php printImageThumb(getImageTitle()); ?></a>
			<?php endwhile; ?>
		</div>

		<?php printPageListWithNav("&laquo; prev", "next &raquo;"); ?>

		<div id="enableSorting">
			<?php printSortableAlbumLink('Click to sort album', 'Manual sorting', NULL, 'sort'); ?>
		</div>

		<div id="credit"><?php printAdminLink('Admin', '', ' | '); ?>Powered by <a href="http://www.zenphoto.org" title="A simpler web photo album">zenphoto</a></div>
	</div>
</div>
<?php get_footer(); ?>
