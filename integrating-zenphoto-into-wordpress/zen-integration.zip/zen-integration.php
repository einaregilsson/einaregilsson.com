<?php

/*
Plugin Name: ZenPhoto Integration
Plugin URI: http://tech.einaregilsson.com/2007/08/06/integrating-zenphoto-into-wordpress/
Description: ZenPhoto Integration, a plugin that adds a ZenPhoto link to your admin panel.
Version: 1.0
Author: Einar Egilsson
Author URI: http://tech.einaregilsson.com


    Copyright 2007 Einar Egilsson (email: tech@einaregilsson.com)

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA

*/

add_action('admin_menu', 'zpint_menu');

#Replace if your zenphoto is not in a folder called zenphoto, photos or gallery
$zp_admin_url = '';

function zpint_menu()
{
	$names = array('zenphoto', 'photos', 'gallery');
	global $zp_admin_url;

	if (function_exists('add_menu_page'))
	{
		if ($zp_admin_url == '')
		{
			foreach($names as $ix => $name)
			{
				if (is_dir("../$name"))
				{
					add_menu_page('ZenPhoto', 'ZenPhoto', 1, "../$name/zen/admin.php");
				}
			}
		}
		else
		{
			add_menu_page('ZenPhoto', 'ZenPhoto', 1, $zp_admin_url);
		}
	}

	global $wp_file_descriptions;
	if (isset($wp_file_descriptions))
	{
		$wp_file_descriptions['zp-index.php'] = 'ZenPhoto Index';
		$wp_file_descriptions['zp-image.php'] = 'ZenPhoto Image';
		$wp_file_descriptions['zp-album.php'] = 'ZenPhoto Album';
		$wp_file_descriptions['zp-style.css'] = 'ZenPhoto Stylesheet';
	}
}
