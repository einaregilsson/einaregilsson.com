/*
 * ZenPhoto Uploader
 * http://tech.einaregilsson.com/2009/07/20/zenphoto-uploader/
 *
 * Copyright (C) 2009 Einar Egilsson [einar@einaregilsson.com]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */
using System;
using System.Drawing;
using System.Drawing.Drawing2D;
using System.Collections.Generic;
using System.IO;
using System.Drawing.Imaging;

namespace ZenPhotoUploader
{
    static class ImageEdit
    {
        public static void RotateLeft(string filename)
        {
            Rotate(filename, RotateFlipType.Rotate270FlipNone);
        }

        public static void RotateRight(string filename)
        {
            Rotate(filename, RotateFlipType.Rotate90FlipNone);
        }

        private static void Rotate(string filename, RotateFlipType type)
        {
            Image img = Image.FromFile(filename);
            img.RotateFlip(type);
            img.Save(filename, ImageFormat.Jpeg);
            img.Dispose();
        }

        public static byte[] ResizeImage(string filename, int width, int height)
        {
            Image img = Image.FromFile(filename);
            if (img.Width < img.Height)
            {
                int tmp = width;
                width = height;
                height = tmp;
            }

            Image output = new Bitmap(width, height);
            Graphics graphics = Graphics.FromImage(output);
            graphics.CompositingQuality = CompositingQuality.HighQuality;
            graphics.SmoothingMode = SmoothingMode.HighQuality;
            graphics.InterpolationMode = InterpolationMode.HighQualityBicubic;
            graphics.DrawImage(img, 0, 0, width, height);
            foreach (PropertyItem pi in img.PropertyItems)
            {
                output.SetPropertyItem(pi);
            }
            MemoryStream ms = new MemoryStream();
            output.Save(ms, ImageFormat.Jpeg);
            img.Dispose();
            graphics.Dispose();
            output.Dispose();
            byte[] result = new byte[ms.Length];
            ms.Seek(0, SeekOrigin.Begin);
            ms.Read(result, 0, (int)ms.Length);
            ms.Close();
            return result;
        }
    }
}
