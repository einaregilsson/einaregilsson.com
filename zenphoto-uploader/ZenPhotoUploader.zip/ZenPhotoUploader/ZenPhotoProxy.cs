﻿/*
 * ZenPhoto Uploader
 * http://tech.einaregilsson.com/2009/07/20/zenphoto-uploader/
 *
 * Copyright (C) 2009 Einar Egilsson [einar@einaregilsson.com]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */
using System;
using System.Collections.Generic;
using System.Net;
using System.Text;
using System.IO;
using System.Web;
using System.Text.RegularExpressions;

namespace ZenPhotoUploader {

    //return false to cancel
    public delegate bool ProgressReporter(string message);
    
    public class ZenPhotoProxy {

        public const int RETRY_COUNT = 3;

        private string baseUrl;
        private string loginCookie;
        private int width;
        private int height;
        public const int NO_RESIZE = 0;

        public ZenPhotoProxy(string baseUrl) : this(baseUrl, NO_RESIZE, NO_RESIZE) { }
        public ZenPhotoProxy(string baseUrl, int resizeWidth, int resizeHeight) {
            this.baseUrl = baseUrl;
            this.width = resizeWidth;
            this.height = resizeHeight;
            if (!this.baseUrl.EndsWith("/")) {
                this.baseUrl += "/";
            }
        }

        public bool Login(string user, string password) {
            WebRequest req = NewRequest("zp-core/admin.php", "POST");
            req.ContentType = "application/x-www-form-urlencoded";
            req.Method = "POST";
            byte[] bytes = Encoding.ASCII.GetBytes(string.Format("login=1&user={0}&pass={1}", user, password));
            Stream stream = req.GetRequestStream();
            stream.Write(bytes, 0, bytes.Length);
            stream.Close();
            HttpWebResponse response = (HttpWebResponse)req.GetResponse();
            foreach (string cookieString in response.GetResponseHeader("set-cookie").Split(',')) {
                string cookie = cookieString.Trim();
                if (cookie.StartsWith("zenphoto_auth")) {
                    if (cookie.StartsWith("zenphoto_auth=deleted")) {
                        return false;
                    }
                    loginCookie = cookie;
                    return true;
                }
            }
            return false; //Shouldn't happen, should always get some cookie
        }
        private void CheckLoginStatus() {
            if (loginCookie == null) {
                throw new ZenPhotoException("You are not logged in!");
            }
        }

        private string MakeSlug(string name) {
            name = name.ToLower();
            name = name.Replace("á", "a");
            name = name.Replace("ð", "d");
            name = name.Replace("é", "e");
            name = name.Replace("í", "i");
            name = name.Replace("ó", "o");
            name = name.Replace("ú", "u");
            name = name.Replace("þ", "th");
            name = name.Replace("æ", "ae");
            name = name.Replace("ö", "o");
            name = name.Replace("ý", "y");
            name = name.Replace(" ", "-");
            name = Regex.Replace(name, "-+", "-");
            name = Regex.Replace(name, "[^a-zA-Z0-9-]", "");
            return name;
        }

        private void SaveAlbumInfo(string albumSlug, string albumTitle, string albumDescription, bool publish, string thumbfile) {
            WebRequest req = NewRequest("zp-core/admin.php?page=edit&action=save&album="+albumSlug, "POST");
            req.ContentType = "application/x-www-form-urlencoded";
            StreamWriter writer = new StreamWriter(req.GetRequestStream());
            string unusedParams = "albumuser=&albumpass=&albumpass_2=&albumpass_hint_en_US=&albumplace_en_US=&album_custom_data_en_US=&album_theme=&a-albumselect=";
            writer.Write(unusedParams);
            writer.Write("&album="+albumSlug);
            writer.Write("&savealbuminfo=1");
            writer.Write("&folder="+albumSlug);
            writer.Write("&tagsort=0");
            writer.Write("&albumtitle_en_US=" + HttpUtility.UrlEncode(albumTitle));
            writer.Write("&albumdesc_en_US=" +HttpUtility.UrlEncode(albumDescription));
            writer.Write("&subalbumsortby=ID");
            writer.Write("&sortby=ID");
            writer.Write("&allowcomments=1");
            if (publish) {
                writer.Write("&Published=1");
            }
            writer.Write("&a-renameto="+albumSlug);
            writer.Write("&thumb="+thumbfile);
            writer.Write("&albumdate=" + HttpUtility.UrlEncode(DateTime.Now.ToString("yyyy-MM-dd+HH:mm:ss")));
            writer.Close();
            req.GetResponse();
        }
        
        public void CreateAlbum(string albumName, string albumDescription, List<Photo> photos, bool publish, ProgressReporter reportPhoto) {
            Logger.Log("----------------------------------------------------------------------");
            Logger.Log("Uploading new album, " + albumName + ", with " + photos.Count + " photos");
	        CheckLoginStatus();	
            Dictionary<string, string> postFields = new Dictionary<string, string>();
            string albumSlug = MakeSlug(albumName);
            postFields.Add("processed","1");
            postFields.Add("existingfolder" , "false");
            postFields.Add("albumselect"    , "");
            if (publish)
            {
                postFields.Add("publishalbum", "1");
            }
            postFields.Add("albumtitle"     , albumName);
            postFields.Add("autogenfolder"  , "on");
            postFields.Add("folder", albumSlug);

            //My webhost is flaky, so retry when there are problems
            int retries = RETRY_COUNT;

            string boundary = "----------ThIs_Is_tHe_bouNdaRY_$";
            foreach (Photo photo in photos) {

                while (retries > 0) {
                    try {
                        WebRequest req = NewRequest("zp-core/admin-upload.php?action=upload", "POST");
                        req.ContentType = "multipart/form-data; boundary=" + boundary;
                        WriteFileToRequestStream(postFields, photo.Path, req.GetRequestStream(), boundary);
                        HttpWebResponse response = (HttpWebResponse)req.GetResponse();
                        using (StreamReader r = new StreamReader(response.GetResponseStream())) {
                            string ss = r.ReadToEnd();
                        }
                        response.Close();
                        if (reportPhoto("Uploaded " + photo.Filename)) return;
                        retries = 0;
                        Logger.Log("Uploaded " + photo.Filename);
                    } catch (Exception ex) {
                        Logger.Log("Failed to upload file " + photo.Path + "\n" + ex);
                        retries--;
                        if (retries == 0) {
                            throw;
                        }
                        if (reportPhoto("Failed to upload " + photo.Filename + ", " + retries + " retries left...")) return;
                    }
                }

                retries = RETRY_COUNT;

                while (retries > 0) {
                    try {
                        postFields["existingfolder"] = "true";
                        GetRequest(String.Format("index.php?album={0}&image={1}&rs=saveTitle&rsrsd={2}&rst=&rsargs[]={3}", albumSlug, photo.ZenPhotoFilename, DateTime.Now.Ticks, HttpUtility.UrlEncode(photo.Title)));
                        if (reportPhoto("Saved title '" + photo.Title + "'")) return;
                        retries = 0;
                        Logger.Log("Saved title: " + photo.Title);
                    } catch (Exception ex) {
                        retries--;
                        Logger.Log("Failed to save title" + photo.Title + "\n" + ex);
                        if (retries == 0) {
                            throw;
                        }
                        if (reportPhoto("Failed to save title " + photo.Title+ ", " + retries + " retries left...")) return;
                    }
                }
                
                
                string descr = photo.Description;
                if (string.IsNullOrEmpty(descr)) {
                    descr = photo.Title;
                }

                retries = RETRY_COUNT;
                while (retries > 0) {
                    try {
                        GetRequest(String.Format("index.php?album={0}&image={1}&rs=saveDesc&rst=&rsargs[]={2}", albumSlug, photo.ZenPhotoFilename, HttpUtility.UrlEncode(descr)));
                        if (descr.Length > 20) {
                            descr = descr.Substring(0, 20);
                        }
                        if (reportPhoto("Saved description '" + descr + "...'")) return;
                        retries = 0;
                        Logger.Log("Saved description: " + descr);
                    } catch (Exception ex) {
                        Logger.Log("Failed to save description " + descr+ "\n" + ex);
                        retries--;
                        if (retries == 0) {
                            throw;
                        }
                        if (reportPhoto("Failed to save description " + descr + ", " + retries + " retries left...")) return;
                    
                    }
                }
            }
            
            if (reportPhoto("Saving album name, sort order and description...")) return;

            retries = RETRY_COUNT;

            while (retries > 0) {
                try {
                    SaveAlbumInfo(albumSlug, albumName, albumDescription, publish, photos[0].ZenPhotoFilename);
                    retries = 0;
                    Logger.Log("Album info saved");
                } catch (Exception ex) {
                    Logger.Log("Failed to save album info\n" + ex);
                    retries--;
                    if (retries == 0) {
                        throw;
                    }
                }
            }

            Logger.Log("Upload completed successfully");
        }

        private WebRequest NewRequest(string url, string method)
        {
            WebRequest req = WebRequest.Create(baseUrl + url);
            req.Method = method;
            if (loginCookie != null)
            {
                req.Headers["Cookie"] = loginCookie;
            }
            return req;
        }

        private void GetRequest(string path) {
            WebRequest req = NewRequest(path, "GET");
            HttpWebResponse response = (HttpWebResponse)req.GetResponse();
            response.Close();
        }

        private void WriteFileToRequestStream(Dictionary<string,string> textValues, string filename, Stream stream, string boundary) {
            
            string crlf = "\r\n";
            StreamWriter writer = new StreamWriter(stream);

            foreach (string key in textValues.Keys) {
                writer.Write("--" + boundary + crlf);
                writer.Write("Content-Disposition: form-data; name=\"" + key + "\"" + crlf+crlf);
                writer.Write(textValues[key]+crlf);
            }
            writer.Write("--" + boundary + crlf);
            writer.Write(string.Format("Content-Disposition: form-data; name=\"files[]\"; filename=\"{0}\"",filename)+crlf);
            writer.Write("Content-Type: image/jpeg"+crlf+crlf);
            writer.Flush();

            if (width == NO_RESIZE || height == NO_RESIZE)
            {
                FileStream fin = new FileStream(filename, FileMode.Open);
                byte[] buf = new byte[1024];
                int read;
                read = fin.Read(buf, 0, buf.Length);
                while (read > 0)
                {
                    stream.Write(buf, 0, read);
                    read = fin.Read(buf, 0, buf.Length);
                }
                fin.Close();
            }
            else
            {
                byte[] imgBytes = ImageEdit.ResizeImage(filename, width, height);
                stream.Write(imgBytes, 0, imgBytes.Length);
            }
            stream.Flush();
            writer.Write(crlf+"--" + boundary + crlf + crlf);
            writer.Flush();
            stream.Close();
        }
    }
}
