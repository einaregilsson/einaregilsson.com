﻿/*
 * ZenPhoto Uploader
 * http://tech.einaregilsson.com/2009/07/20/zenphoto-uploader/
 *
 * Copyright (C) 2009 Einar Egilsson [einar@einaregilsson.com]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.Text.RegularExpressions;
using System.Drawing.Imaging;
using System.IO;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Serialization;

namespace ZenPhotoUploader {
    public partial class MainWindow : Form {

        private List<Photo> photos = new List<Photo>();
        private int dy;
        private bool mayReload = true; //Whether reloadPreview should work. Since it is called by event handlers
                                       //we might want it not to work at all times
        private Timer timer = new Timer();

        public MainWindow() {
            InitializeComponent();
            dy = this.Height - picPreview.Height - 3;
            splitContainer1.FixedPanel = FixedPanel.Panel1;
            lstImages.DataSource = photos;
            LoadAlbum();
            timer.Interval = 350;
            timer.Tick += new EventHandler(CheckPreviewRefreshed);
        }

        void CheckPreviewRefreshed(object sender, EventArgs e) {
            ReloadPreview();
            timer.Stop();
        }

        private Photo SelectedPhoto {
            get {
                return (Photo)lstImages.SelectedItem;
            }
        }
        private void btnAddPhotos_Click(object sender, EventArgs e) {

            DialogResult result = dlgOpenImageFiles.ShowDialog();
            if (result == DialogResult.OK) {
                foreach (string filename in dlgOpenImageFiles.FileNames) {
                    photos.Add(new Photo(filename));
                }
            }
            SaveAlbum();
            RefreshDataSource();
        }

        private void ReloadPreview() {
            if (SelectedPhoto != null && mayReload) {
                if (picPreview.Image != null) {
                    picPreview.Image.Dispose();
                }
                picPreview.Image = null;
                FileStream fs = new FileStream(SelectedPhoto.Path, FileMode.Open);
                picPreview.Image = Image.FromStream(fs);
                fs.Close();
            }
        }

        private void lstImages_SelectedValueChanged(object sender, EventArgs e) {
            timer.Stop();
            if (SelectedPhoto == null) {
                return;
            }
            txtTitle.Enabled = true;
            txtDescription.Enabled = true;
            txtTitle.Text = SelectedPhoto.Title;
            txtDescription.Text = SelectedPhoto.Description;
            if (txtTitle.Focused) {
                txtTitle.SelectAll();
            }
            //ReloadPreview();
            timer.Start();
        }

        private void btnTurnLeft_Click(object sender, EventArgs e) {
            if (SelectedPhoto != null) {
                ImageEdit.RotateLeft(SelectedPhoto.Path);
                ReloadPreview();
            }
        }

        private void btnTurnRight_Click(object sender, EventArgs e) {
            if (SelectedPhoto != null) {
                ImageEdit.RotateRight(SelectedPhoto.Path);
                ReloadPreview();
            }
        }

        private void SaveAlbum() {
            XmlSerializer xml = new XmlSerializer(typeof(List<Photo>));
            StringWriter output = new StringWriter(); ;
            xml.Serialize(output, photos);
            Settings.Default.LastAlbum = output.ToString();
            Settings.Default.Save();
            output.Close();
        }

        private void LoadAlbum() {
            if (Settings.Default.LastAlbum != "") {
                XmlSerializer xml = new XmlSerializer(typeof(List<Photo>));
                this.photos.Clear();
                this.photos.AddRange((List<Photo>) xml.Deserialize(new StringReader(Settings.Default.LastAlbum)));
                RefreshDataSource();
            }
        }

        private void btnUpload_Click(object sender, EventArgs e) {
            UploadWindow upload = new UploadWindow(photos);
            try {
                upload.ShowDialog();
            } catch (System.Reflection.TargetInvocationException ex) {
                string msg = ex.Message;
                msg.ToString(); //Just for debug;
            }
        }


        private void txtTitle_TextChanged(object sender, EventArgs e) {
            if (SelectedPhoto != null && txtTitle.Focused && SelectedPhoto.Title != txtTitle.Text) {
                SelectedPhoto.Title = txtTitle.Text;
                SaveAlbum();
                RefreshDataSource();
            }
        }

        private void txtDescription_TextChanged(object sender, EventArgs e) {
            if (SelectedPhoto != null && txtDescription.Focused && SelectedPhoto.Description != txtDescription.Text) {
                SelectedPhoto.Description = txtDescription.Text;
                SaveAlbum();
            }
        }

        private void ZPWindow_Resize(object sender, EventArgs e) {
            if (splitContainer1.Panel2.Width > 2) { //For mono, which runs this at startup when it has no width
                picPreview.Height = this.Height - dy;
                picPreview.Width = splitContainer1.Panel2.Width - 3;
            }
        }

        private void btnMoveUp_Click(object sender, EventArgs e) {
            MoveImage(0, -1);
        }

        private void MoveImage(int failIndex, int offset) {
            if (SelectedPhoto == null || lstImages.SelectedIndex == failIndex)
                return;
            mayReload = false;
            int index = lstImages.SelectedIndex;
            Photo temp = photos[index];
            photos[index] = photos[index + offset];
            photos[index + offset] = temp;
            RefreshDataSource();
            lstImages.SelectedIndex = index + offset;
            SaveAlbum();
            mayReload = true;
        }

        private void btnMoveDown_Click(object sender, EventArgs e) {
            MoveImage(photos.Count - 1, 1);
        }

        private void lstImages_DragDrop(object sender, DragEventArgs e) {
            try {
                string[] files = (string[]) e.Data.GetData(DataFormats.FileDrop);
                foreach (string file in files) {
                    if (!Regex.IsMatch(file, @"\.(jpe?g|png|gif|bmp)$", RegexOptions.IgnoreCase)) {
                        MessageBox.Show(string.Format("Cannot add file '{0}', only common image files are allowed!", file), "Cannot add file", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        continue;
                    }
                    this.photos.Add(new Photo(file));
                }
                RefreshDataSource();
            } catch (Exception ex) {
                MessageBox.Show(string.Format("Failed to add files with drag-drop!", "Cannot add files", MessageBoxButtons.OK, MessageBoxIcon.Error));
                Logger.Log("Drag-drop error:\n" + ex);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e) {
            if (SelectedPhoto == null) {
                return;
            }
            ConfirmDelete confirm = new ConfirmDelete(SelectedPhoto.Filename);
            DialogResult result = confirm.ShowDialog(this);
            int index = lstImages.SelectedIndex;
            if (result == DialogResult.No || result == DialogResult.Yes) {
                Photo photo = SelectedPhoto;
                photos.RemoveAt(index);
                RefreshDataSource();

                if (result == DialogResult.Yes) {
                    System.IO.File.Delete(photo.Path);
                }
                if (index < photos.Count) {
                    lstImages.SelectedIndex = index; //Select the next in the list
                } else if (index == photos.Count && photos.Count > 0) {
                    lstImages.SelectedIndex = index - 1;
                } else if (photos.Count == 0) {
                    txtDescription.Text = "";
                    txtTitle.Text = "";
                    txtTitle.Enabled = false;
                    txtDescription.Enabled = false;
                    picPreview.Image = null;
                }
                SaveAlbum();
                ReloadPreview();
            }
        }

        //Double buffering. Causes other problems :(
        //protected override CreateParams CreateParams {
        //    get {
        //        CreateParams result = base.CreateParams;
        //        result.ExStyle |= 0x02000000; // WS_EX_COMPOSITED
        //        return result;
        //    }
        //}

        private void RefreshDataSource() {
            ((CurrencyManager)lstImages.BindingContext[photos]).Refresh();
        }

        private void OnKeyDown(object sender, KeyEventArgs e) {
            if ((e.Modifiers & Keys.Control) == Keys.Control) {
                if (e.KeyCode == Keys.Left) {
                    btnTurnLeft_Click(btnTurnLeft, new EventArgs());
                    e.Handled = true;
                } else if (e.KeyCode == Keys.Right) {
                    btnTurnRight_Click(btnTurnRight, new EventArgs());
                    e.Handled = true;
                } else if (e.KeyCode == Keys.Up) {
                    e.Handled = true;
                    if ((e.Modifiers & Keys.Shift) == Keys.Shift) {
                        btnMoveUp_Click(btnMoveUp, new EventArgs());
                    } else {
                        if (lstImages.SelectedIndex > 0) {
                            lstImages.SelectedIndex -= 1;
                        }
                    }
                } else if (e.KeyCode == Keys.Down) {
                    e.Handled = true;
                    if ((e.Modifiers & Keys.Shift) == Keys.Shift) {
                        btnMoveDown_Click(btnMoveDown, new EventArgs());
                    } else {
                        if (lstImages.SelectedIndex < photos.Count - 1) {
                            lstImages.SelectedIndex += 1;
                        }
                    }
                } else if (e.KeyCode == Keys.U) {
                    btnUpload_Click(btnUpload, new EventArgs());
                    e.Handled = true;
                } else if (e.KeyCode == Keys.D) {
                    if (SelectedPhoto != null) {
                        e.Handled = true;
                        txtDescription.Focus();
                    }
                } else if (e.KeyCode == Keys.L) {
                    lstImages.Focus();
                    if (SelectedPhoto == null && photos.Count > 0) {
                        e.Handled = true;
                        lstImages.SelectedIndex = 0;
                    }
                } else if (e.KeyCode == Keys.T) {
                    if (SelectedPhoto != null) {
                        e.Handled = true;
                        txtTitle.Focus();
                    }
                } else if (e.KeyCode == Keys.U) {
                    btnUpload_Click(btnUpload, new EventArgs());
                    e.Handled = true;
                } else if (e.KeyCode == Keys.O) {
                    btnAddPhotos_Click(btnAddPhotos, new EventArgs());
                    e.Handled = true;
                } else if (e.KeyCode == Keys.Delete) {
                    btnDelete_Click(btnDelete, new EventArgs());
                    e.Handled = true;
                }
            }
            if (e.KeyCode == Keys.Delete && sender != txtTitle && sender != txtDescription) {
                btnDelete_Click(btnDelete, new EventArgs());
                e.Handled = true;
            }
        }

        private void btnClearAlbum_Click(object sender, EventArgs e) {
            DialogResult result = MessageBox.Show("Do you want to clear all images from the album? This should only be done after you have finished uploading them to ZenPhoto!", "Clear album?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (result == DialogResult.Yes) {
                this.photos.Clear();
                picPreview.Image = null;
                SaveAlbum();
                RefreshDataSource();
            }
        }

        private void lstImages_DragEnter(object sender, DragEventArgs e) {
            e.Effect = DragDropEffects.Copy;
        }

        private void btnHelp_Click(object sender, EventArgs e) {
            Process.Start("http://tech.einaregilsson.com/2009/07/20/zenphoto-uploader/");
        }
    }
}
