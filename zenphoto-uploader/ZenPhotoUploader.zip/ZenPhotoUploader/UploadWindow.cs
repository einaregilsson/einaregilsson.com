/*
 * ZenPhoto Uploader
 * http://tech.einaregilsson.com/2009/07/20/zenphoto-uploader/
 *
 * Copyright (C) 2009 Einar Egilsson [einar@einaregilsson.com]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;

namespace ZenPhotoUploader {

    public partial class UploadWindow : Form {
        
        private List<Photo> photos;
        string status = "";

        private enum ZenPhotoResult {
            Success,
            Error,
            LoginFailed,
            Cancelled
        }

        public UploadWindow(List<Photo> photos) {
            this.photos = photos;
            InitializeComponent();
            bgWorker.DoWork += new DoWorkEventHandler(BackgroundUpload);
            bgWorker.RunWorkerCompleted += new RunWorkerCompletedEventHandler(UploadCompleted);
            bgWorker.ProgressChanged += new ProgressChangedEventHandler(ProgressChanged);
        }

        void ProgressChanged(object sender, ProgressChangedEventArgs e) {
            lblStatus.Text = status;
            prgUpload.PerformStep();
        }

        void UploadCompleted(object sender, RunWorkerCompletedEventArgs e) {
            if (e == null) {
                Logger.Log("CompletedEventArgs were null!");
            }

            ZenPhotoResult result = (ZenPhotoResult)e.Result;
            lblStatus.Text = string.Format("Uploaded album '{0}'", txtAlbumName.Text);
            
            if (result == ZenPhotoResult.Cancelled) {
                MessageBox.Show(this, "The upload was cancelled by user. Please delete the half uploaded album manually from your ZenPhoto gallery.", "Upload cancelled", MessageBoxButtons.OK, MessageBoxIcon.Information);
            } else if (result == ZenPhotoResult.Success) {
                MessageBox.Show(this, "The album was uploaded", "Upload successfull", MessageBoxButtons.OK, MessageBoxIcon.Information);
                this.Close();
            } else if (result == ZenPhotoResult.LoginFailed) {
                MessageBox.Show(this, "Failed to login to ZenPhoto", "Login failure", MessageBoxButtons.OK, MessageBoxIcon.Error);
            } else if (result == ZenPhotoResult.Error) {
                MessageBox.Show(this, e.Error.Message, "Error uploading album", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            EnableControls(true);
            btnCancel.Enabled = false;
            btnUpload.Enabled = false;

        }

        void BackgroundUpload(object sender, DoWorkEventArgs e) {
            try {
                ZenPhotoProxy proxy;
                e.Result = ZenPhotoResult.Success;
                if (chkNoResize.Checked) {
                    proxy = new ZenPhotoProxy(txtZenPhotoBaseUrl.Text);
                } else {
                    proxy = new ZenPhotoProxy(txtZenPhotoBaseUrl.Text, int.Parse(txtWidth.Text), int.Parse(txtHeight.Text));
                }
                if (!proxy.Login(txtZenPhotoUsername.Text, txtZenPhotoPassword.Text)) {
                    e.Result = ZenPhotoResult.LoginFailed;
                    return;
                }
                status = "Logged in to ZenPhoto";
                bgWorker.ReportProgress(1);
                proxy.CreateAlbum(txtAlbumName.Text, txtAlbumDescription.Text, photos, chkPublish.Checked, new ProgressReporter(delegate(string msg) {
                    bgWorker.ReportProgress(1);
                    status = msg;
                    if (bgWorker.CancellationPending) {
                        e.Result = ZenPhotoResult.Cancelled;
                        return true;
                    }
                    return false;
                }));
            } catch (Exception) {
                e.Result = ZenPhotoResult.Error;
            }
        }

        private void btnUpload_Click(object sender, EventArgs e) {
            EnableControls(false);
            btnCancel.Enabled = true;
            lblStatus.Text = "Logging in to ZenPhoto...";
            bgWorker.RunWorkerAsync();
        }

        private void EnableControls(bool enable) {
            foreach (Control c in this.Controls) {
                if (c is TextBox || c is CheckBox || c is Button) {
                    c.Enabled = enable;
                }
            }
        }


        private void UploadWindow_Load(object sender, EventArgs e) {
            txtWidth.Text = Settings.Default.ResizeWidth.ToString();
            txtHeight.Text = Settings.Default.ResizeHeight.ToString();
            txtZenPhotoBaseUrl.Text = Settings.Default.ZenPhotoBaseUrl;
            txtZenPhotoUsername.Text = Settings.Default.UserName;
            chkPublish.Checked = Settings.Default.Publish;

            prgUpload.Minimum = 0;
            prgUpload.Maximum = photos.Count * 3 + 1;
            prgUpload.Step = 1;
        }

        private void chkNoResize_CheckedChanged(object sender, EventArgs e) {
            txtWidth.Enabled = !chkNoResize.Checked;
            txtHeight.Enabled = !chkNoResize.Checked;
        }

        private void btnCancel_Click(object sender, EventArgs e) {
            bgWorker.CancelAsync();
        }

        private void UploadWindow_FormClosing(object sender, FormClosingEventArgs e) {
            Settings.Default.Publish = chkPublish.Checked;
            if (!chkNoResize.Checked) {
                Settings.Default.ResizeHeight = int.Parse(txtHeight.Text);
                Settings.Default.ResizeWidth= int.Parse(txtWidth.Text);
            }
            Settings.Default.ZenPhotoBaseUrl = txtZenPhotoBaseUrl.Text;
            Settings.Default.UserName = txtZenPhotoUsername.Text;
            Settings.Default.Save();
        }


        private void FilterAllowedNumberBoxKeys(object sender, KeyEventArgs e) {
            if (e.KeyData == Keys.A && ((e.Modifiers & Keys.Control) == Keys.Control)) {
                return; //Select all
            }
            if (e.KeyValue >= '0' && e.KeyValue <= '9') {
                return;
            }
            List<Keys> allowed = new List<Keys>(new Keys[] {
                Keys.Left, Keys.Right, Keys.Up, Keys.Down, Keys.Delete, Keys.Back, Keys.Shift, Keys.ShiftKey
            });
            e.SuppressKeyPress = !allowed.Contains(e.KeyData);
        }
    }
}
