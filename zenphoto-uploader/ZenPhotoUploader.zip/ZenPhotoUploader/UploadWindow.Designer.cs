/*
 * ZenPhoto Uploader
 * http://tech.einaregilsson.com/2009/07/20/zenphoto-uploader/
 *
 * Copyright (C) 2009 Einar Egilsson [einar@einaregilsson.com]
 *
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as published by
 * the Free Software Foundation, either version 3 of the License, or
 * (at your option) any later version.
 *
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 *
 * You should have received a copy of the GNU General Public License
 * along with this program.  If not, see <http://www.gnu.org/licenses/>.
 *  
 */
namespace ZenPhotoUploader
{
    partial class UploadWindow
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnUpload = new System.Windows.Forms.Button();
            this.txtAlbumName = new System.Windows.Forms.TextBox();
            this.lblAlbumName = new System.Windows.Forms.Label();
            this.lblResize = new System.Windows.Forms.Label();
            this.lblPublish = new System.Windows.Forms.Label();
            this.txtWidth = new System.Windows.Forms.TextBox();
            this.txtHeight = new System.Windows.Forms.TextBox();
            this.chkNoResize = new System.Windows.Forms.CheckBox();
            this.chkPublish = new System.Windows.Forms.CheckBox();
            this.lblWidth = new System.Windows.Forms.Label();
            this.lblHeight = new System.Windows.Forms.Label();
            this.prgUpload = new System.Windows.Forms.ProgressBar();
            this.bgWorker = new System.ComponentModel.BackgroundWorker();
            this.btnCancel = new System.Windows.Forms.Button();
            this.grpZenPhotoInformation = new System.Windows.Forms.GroupBox();
            this.lblZenPhotoPassword = new System.Windows.Forms.Label();
            this.lblZenPhotoUsername = new System.Windows.Forms.Label();
            this.lblZenPhotoBaseUrl = new System.Windows.Forms.Label();
            this.txtZenPhotoPassword = new System.Windows.Forms.TextBox();
            this.txtZenPhotoUsername = new System.Windows.Forms.TextBox();
            this.txtZenPhotoBaseUrl = new System.Windows.Forms.TextBox();
            this.grpAlbumInformation = new System.Windows.Forms.GroupBox();
            this.txtAlbumDescription = new System.Windows.Forms.TextBox();
            this.lblAlbumDescription = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.grpZenPhotoInformation.SuspendLayout();
            this.grpAlbumInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnUpload
            // 
            this.btnUpload.Location = new System.Drawing.Point(169, 351);
            this.btnUpload.Name = "btnUpload";
            this.btnUpload.Size = new System.Drawing.Size(131, 23);
            this.btnUpload.TabIndex = 10;
            this.btnUpload.Text = "Upload to ZenPhoto";
            this.btnUpload.UseVisualStyleBackColor = true;
            this.btnUpload.Click += new System.EventHandler(this.btnUpload_Click);
            // 
            // txtAlbumName
            // 
            this.txtAlbumName.Location = new System.Drawing.Point(74, 19);
            this.txtAlbumName.Name = "txtAlbumName";
            this.txtAlbumName.Size = new System.Drawing.Size(240, 20);
            this.txtAlbumName.TabIndex = 1;
            // 
            // lblAlbumName
            // 
            this.lblAlbumName.AutoSize = true;
            this.lblAlbumName.Location = new System.Drawing.Point(9, 22);
            this.lblAlbumName.Name = "lblAlbumName";
            this.lblAlbumName.Size = new System.Drawing.Size(68, 13);
            this.lblAlbumName.TabIndex = 2;
            this.lblAlbumName.Text = "Album name:";
            // 
            // lblResize
            // 
            this.lblResize.AutoSize = true;
            this.lblResize.Location = new System.Drawing.Point(9, 95);
            this.lblResize.Name = "lblResize";
            this.lblResize.Size = new System.Drawing.Size(42, 13);
            this.lblResize.TabIndex = 3;
            this.lblResize.Text = "Resize:";
            // 
            // lblPublish
            // 
            this.lblPublish.AutoSize = true;
            this.lblPublish.Location = new System.Drawing.Point(9, 121);
            this.lblPublish.Name = "lblPublish";
            this.lblPublish.Size = new System.Drawing.Size(44, 13);
            this.lblPublish.TabIndex = 4;
            this.lblPublish.Text = "Publish:";
            // 
            // txtWidth
            // 
            this.txtWidth.Location = new System.Drawing.Point(106, 92);
            this.txtWidth.MaxLength = 4;
            this.txtWidth.Name = "txtWidth";
            this.txtWidth.Size = new System.Drawing.Size(33, 20);
            this.txtWidth.TabIndex = 3;
            this.txtWidth.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FilterAllowedNumberBoxKeys);
            // 
            // txtHeight
            // 
            this.txtHeight.Location = new System.Drawing.Point(183, 92);
            this.txtHeight.MaxLength = 4;
            this.txtHeight.Name = "txtHeight";
            this.txtHeight.Size = new System.Drawing.Size(33, 20);
            this.txtHeight.TabIndex = 4;
            this.txtHeight.KeyDown += new System.Windows.Forms.KeyEventHandler(this.FilterAllowedNumberBoxKeys);
            // 
            // chkNoResize
            // 
            this.chkNoResize.AutoSize = true;
            this.chkNoResize.Location = new System.Drawing.Point(236, 94);
            this.chkNoResize.Name = "chkNoResize";
            this.chkNoResize.Size = new System.Drawing.Size(78, 17);
            this.chkNoResize.TabIndex = 5;
            this.chkNoResize.Text = "No resizing";
            this.chkNoResize.UseVisualStyleBackColor = true;
            this.chkNoResize.CheckedChanged += new System.EventHandler(this.chkNoResize_CheckedChanged);
            // 
            // chkPublish
            // 
            this.chkPublish.AutoSize = true;
            this.chkPublish.Location = new System.Drawing.Point(74, 121);
            this.chkPublish.Name = "chkPublish";
            this.chkPublish.Size = new System.Drawing.Size(15, 14);
            this.chkPublish.TabIndex = 6;
            this.chkPublish.UseVisualStyleBackColor = true;
            // 
            // lblWidth
            // 
            this.lblWidth.AutoSize = true;
            this.lblWidth.Location = new System.Drawing.Point(71, 95);
            this.lblWidth.Name = "lblWidth";
            this.lblWidth.Size = new System.Drawing.Size(38, 13);
            this.lblWidth.TabIndex = 9;
            this.lblWidth.Text = "Width:";
            // 
            // lblHeight
            // 
            this.lblHeight.AutoSize = true;
            this.lblHeight.Location = new System.Drawing.Point(145, 95);
            this.lblHeight.Name = "lblHeight";
            this.lblHeight.Size = new System.Drawing.Size(41, 13);
            this.lblHeight.TabIndex = 10;
            this.lblHeight.Text = "Height:";
            // 
            // prgUpload
            // 
            this.prgUpload.Location = new System.Drawing.Point(18, 316);
            this.prgUpload.Name = "prgUpload";
            this.prgUpload.Size = new System.Drawing.Size(330, 23);
            this.prgUpload.TabIndex = 11;
            // 
            // bgWorker
            // 
            this.bgWorker.WorkerReportsProgress = true;
            this.bgWorker.WorkerSupportsCancellation = true;
            // 
            // btnCancel
            // 
            this.btnCancel.Enabled = false;
            this.btnCancel.Location = new System.Drawing.Point(52, 351);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(111, 23);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // grpZenPhotoInformation
            // 
            this.grpZenPhotoInformation.Controls.Add(this.lblZenPhotoPassword);
            this.grpZenPhotoInformation.Controls.Add(this.lblZenPhotoUsername);
            this.grpZenPhotoInformation.Controls.Add(this.lblZenPhotoBaseUrl);
            this.grpZenPhotoInformation.Controls.Add(this.txtZenPhotoPassword);
            this.grpZenPhotoInformation.Controls.Add(this.txtZenPhotoUsername);
            this.grpZenPhotoInformation.Controls.Add(this.txtZenPhotoBaseUrl);
            this.grpZenPhotoInformation.Location = new System.Drawing.Point(18, 168);
            this.grpZenPhotoInformation.Name = "grpZenPhotoInformation";
            this.grpZenPhotoInformation.Size = new System.Drawing.Size(330, 112);
            this.grpZenPhotoInformation.TabIndex = 13;
            this.grpZenPhotoInformation.TabStop = false;
            this.grpZenPhotoInformation.Text = "ZenPhoto Information";
            // 
            // lblZenPhotoPassword
            // 
            this.lblZenPhotoPassword.AutoSize = true;
            this.lblZenPhotoPassword.Location = new System.Drawing.Point(6, 82);
            this.lblZenPhotoPassword.Name = "lblZenPhotoPassword";
            this.lblZenPhotoPassword.Size = new System.Drawing.Size(56, 13);
            this.lblZenPhotoPassword.TabIndex = 5;
            this.lblZenPhotoPassword.Text = "Password:";
            // 
            // lblZenPhotoUsername
            // 
            this.lblZenPhotoUsername.AutoSize = true;
            this.lblZenPhotoUsername.Location = new System.Drawing.Point(6, 56);
            this.lblZenPhotoUsername.Name = "lblZenPhotoUsername";
            this.lblZenPhotoUsername.Size = new System.Drawing.Size(58, 13);
            this.lblZenPhotoUsername.TabIndex = 4;
            this.lblZenPhotoUsername.Text = "Username:";
            // 
            // lblZenPhotoBaseUrl
            // 
            this.lblZenPhotoBaseUrl.AutoSize = true;
            this.lblZenPhotoBaseUrl.Location = new System.Drawing.Point(6, 30);
            this.lblZenPhotoBaseUrl.Name = "lblZenPhotoBaseUrl";
            this.lblZenPhotoBaseUrl.Size = new System.Drawing.Size(59, 13);
            this.lblZenPhotoBaseUrl.TabIndex = 3;
            this.lblZenPhotoBaseUrl.Text = "Base URL:";
            // 
            // txtZenPhotoPassword
            // 
            this.txtZenPhotoPassword.Location = new System.Drawing.Point(71, 79);
            this.txtZenPhotoPassword.Name = "txtZenPhotoPassword";
            this.txtZenPhotoPassword.PasswordChar = '*';
            this.txtZenPhotoPassword.Size = new System.Drawing.Size(100, 20);
            this.txtZenPhotoPassword.TabIndex = 9;
            // 
            // txtZenPhotoUsername
            // 
            this.txtZenPhotoUsername.Location = new System.Drawing.Point(71, 53);
            this.txtZenPhotoUsername.Name = "txtZenPhotoUsername";
            this.txtZenPhotoUsername.Size = new System.Drawing.Size(100, 20);
            this.txtZenPhotoUsername.TabIndex = 8;
            // 
            // txtZenPhotoBaseUrl
            // 
            this.txtZenPhotoBaseUrl.Location = new System.Drawing.Point(71, 27);
            this.txtZenPhotoBaseUrl.Name = "txtZenPhotoBaseUrl";
            this.txtZenPhotoBaseUrl.Size = new System.Drawing.Size(240, 20);
            this.txtZenPhotoBaseUrl.TabIndex = 7;
            // 
            // grpAlbumInformation
            // 
            this.grpAlbumInformation.Controls.Add(this.txtWidth);
            this.grpAlbumInformation.Controls.Add(this.txtHeight);
            this.grpAlbumInformation.Controls.Add(this.txtAlbumDescription);
            this.grpAlbumInformation.Controls.Add(this.lblAlbumDescription);
            this.grpAlbumInformation.Controls.Add(this.txtAlbumName);
            this.grpAlbumInformation.Controls.Add(this.chkPublish);
            this.grpAlbumInformation.Controls.Add(this.chkNoResize);
            this.grpAlbumInformation.Controls.Add(this.lblAlbumName);
            this.grpAlbumInformation.Controls.Add(this.lblResize);
            this.grpAlbumInformation.Controls.Add(this.lblPublish);
            this.grpAlbumInformation.Controls.Add(this.lblWidth);
            this.grpAlbumInformation.Controls.Add(this.lblHeight);
            this.grpAlbumInformation.Location = new System.Drawing.Point(18, 15);
            this.grpAlbumInformation.Name = "grpAlbumInformation";
            this.grpAlbumInformation.Size = new System.Drawing.Size(330, 147);
            this.grpAlbumInformation.TabIndex = 14;
            this.grpAlbumInformation.TabStop = false;
            this.grpAlbumInformation.Text = "Album information";
            // 
            // txtAlbumDescription
            // 
            this.txtAlbumDescription.Location = new System.Drawing.Point(74, 45);
            this.txtAlbumDescription.Multiline = true;
            this.txtAlbumDescription.Name = "txtAlbumDescription";
            this.txtAlbumDescription.Size = new System.Drawing.Size(240, 41);
            this.txtAlbumDescription.TabIndex = 2;
            // 
            // lblAlbumDescription
            // 
            this.lblAlbumDescription.AutoSize = true;
            this.lblAlbumDescription.Location = new System.Drawing.Point(9, 48);
            this.lblAlbumDescription.Name = "lblAlbumDescription";
            this.lblAlbumDescription.Size = new System.Drawing.Size(63, 13);
            this.lblAlbumDescription.TabIndex = 12;
            this.lblAlbumDescription.Text = "Description:";
            // 
            // lblStatus
            // 
            this.lblStatus.AutoSize = true;
            this.lblStatus.Location = new System.Drawing.Point(19, 293);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(325, 13);
            this.lblStatus.TabIndex = 15;
            this.lblStatus.Text = "                                                                                 " +
                "                         ";
            // 
            // UploadWindow
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(368, 391);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.grpZenPhotoInformation);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.prgUpload);
            this.Controls.Add(this.btnUpload);
            this.Controls.Add(this.grpAlbumInformation);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.MaximizeBox = false;
            this.MinimizeBox = false;
            this.Name = "UploadWindow";
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent;
            this.Text = "Upload album to ZenPhoto";
            this.Load += new System.EventHandler(this.UploadWindow_Load);
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.UploadWindow_FormClosing);
            this.grpZenPhotoInformation.ResumeLayout(false);
            this.grpZenPhotoInformation.PerformLayout();
            this.grpAlbumInformation.ResumeLayout(false);
            this.grpAlbumInformation.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnUpload;
        private System.Windows.Forms.TextBox txtAlbumName;
        private System.Windows.Forms.Label lblAlbumName;
        private System.Windows.Forms.Label lblResize;
        private System.Windows.Forms.Label lblPublish;
        private System.Windows.Forms.TextBox txtWidth;
        private System.Windows.Forms.TextBox txtHeight;
        private System.Windows.Forms.CheckBox chkNoResize;
        private System.Windows.Forms.CheckBox chkPublish;
        private System.Windows.Forms.Label lblWidth;
        private System.Windows.Forms.Label lblHeight;
        private System.Windows.Forms.ProgressBar prgUpload;
        private System.ComponentModel.BackgroundWorker bgWorker;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.GroupBox grpZenPhotoInformation;
        private System.Windows.Forms.Label lblZenPhotoPassword;
        private System.Windows.Forms.Label lblZenPhotoUsername;
        private System.Windows.Forms.Label lblZenPhotoBaseUrl;
        private System.Windows.Forms.TextBox txtZenPhotoPassword;
        private System.Windows.Forms.TextBox txtZenPhotoUsername;
        private System.Windows.Forms.TextBox txtZenPhotoBaseUrl;
        private System.Windows.Forms.GroupBox grpAlbumInformation;
        private System.Windows.Forms.TextBox txtAlbumDescription;
        private System.Windows.Forms.Label lblAlbumDescription;
        private System.Windows.Forms.Label lblStatus;
    }
}